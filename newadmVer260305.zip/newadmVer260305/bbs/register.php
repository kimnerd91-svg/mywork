<?php
include_once('./_common.php');

// 이미 로그인되어 있으면 메인으로
if ($is_member) {
    goto_url(G5_URL);
}

$error_msg = '';

// 회원가입 처리
if (isset($_POST['mode']) && $_POST['mode'] == 'register') {
    $mb_id = sql_real_escape_string(trim($_POST['mb_id']));
    $mb_password = trim($_POST['mb_password']);
    $mb_password_re = trim($_POST['mb_password_re']);
    $mb_name = sql_real_escape_string(trim($_POST['mb_name']));
    $mb_nick = sql_real_escape_string(trim($_POST['mb_nick']));
    $mb_email = sql_real_escape_string(trim($_POST['mb_email']));
    $mb_hp = sql_real_escape_string(trim($_POST['mb_hp']));
    
    // 유효성 검사
    if (!$mb_id || !$mb_password || !$mb_name || !$mb_email) {
        $error_msg = '필수 항목을 모두 입력해주세요.';
    } else if (strlen($mb_id) < 3) {
        $error_msg = '아이디는 3자 이상이어야 합니다.';
    } else if ($mb_password !== $mb_password_re) {
        $error_msg = '비밀번호가 일치하지 않습니다.';
    } else if (strlen($mb_password) < 4) {
        $error_msg = '비밀번호는 4자 이상이어야 합니다.';
    } else {
        // 아이디 중복 체크
        $sql = " SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ";
        $row = sql_fetch($sql);
        
        if ($row['mb_id']) {
            $error_msg = '이미 사용중인 아이디입니다.';
        } else {
            // 닉네임이 없으면 이름으로 설정
            if (!$mb_nick) $mb_nick = $mb_name;
            
            // 회원가입 처리 (그누보드 기본 필드 구조 사용)
            $hash_password = get_encrypt_string($mb_password);
            $mb_level = $config['cf_register_level']; // 기본 회원 레벨
            
            $sql = " INSERT INTO {$g5['member_table']} SET
                     mb_id = '$mb_id',
                     mb_password = '$hash_password',
                     mb_name = '$mb_name',
                     mb_nick = '$mb_nick',
                     mb_email = '$mb_email',
                     mb_hp = '$mb_hp',
                     mb_level = '$mb_level',
                     mb_mailling = '1',
                     mb_open = '0',
                     mb_email_certify = '0',
                     mb_datetime = '".G5_TIME_YMDHIS."',
                     mb_ip = '{$_SERVER['REMOTE_ADDR']}'
                   ";
            sql_query($sql);
            
            // 회원가입 포인트 지급
            if ($config['cf_register_point'] > 0) {
                insert_point($mb_id, $config['cf_register_point'], '회원가입 축하', '@member', $mb_id, '회원가입');
            }
            
           alert_toast('회원가입이 완료되었습니다.로그인 후 이용해주세요.', './login.php', 'success');
            exit;
        }
    }
}

// 아이디 중복 확인 (AJAX)
if (isset($_POST['check_id'])) {
    $check_id = sql_real_escape_string(trim($_POST['check_id']));
    $sql = " SELECT mb_id FROM {$g5['member_table']} WHERE mb_id = '$check_id' ";
    $row = sql_fetch($sql);
    
    header('Content-Type: application/json');
    echo json_encode(['exists' => (bool)$row['mb_id']]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입 - <?php echo $config['cf_title']; ?></title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <style>
        body { 
            background: #f8f9fa; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            margin: 0;
            padding: 20px 0;
        }
        .register-card { 
            width: 100%; 
            max-width: 480px; 
            padding: 40px; 
            background: #fff; 
            border-radius: 20px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.05); 
        }
        .input-wrapper { 
            position: relative; 
            margin-bottom: 15px; 
        }
        .input-wrapper .material-symbols-outlined { 
            position: absolute; 
            left: 15px; 
            top: 50%; 
            transform: translateY(-50%); 
            color: #adb5bd; 
            font-size: 20px;
        }
        .u-input { 
            width: 100%; 
            padding: 12px 12px 12px 45px !important; 
            border: 1px solid #ddd; 
            border-radius: 8px; 
            box-sizing: border-box;
            font-size: 14px;
        }
        .u-input:focus {
            outline: none;
            border-color: var(--main-color, #4285f4);
        }
        .w-100 { 
            width: 100%; 
            cursor: pointer; 
        }
        .id-check-wrapper {
            display: flex;
            gap: 8px;
            align-items: stretch;
        }
        .id-check-wrapper .input-wrapper {
            flex: 1;
            margin-bottom: 0;
        }
        .id-check-btn {
            padding: 12px 16px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            white-space: nowrap;
            font-size: 13px;
            color: #495057;
            font-weight: 600;
        }
        .id-check-btn:hover {
            background: #e9ecef;
        }
        .check-result {
            font-size: 12px;
            margin-top: 4px;
            margin-bottom: 8px;
        }
        .check-result.success {
            color: #28a745;
        }
        .check-result.error {
            color: #dc3545;
        }
        .password-strength {
            height: 4px;
            background: #e9ecef;
            border-radius: 2px;
            margin-top: 8px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            width: 0;
            transition: all 0.3s;
        }
        .password-strength-bar.weak { width: 33%; background: #dc3545; }
        .password-strength-bar.medium { width: 66%; background: #ffc107; }
        .password-strength-bar.strong { width: 100%; background: #28a745; }
    </style>
</head>
<body>
    <div class="register-card">
        <h1 class="text-center fw-900 u-txt-main u-mb-32">SIGN UP</h1>

        <?php if($error_msg) echo "<div class='u-p-12 u-bg-red-50 u-txt-red u-mb-16 rounded-8 c-fs-14'>$error_msg</div>"; ?>

        <form method="post" id="registerForm">
            <input type="hidden" name="mode" value="register">
            
            <!-- 아이디 -->
            <div class="u-mb-15">
                <div class="id-check-wrapper">
                    <div class="input-wrapper">
                        <span class="material-symbols-outlined">person</span>
                        <input type="text" name="mb_id" id="mb_id" class="u-input" placeholder="아이디 (영문, 숫자 3-20자)" maxlength="20" required>
                    </div>
                    <button type="button" class="id-check-btn" onclick="checkIdDuplicate()">중복확인</button>
                </div>
                <div id="idCheckResult" class="check-result"></div>
            </div>

            <!-- 비밀번호 -->
            <div class="input-wrapper">
                <span class="material-symbols-outlined">lock</span>
                <input type="password" name="mb_password" id="mb_password" class="u-input" placeholder="비밀번호 (4자 이상)" required>
            </div>
            <div class="password-strength">
                <div class="password-strength-bar" id="passwordStrengthBar"></div>
            </div>

            <!-- 비밀번호 확인 -->
            <div class="input-wrapper u-mt-15">
                <span class="material-symbols-outlined">lock_reset</span>
                <input type="password" name="mb_password_re" id="mb_password_re" class="u-input" placeholder="비밀번호 확인" required>
            </div>
            <div id="passwordMatchResult" class="check-result"></div>

            <!-- 이름 -->
            <div class="input-wrapper">
                <span class="material-symbols-outlined">badge</span>
                <input type="text" name="mb_name" class="u-input" placeholder="이름" required>
            </div>

            <!-- 닉네임 -->
            <div class="input-wrapper">
                <span class="material-symbols-outlined">account_circle</span>
                <input type="text" name="mb_nick" class="u-input" placeholder="닉네임 (선택, 미입력시 이름 사용)" maxlength="20">
            </div>

            <!-- 이메일 -->
            <div class="input-wrapper">
                <span class="material-symbols-outlined">mail</span>
                <input type="email" name="mb_email" class="u-input" placeholder="이메일" required>
            </div>

            <!-- 휴대폰 -->
            <div class="input-wrapper">
                <span class="material-symbols-outlined">phone_iphone</span>
                <input type="tel" name="mb_hp" class="u-input" placeholder="휴대폰번호 (선택)" pattern="[0-9-]+">
            </div>

            <!-- 약관 동의 -->
            <div class="u-p-16 u-bg-gray-50 rounded-8 u-mb-20">
                <label class="d-flex a-center u-gap-8 cursor-pointer u-mb-8">
                    <input type="checkbox" id="agreeAll">
                    <span class="fw-700 c-fs-14">전체 동의</span>
                </label>
                <hr style="border: none; border-top: 1px solid #dee2e6; margin: 12px 0;">
                <label class="d-flex a-center u-gap-8 cursor-pointer u-mb-8">
                    <input type="checkbox" name="agree_terms" class="agree-item" required>
                    <span class="c-fs-13 u-txt-gray-600">[필수] 이용약관 동의</span>
                </label><br>
                <label class="d-flex a-center u-gap-8 cursor-pointer">
                    <input type="checkbox" name="agree_privacy" class="agree-item" required>
                    <span class="c-fs-13 u-txt-gray-600">[필수] 개인정보 처리방침 동의</span>
                </label>
            </div>

            <button type="submit" class="u-btn u-bg-main u-txt-white w-100 u-py-12 rounded-8 fw-700 u-mb-12">회원가입</button>
            
            <div class="text-center">
                <a href="./login.php" class="u-txt-gray-500 c-fs-13">이미 계정이 있으신가요? <span class="u-txt-main fw-700">로그인</span></a>
            </div>
        </form>
    </div>

    <script>
        let idCheckPassed = false;

        // 아이디 중복 확인
        async function checkIdDuplicate() {
            const mbId = document.getElementById('mb_id').value.trim();
            const resultDiv = document.getElementById('idCheckResult');
            
            if (!mbId || mbId.length < 3) {
                resultDiv.className = 'check-result error';
                resultDiv.textContent = '아이디는 3자 이상 입력해주세요.';
                idCheckPassed = false;
                return;
            }

            // 아이디 형식 검사 (영문, 숫자만)
            if (!/^[a-zA-Z0-9]+$/.test(mbId)) {
                resultDiv.className = 'check-result error';
                resultDiv.textContent = '아이디는 영문과 숫자만 사용 가능합니다.';
                idCheckPassed = false;
                return;
            }

            try {
                const formData = new FormData();
                formData.append('check_id', mbId);
                
                const response = await fetch('', {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                
                if (data.exists) {
                    resultDiv.className = 'check-result error';
                    resultDiv.textContent = '이미 사용중인 아이디입니다.';
                    idCheckPassed = false;
                } else {
                    resultDiv.className = 'check-result success';
                    resultDiv.textContent = '✓ 사용 가능한 아이디입니다.';
                    idCheckPassed = true;
                }
            } catch (error) {
                console.error('Error:', error);
                resultDiv.className = 'check-result error';
                resultDiv.textContent = '중복 확인 중 오류가 발생했습니다.';
            }
        }

        // 아이디 입력 시 중복확인 초기화
        document.getElementById('mb_id').addEventListener('input', function() {
            idCheckPassed = false;
            document.getElementById('idCheckResult').textContent = '';
        });

        // 비밀번호 강도 체크
        document.getElementById('mb_password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrengthBar');
            
            if (password.length === 0) {
                strengthBar.className = 'password-strength-bar';
                return;
            }
            
            let strength = 0;
            if (password.length >= 6) strength++;
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength++;
            if (password.match(/[0-9]/)) strength++;
            if (password.match(/[^a-zA-Z0-9]/)) strength++;
            
            if (strength <= 1) {
                strengthBar.className = 'password-strength-bar weak';
            } else if (strength <= 2) {
                strengthBar.className = 'password-strength-bar medium';
            } else {
                strengthBar.className = 'password-strength-bar strong';
            }
        });

        // 비밀번호 확인
        document.getElementById('mb_password_re').addEventListener('input', function() {
            const password = document.getElementById('mb_password').value;
            const passwordRe = this.value;
            const resultDiv = document.getElementById('passwordMatchResult');
            
            if (passwordRe === '') {
                resultDiv.textContent = '';
                return;
            }
            
            if (password === passwordRe) {
                resultDiv.className = 'check-result success';
                resultDiv.textContent = '✓ 비밀번호가 일치합니다.';
            } else {
                resultDiv.className = 'check-result error';
                resultDiv.textContent = '비밀번호가 일치하지 않습니다.';
            }
        });

        // 전체 동의
        document.getElementById('agreeAll').addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.agree-item');
            checkboxes.forEach(checkbox => {
                checkbox.checked = this.checked;
            });
        });

        // 개별 체크박스 변경 시 전체 동의 체크박스 상태 업데이트
        document.querySelectorAll('.agree-item').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const allChecked = Array.from(document.querySelectorAll('.agree-item')).every(cb => cb.checked);
                document.getElementById('agreeAll').checked = allChecked;
            });
        });

        // 폼 제출 전 검증
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            if (!idCheckPassed) {
                e.preventDefault();
                alert_toast('아이디 중복확인을 해주세요.', "./");
                return false;
            }
            
            const password = document.getElementById('mb_password').value;
            const passwordRe = document.getElementById('mb_password_re').value;
            
            if (password !== passwordRe) {
                e.preventDefault();
                alert_toast('비밀번호가 일치하지 않습니다.', "./");
                return false;
            }

            const agreeTerms = document.querySelector('input[name="agree_terms"]').checked;
            const agreePrivacy = document.querySelector('input[name="agree_privacy"]').checked;
            
            if (!agreeTerms || !agreePrivacy) {
                e.preventDefault();
                alert_toast('필수 약관에 동의해주세요.', "./");
                return false;
            }
        });
    </script>
</body>
</html>