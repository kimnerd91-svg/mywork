<?php
// ─── 설정값 (필요시 수정 가능) ───
$title_text    = '36년의 인생';
$sub_text_1    = '혁신과 변화의 역사';
$sub_text_2    = '그 중앙에서 오늘과 만남';
$start_year    = 1896;
$end_year      = 2026;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title><?= $start_year ?> → <?= $end_year ?></title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@300;400;700&family=Noto+Sans+KR:wght@300;400&display=swap" rel="stylesheet">

<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>

<style>
  /* ─── 리셋 & 기본 ─── */
  *, *::before, *::after {
    margin: 0; padding: 0;
    box-sizing: border-box;
  }

  :root {
    --bg:          #0a0a0a;
    --num-color:   rgba(200, 190, 175, 0.52);
    --num-bright:  rgba(220, 210, 195, 0.75);
    --text-title: #e8ddd0;
    --text-sub:   rgba(200, 190, 175, 0.5);
    --accent:     rgba(200, 185, 160, 0.4);
  }

  html, body {
    width: 100%; height: 100%;
    background: var(--bg);
    color: #fff;
    font-family: 'Noto Sans KR', sans-serif;
    overflow: hidden;
  }

  /* ─── 배경 그라디엔트 ─── */
  .bg-grad {
    position: fixed; inset: 0; z-index: 0;
    background:
      radial-gradient(ellipse 70% 55% at 25% 50%, rgba(55,45,35,0.4) 0%, transparent 70%),
      radial-gradient(ellipse 50% 45% at 78% 55%, rgba(40,33,28,0.35) 0%, transparent 70%);
    pointer-events: none;
  }

  /* ─── 오른쪽 나무 패널 ─── */
  .wood-panel {
    position: fixed; top: 0; right: 0;
    width: 160px; height: 100%; z-index: 0;
    background: repeating-linear-gradient(
      90deg,
      rgba(52,38,26,0.55) 0px,
      rgba(68,48,30,0.6)  11px,
      rgba(44,30,20,0.4)  17px,
      rgba(58,40,26,0.5)  26px,
      rgba(48,34,22,0.45) 34px
    );
    opacity: 0.55;
  }
  .wood-panel::after {
    content: '';
    position: absolute; inset: 0;
    background: linear-gradient(180deg, rgba(0,0,0,0.55) 0%, transparent 25%, transparent 75%, rgba(0,0,0,0.55) 100%);
  }

  /* ─── 스테이지 ─── */
  .stage {
    position: relative; z-index: 1;
    width: 100%; height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* ─── 숫자 영역 전체 래퍼 ─── */
  .numbers-scene {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  /* 왼쪽 1896 / 오른쪽 1896 — 각각 독립 그룹 */
  .year-block {
    display: flex;
    align-items: baseline;
    /* gap은 gsap으로 직접 제어하지 않으므로 없음 */
  }

  .year-block .digit {
    font-family: 'Playfair Display', serif;
    font-weight: 300;
    line-height: 1;
    color: var(--num-color);
    display: inline-block;
    /* 초기 상태 */
    font-size: 0px;
    opacity: 0;
  }

  /* 오른쪽 블록의 숫자는 카운트 시 밝아짐 */
  .year-block--right .digit.counting {
    color: var(--num-bright);
  }

  /* ─── 중간 텍스트 ─── */
  .mid-text {
    position: absolute;
    top:  50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    width: 280px;
    z-index: 2;
    pointer-events: none;
    opacity: 0; /* 전체 컨테이너도 초기 숨김 */
  }

  .mid-text .mt-title {
    font-family: 'Playfair Display', serif;
    font-weight: 400;
    font-size: 21px;
    letter-spacing: 0.06em;
    color: var(--text-title);
    opacity: 0;
    transform: translateY(18px);
  }

  .mid-text .mt-divider {
    width: 0;
    height: 1px;
    background: var(--accent);
    margin: 16px auto;
    opacity: 0;
  }

  .mid-text .mt-sub {
    font-family: 'Noto Sans KR', sans-serif;
    font-weight: 300;
    font-size: 12px;
    line-height: 2;
    letter-spacing: 0.15em;
    text-transform: uppercase;
    color: var(--text-sub);
    opacity: 0;
    transform: translateY(14px);
  }

  /* ─── 세로 구분선 ─── */
  .split-line {
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    width: 1px;
    height: 0;
    background: var(--accent);
    z-index: 1;
  }

  /* ─── Replay 버튼 ─── */
  .replay-btn {
    position: fixed;
    bottom: 44px; left: 50%;
    transform: translateX(-50%);
    z-index: 10;
    background: transparent;
    border: 1px solid rgba(200,185,160,0.3);
    color: rgba(200,185,160,0.6);
    font-family: 'Noto Sans KR', sans-serif;
    font-size: 11px;
    letter-spacing: 0.22em;
    text-transform: uppercase;
    padding: 11px 26px;
    cursor: pointer;
    opacity: 0;
    transition: background 0.3s, color 0.3s, border-color 0.3s;
  }
  .replay-btn:hover {
    background: rgba(200,185,160,0.08);
    border-color: rgba(200,185,160,0.5);
    color: var(--text-title);
  }
</style>
</head>
<body>

<!-- 배경 레이어 -->
<div class="bg-grad"></div>
<div class="wood-panel"></div>

<!-- 메인 스테이지 -->
<div class="stage">
  <div class="numbers-scene" id="numbersScene">

    <!-- 왼쪽 1896 (복제본) -->
    <div class="year-block year-block--left" id="yearLeft">
      <span class="digit" id="lD1"><?= $start_year[0] ?></span>
      <span class="digit" id="lD2"><?= $start_year[1] ?></span>
      <span class="digit" id="lD3"><?= $start_year[2] ?></span>
      <span class="digit" id="lD4"><?= $start_year[3] ?></span>
    </div>

    <!-- 세로선 -->
    <div class="split-line" id="splitLine"></div>

    <!-- 중간 텍스트 -->
    <div class="mid-text" id="midText">
      <div class="mt-title" id="mtTitle"><?= $title_text ?></div>
      <div class="mt-divider" id="mtDivider"></div>
      <div class="mt-sub" id="mtSub1"><?= $sub_text_1 ?></div>
      <div class="mt-sub" id="mtSub2"><?= $sub_text_2 ?></div>
    </div>

    <!-- 오른쪽 1896 → 2026 (원본) -->
    <div class="year-block year-block--right" id="yearRight">
      <span class="digit" id="rD1"><?= $start_year[0] ?></span>
      <span class="digit" id="rD2"><?= $start_year[1] ?></span>
      <span class="digit" id="rD3"><?= $start_year[2] ?></span>
      <span class="digit" id="rD4"><?= $start_year[3] ?></span>
    </div>

  </div>
</div>

<!-- Replay -->
<button class="replay-btn" id="replayBtn">↺ Replay</button>

<script>
(function(){
  // ─── DOM refs ───
  const scene     = document.getElementById('numbersScene');
  const yearLeft  = document.getElementById('yearLeft');
  const yearRight = document.getElementById('yearRight');
  const splitLine = document.getElementById('splitLine');
  const midText   = document.getElementById('midText');
  const mtTitle   = document.getElementById('mtTitle');
  const mtDivider = document.getElementById('mtDivider');
  const mtSub1    = document.getElementById('mtSub1');
  const mtSub2    = document.getElementById('mtSub2');
  const replayBtn = document.getElementById('replayBtn');

  // 왼쪽 숫자 스팬 4개
  const leftDigits  = ['lD1','lD2','lD3','lD4'].map(id => document.getElementById(id));
  // 오른쪽 숫자 스팬 4개
  const rightDigits = ['rD1','rD2','rD3','rD4'].map(id => document.getElementById(id));

  // 카운트 대상: 오른쪽 1896 → 2026 (각 자릿수)
  const startDigits = [1, 9, 9, 1];
  const endDigits   = [2, 0, 2, 6];

  // ─── 초기 상태 리셋 함수 ───
  function resetAll() {
    // 왼쪽 숫자 숨김 + 원래 값
    leftDigits.forEach((el, i) => {
      gsap.set(el, { fontSize: 0, opacity: 0 });
      el.textContent = String(startDigits[i]);
    });
    // 오른쪽 숫자 숨김 + 원래 값
    rightDigits.forEach((el, i) => {
      gsap.set(el, { fontSize: 0, opacity: 0 });
      el.textContent = String(startDigits[i]);
      el.classList.remove('counting');
    });
    // 그룹 위치 리셋
    gsap.set(yearLeft,  { x: 0 });
    gsap.set(yearRight, { x: 0 });
    // 왼쪽 그룹 숨김 (아직 복제 안 된 상태)
    gsap.set(yearLeft, { opacity: 0 });
    // 세로선
    gsap.set(splitLine, { height: 0, opacity: 0 });
    // 텍스트
    gsap.set(midText,   { opacity: 0 });
    gsap.set(mtTitle,   { opacity: 0, y: 18 });
    gsap.set(mtDivider, { width: 0, opacity: 0 });
    gsap.set(mtSub1,    { opacity: 0, y: 14 });
    gsap.set(mtSub2,    { opacity: 0, y: 14 });
    // replay btn
    gsap.set(replayBtn, { opacity: 0 });
  }

  // ─── 메인 타임라인 생성 ───
  function buildTimeline() {
    const tl = gsap.timeline({ delay: 0.7 });

    // ════════════════════════════════════════
    // 1단계: 중앙에 1896 하나 등장 (오른쪽 블록 사용)
    //         숫자 1→8→9→6 순차 등장 후 확대
    // ════════════════════════════════════════

    // 각 숫자 순차 페이드 등장 (작은 크기)
    rightDigits.forEach((el, i) => {
      tl.to(el, {
        fontSize: 72,
        opacity: 1,
        duration: 0.45,
        ease: 'power2.out'
      }, i * 0.16);
    });

    // 전체 숫자 확대 (큰 크기로)
    tl.to(rightDigits, {
      fontSize: 170,
      duration: 1.0,
      ease: 'power3.out',
      stagger: 0.03
    }, 0.9);

    // ════════════════════════════════════════
    // 2단계: 왼쪽 복제본 등장 + 양쪽 분리
    //         왼쪽 블록을 오른쪽과 같은 크기로 즉시 세팅 후
    //         중앙에서 동시에 벌어짐
    // ════════════════════════════════════════

    // 왼쪽 블록을 오른쪽과 동일한 크기로 즉시 세팅 (분리 직전)
    tl.set(leftDigits, { fontSize: 170, opacity: 1 }, 1.85);
    tl.set(yearLeft,   { opacity: 1 },                 1.85);

    // 왼쪽/오른쪽 동시에 벌어짐
    tl.to(yearLeft, {
      x: -115,
      duration: 0.85,
      ease: 'power2.inOut'
    }, 1.92);
    tl.to(yearRight, {
      x: 115,
      duration: 0.85,
      ease: 'power2.inOut'
    }, 1.92);

    // ════════════════════════════════════════
    // 3단계: 세로선 등장
    // ════════════════════════════════════════
    tl.to(splitLine, {
      height: 130,
      opacity: 1,
      duration: 0.5,
      ease: 'power2.out'
    }, 2.35);

    // ════════════════════════════════════════
    // 4단계: 오른쪽 숫자 카운트 (동적 생성)
    //         startDigits → endDigits 각 자릿수별로
    //         카운트 방향(올림/내림)을 자동 판단
    // ════════════════════════════════════════

    const countStart  = 2.9;   // 카운트 시작 타이밍
    const stepDur     = 0.07;  // 각 숫자 변경당 소요 시간
    const digitDelay  = 0.15;  // 자릿수 간 시작 딜레이

    // 밝기 강조
    rightDigits.forEach(el => {
      tl.to(el, { color: 'rgba(220,210,195,0.82)', duration: 0.15 }, countStart - 0.1);
    });

    // 각 자릿수별로 카운트 시퀀스 동적 생성
    startDigits.forEach((s, idx) => {
      const e = endDigits[idx];
      if (s === e) return; // 변경 불필요하면 건너뜀

      const dir   = e > s ? 1 : -1;        // 올림(+1) 또는 내림(-1)
      const steps = Math.abs(e - s);        // 총 카운트 단계 수
      const baseTime = countStart + idx * digitDelay; // 해당 자릿수의 시작 타이밍

      for (let step = 1; step <= steps; step++) {
        const val = s + dir * step;
        tl.to({}, {
          duration: stepDur,
          onStart: () => { rightDigits[idx].textContent = String(val); }
        }, baseTime + (step - 1) * stepDur);
      }
    });

    // ════════════════════════════════════════
    // 5단계: 양쪽 더 벌어짐 (텍스트 공간 확보)
    // ════════════════════════════════════════
    tl.to(yearLeft, {
      x: -175,
      duration: 0.75,
      ease: 'power2.out'
    }, 3.75);
    tl.to(yearRight, {
      x: 175,
      duration: 0.75,
      ease: 'power2.out'
    }, 3.75);

    // 세로선 더 길어짐
    tl.to(splitLine, {
      height: 200,
      duration: 0.6,
      ease: 'power2.out'
    }, 3.75);

    // ════════════════════════════════════════
    // 6단계: 중간 텍스트 등장
    // ════════════════════════════════════════
    // 컨테이너 등장
    tl.set(midText, { opacity: 1 }, 4.2);

    // 타이틀
    tl.to(mtTitle, {
      opacity: 1, y: 0,
      duration: 0.65,
      ease: 'power2.out'
    }, 4.2);

    // 구분선
    tl.to(mtDivider, {
      width: 38, opacity: 1,
      duration: 0.45,
      ease: 'power2.out'
    }, 4.6);

    // 서브 1
    tl.to(mtSub1, {
      opacity: 1, y: 0,
      duration: 0.55,
      ease: 'power2.out'
    }, 4.78);

    // 서브 2
    tl.to(mtSub2, {
      opacity: 1, y: 0,
      duration: 0.55,
      ease: 'power2.out'
    }, 5.05);

    // ── Replay 버튼 등장 ──
    tl.to(replayBtn, { opacity: 1, duration: 0.4 }, 5.6);

    return tl;
  }

  // ─── 초기화 & 실행 ───
  resetAll();
  let tl = buildTimeline();

  // ─── Replay ───
  replayBtn.addEventListener('click', () => {
    tl.kill();
    resetAll();
    tl = buildTimeline();
  });

})();
</script>
</body>
</html>
<?php
// ─── 참고: 이 파일은 PHP 서버에서 실행되어야 <?= ?> 태그가 처리됨 ───
// 로컬 테스트 시: php -S localhost:8000 으로 내장 서버 실행 후 접속
?>