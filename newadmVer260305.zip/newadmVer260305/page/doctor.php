<?php
// 의료진 데이터 가져오기
if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}

$doctor_table = 'dm_doctors';

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$doctor_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) {
    return;
}

// 노출 가능한 의료진만 가져오기
$sql = "SELECT * FROM {$doctor_table} WHERE is_visible = 1 ORDER BY display_order ASC, id ASC";
$result = sql_query($sql, false);

if (!$result || sql_num_rows($result) == 0) {
    return;
}
?>

<!-- 의료진 섹션 -->
<section class="u-py-80 u-bg-black">
    <div class="u-mx-auto" style="max-width: 1400px; padding: 0 var(--sp-20);">

        <!-- 헤더 -->
        <div class="text-center u-mb-60" data-aos="fade-up">
            <div class="u-txt-main fw-700 c-fs-14 u-mb-10" style="text-transform: uppercase; letter-spacing: 1px;">MEDICAL STAFF</div>
            <h2 class="t-fs-48 fw-900 u-mb-16 u-txt-white">전문 의료진</h2>
            <p class="c-fs-18 u-txt-muted">최고의 실력과 경험을 갖춘 의료진이 함께합니다</p>
        </div>

        <!-- 의료진 그리드 -->
        <div class="g-cols-fit-12 u-gap-32">
            <?php while ($doctor = sql_fetch_array($result)):
                $degrees = json_decode($doctor['degree'], true);
                $careers = json_decode($doctor['career'], true);
                $specialties = json_decode($doctor['specialty'], true);
            ?>
                <div class="doctor-card-hover position-relative cursor-pointer u-bg-white rounded-20 overflow-hidden shadow-soft rounded-16"
                     data-id="<?= $doctor['id'] ?>"
                     data-name="<?= htmlspecialchars($doctor['name']) ?>"
                     data-position="<?= htmlspecialchars($doctor['position']) ?>"
                     data-specialty='<?= htmlspecialchars(json_encode($specialties, JSON_UNESCAPED_UNICODE)) ?>'
                     data-degree='<?= htmlspecialchars(json_encode($degrees, JSON_UNESCAPED_UNICODE)) ?>'
                     data-career='<?= htmlspecialchars(json_encode($careers, JSON_UNESCAPED_UNICODE)) ?>'
                     data-image="<?= htmlspecialchars($doctor['image']) ?>"
                     onclick="openDoctorModal(this)">

                    <!-- 이미지 영역 -->
                    <div class="doctor-img-wrapper">
                        <?php if ($doctor['image']): ?>
                            <img src="<?= htmlspecialchars($doctor['image']) ?>"
                                 alt="<?= htmlspecialchars($doctor['name']) ?>"
                                 class="doctor-profile-img">
                        <?php else: ?>
                            <div class="doctor-no-img">
                                <span style="font-size: 64px;">👨‍⚕️</span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- 카드 하단 정보 -->
                    <div class="doctor-card-info u-p-24 u-txt-white">
                        <h3 class="fw-900 u-mb-8 u-m-0 c-fs-20">
                            <?= htmlspecialchars($doctor['name']) ?>
                        </h3>
                        <p class="c-fs-14 u-m-0" style="opacity: 0.9;">
                            <?= htmlspecialchars($doctor['position']) ?>
                        </p>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<!-- 오버레이 -->
<div class="doctor-overlay" id="doctorOverlay" onclick="closeDoctorModal()"></div>

<!-- 모달 -->
<div class="doctor-modal overflow-hidden u-bg-soft rounded-32 shadow-xl" id="doctorModal">
    <button class="doctor-close-btn position-absolute u-bg-white u-txt-gray-700 rounded-full d-flex align-items-center c-fs-24 justify-content-center cursor-pointer shadow-soft"
            style="top: var(--sp-24); right: var(--sp-24); width: 52px; height: 52px; border: none; z-index: 1001;"
            onclick="closeDoctorModal()">✕</button>

    <div class="doctor-modal-inner d-flex w-full h-full u-gap-40 u-p-48">
        <!-- 왼쪽: 이미지 -->
        <div class="doctor-modal-left flex-shrink-0">
            <div class="doctor-modal-img-box position-relative rounded-24 u-bg-white shadow-lg overflow-hidden">
                <img id="doctorModalImage" 
                     src="" 
                     alt="" 
                     style="width: 100%; height: 100%; object-fit: cover; display: block;">
            </div>
        </div>

        <!-- 오른쪽: 정보 (스크롤 가능) -->
        <div class="doctor-modal-right overflow-y-auto overflow-x-hidden">
            <div class="doctor-modal-content u-pr-24">
                <h1 class="fw-900 u-txt-title u-mb-12 t-fs-32 u-lh-125" id="doctorModalName"></h1>
                <p class="fw-700 u-txt-main u-mb-16 c-fs-20" id="doctorModalPosition"></p>

                <!-- 진료과목 태그 -->
                <div class="d-flex flex-wrap u-gap-10 u-mb-32" id="doctorModalSpecialties"></div>

                <div class="w-full u-bg-gray-200 u-my-8" style="height: 1px;"></div>

                <!-- 학위 -->
                <div id="doctorModalDegreeSection" class="u-mb-40">
                    <h3 class="fw-700 u-txt-title u-mb-20 c-fs-18" style="text-transform: uppercase; letter-spacing: 1px;">
                        🎓 학위
                    </h3>
                    <div class="d-grid u-gap-16 g-cols-fit-12" id="doctorModalDegree"></div>
                </div>

                <!-- 경력 -->
                <div id="doctorModalCareerSection">
                    <h3 class="fw-700 u-txt-title u-mb-20 c-fs-18" style="text-transform: uppercase; letter-spacing: 1px;">
                        💼 경력
                    </h3>
                    <div class="d-flex flex-column u-gap-12" id="doctorModalCareer"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
/* ============================================
   의료진 카드 - 모든 카드 동일 높이
============================================ */

/* 카드 컨테이너 - 3:4 비율 고정 */
.doctor-card-hover {
    aspect-ratio: 3 / 4;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.doctor-card-hover:hover {
    transform: translateY(-8px);
}

/* 이미지 래퍼 - 카드 전체를 덮음 */
.doctor-img-wrapper {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
}

/* 이미지 - 카드 전체 커버 */
.doctor-profile-img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    object-position: center top;
    display: block;
    transition: transform 0.5s ease;
}

.doctor-card-hover:hover .doctor-profile-img {
    transform: scale(1.05);
}

/* 이미지 없을 때 */
.doctor-no-img {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, var(--bg-soft) 0%, var(--gray-200) 100%);
}

/* 카드 하단 그라데이션 오버레이 */
.doctor-card-info {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(
        to top,
        rgba(0, 0, 0, 0.95) 0%,
        rgba(0, 0, 0, 0.75) 60%,
        transparent 100%
    );
}

/* ============================================
   모달 오버레이
============================================ */
.doctor-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0);
    backdrop-filter: blur(0px);
    opacity: 0;
    visibility: hidden;
    z-index: var(--z-modal);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
}

.doctor-overlay.is-active {
    background: rgba(0, 0, 0, 0.85);
    backdrop-filter: blur(10px);
    opacity: 1;
    visibility: visible;
}

/* ============================================
   모달
============================================ */
.doctor-modal {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%) scale(0.9);
    width: 90vw;
    height: 85vh;
    max-width: 1400px;
    max-height: 900px;
    opacity: 0;
    visibility: hidden;
    z-index: calc(var(--z-modal) + 1);
    transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

.doctor-modal.is-active {
    transform: translate(-50%, -50%) scale(1);
    opacity: 1;
    visibility: visible;
}

/* 모달 내부 레이아웃 */
.doctor-modal-left {
    width: 35%;
    height: 100%;
}

.doctor-modal-img-box {
    width: 100%;
    height: 100%;
}

.doctor-modal-right {
    width: 65%;
    height: 100%;
}

/* 스크롤바 커스텀 */
.doctor-modal-right::-webkit-scrollbar {
    width: 8px;
}

.doctor-modal-right::-webkit-scrollbar-track {
    background: var(--gray-200);
    border-radius: 10px;
}

.doctor-modal-right::-webkit-scrollbar-thumb {
    background: var(--gray-400);
    border-radius: 10px;
}

.doctor-modal-right::-webkit-scrollbar-thumb:hover {
    background: var(--gray-500);
}

/* 진료과목 태그 호버 */
.specialty-tag {
    transition: all 0.2s ease;
}

.specialty-tag:hover {
    border-color: var(--main-color);
    background: var(--bg-soft);
    color: var(--main-color);
}

/* 학위 카드 호버 */
.degree-card {
    transition: all 0.3s ease;
}

.degree-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
}

/* 경력 카드 호버 */
.career-card {
    transition: all 0.2s ease;
}

.career-card:hover {
    transform: translateX(4px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

/* 닫기 버튼 호버 */
.doctor-close-btn {
    transition: all 0.3s ease;
}

.doctor-close-btn:hover {
    background: var(--main-color) !important;
    color: var(--white) !important;
    transform: rotate(90deg);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15) !important;
}

/* ============================================
   반응형 - 태블릿 (1024px 이하)
============================================ */
@media (max-width: 1024px) {
    .doctor-modal {
        width: 92vw;
        height: 88vh;
    }
    
    .doctor-modal-inner {
        gap: var(--sp-32) !important;
        padding: var(--sp-32) !important;
    }

    .doctor-modal-left {
        width: 40% !important;
    }

    .doctor-modal-right {
        width: 60% !important;
    }
}

/* ============================================
   반응형 - 모바일 (768px 이하)
============================================ */
@media (max-width: 768px) {
    /* 섹션 여백 조정 */
    section.u-py-80 {
        padding-top: var(--sp-60) !important;
        padding-bottom: var(--sp-60) !important;
    }
    
    /* 헤더 여백 조정 */
    .text-center.u-mb-60 {
        margin-bottom: var(--sp-40) !important;
    }
    
    /* 그리드 간격 조정 */
    .g-cols-fit-12 {
        gap: var(--sp-24) !important;
    }
    
    /* 모달 크기 */
    .doctor-modal {
        width: 95vw;
        height: 90vh;
    }
    
    /* 모달 내부 세로 배치 */
    .doctor-modal-inner {
        flex-direction: column !important;
        gap: var(--sp-24) !important;
        padding: var(--sp-24) !important;
    }
    
    .doctor-modal-left {
        width: 100% !important;
        height: 40% !important;
    }
    
    .doctor-modal-right {
        width: 100% !important;
        height: 60% !important;
    }
    
    .doctor-modal-content {
        padding-right: 0 !important;
    }
    
    /* 닫기 버튼 크기 조정 */
    .doctor-close-btn {
        width: 44px !important;
        height: 44px !important;
        top: var(--sp-16) !important;
        right: var(--sp-16) !important;
    }
}

/* ============================================
   반응형 - 작은 모바일 (480px 이하)
============================================ */
@media (max-width: 480px) {
    /* 카드 텍스트 크기 조정 */
    .doctor-card-info h3 {
        font-size: clamp(1rem, 3vw, 1.25rem) !important;
    }
    
    .doctor-card-info p {
        font-size: clamp(0.8rem, 2.5vw, 0.875rem) !important;
    }
}
</style>

<script>
const doctorOverlay = document.getElementById('doctorOverlay');
const doctorModal = document.getElementById('doctorModal');

/**
 * 의료진 모달 열기
 */
function openDoctorModal(card) {
    // 데이터 추출
    const name = card.dataset.name;
    const position = card.dataset.position;
    const image = card.dataset.image;

    let specialties = [];
    let degrees = [];
    let careers = [];

    try {
        specialties = JSON.parse(card.dataset.specialty) || [];
    } catch (e) {
        console.error('Specialty parse error:', e);
    }

    try {
        degrees = JSON.parse(card.dataset.degree) || [];
    } catch (e) {
        console.error('Degree parse error:', e);
    }

    try {
        careers = JSON.parse(card.dataset.career) || [];
    } catch (e) {
        console.error('Career parse error:', e);
    }

    // 모달에 기본 정보 삽입
    document.getElementById('doctorModalName').textContent = name;
    document.getElementById('doctorModalPosition').textContent = position;

    // 이미지 설정
    const modalImg = document.getElementById('doctorModalImage');
    if (image) {
        modalImg.src = image;
        modalImg.alt = name;
        modalImg.style.display = 'block';
    } else {
        modalImg.style.display = 'none';
    }

    // 진료과목 태그
    const specialtiesContainer = document.getElementById('doctorModalSpecialties');
    if (specialties.length > 0) {
        specialtiesContainer.innerHTML = specialties.map(item => {
            return `<span class="specialty-tag d-inline-flex align-items-center u-p-10 u-px-20 u-bg-white rounded-full c-fs-14 fw-600 u-txt-c-color" 
                      style="border: 1.5px solid var(--gray-300);">${item}</span>`;
        }).join('');
        specialtiesContainer.style.display = 'flex';
    } else {
        specialtiesContainer.style.display = 'none';
    }

    // 학위 섹션
    const degreeSection = document.getElementById('doctorModalDegreeSection');
    const degreeContainer = document.getElementById('doctorModalDegree');

    if (degrees.length > 0) {
        degreeSection.style.display = 'block';
        degreeContainer.innerHTML = degrees.map(item => {
            if (item.logo) {
                return `
                <div class="degree-card u-bg-white rounded-16 u-p-16 shadow-soft d-flex align-items-center u-gap-16">
                    <img src="${item.logo}" alt="학위 로고" 
                         class="flex-shrink-0 u-bg-soft rounded-12 u-p-10" 
                         style="width: 56px; height: 56px; object-fit: contain;">
                    <div class="flex-1 c-fs-15 u-txt-c-color fw-500 u-lh-15">
                        ${item.text}
                    </div>
                </div>
            `;
            } else {
                return `
                <div class="degree-card u-bg-white rounded-16 u-p-16 shadow-soft">
                    <div class="c-fs-15 u-txt-c-color fw-500 u-lh-15">
                        ${item.text}
                    </div>
                </div>
            `;
            }
        }).join('');
    } else {
        degreeSection.style.display = 'none';
    }

    // 경력 섹션
    const careerSection = document.getElementById('doctorModalCareerSection');
    const careerContainer = document.getElementById('doctorModalCareer');

    if (careers.length > 0) {
        careerSection.style.display = 'block';
        careerContainer.innerHTML = careers.map(item => {
            return `
            <div class="career-card u-bg-white rounded-12 u-p-16 u-px-20 shadow-sm d-flex align-items-center u-gap-12">
                <div class="career-bullet flex-shrink-0 u-bg-black rounded-full" 
                     style="width: 6px; height: 6px;"></div>
                <div class="flex-1 c-fs-15 u-txt-c-color fw-500 u-lh-15">
                    ${item.text}
                </div>
            </div>
        `;
        }).join('');
    } else {
        careerSection.style.display = 'none';
    }

    // body 스크롤 방지
    document.body.style.overflow = 'hidden';

    // 오버레이 & 모달 활성화
    setTimeout(() => {
        doctorOverlay.classList.add('is-active');
        doctorModal.classList.add('is-active');
    }, 10);
}

/**
 * 의료진 모달 닫기
 */
function closeDoctorModal() {
    doctorOverlay.classList.remove('is-active');
    doctorModal.classList.remove('is-active');

    // body 스크롤 복원
    setTimeout(() => {
        document.body.style.overflow = '';
    }, 400);
}

// ESC 키로 닫기
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && doctorModal.classList.contains('is-active')) {
        closeDoctorModal();
    }
});
</script>