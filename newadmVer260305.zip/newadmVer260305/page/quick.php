<!-- 
=====================================================
퀵메뉴 컴포넌트 4종 - tail.php에 복사/붙여넣기
=====================================================
1. 원형 토글형 (오른쪽 하단)
2. 막대 토글형 (오른쪽 하단 중간)
3. 막대 고정형 (오른쪽 하단)
4. 필 토글형 (왼쪽 하단)
===================================================== 
-->

<?php
// ═══════════════════════════════════════════════════
// 데이터 로드 (dm_config 테이블에서)
// ═══════════════════════════════════════════════════
$qm_conf = array();
if (function_exists('sql_fetch')) {
    $qm_result = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
    if (is_array($qm_result)) {
        $qm_conf = $qm_result;
    }
}

// ═══════════════════════════════════════════════════
// SVG 아이콘 정의
// ═══════════════════════════════════════════════════
$qm_svg = array(
    'naver' => '<svg viewBox="0 0 28 31" fill="none"><path d="M22.3275 2.52665L22.3275 1.65744C22.3275 0.739638 21.6864 -8.45462e-08 20.9013 -8.14853e-08C20.1161 -7.84244e-08 19.475 0.745037 19.475 1.65744L19.475 2.52665L8.52962 2.52665L8.52962 1.65744C8.52962 0.739638 7.8885 -3.0754e-08 7.10337 -2.76931e-08C6.31823 -2.46322e-08 5.67712 0.745037 5.67712 1.65744L5.67712 2.52665L-9.04374e-09 2.52665L-1.1096e-07 31L28 31L28 2.52665L22.3275 2.52665ZM25.5563 28.1602L2.44367 28.1602L2.44367 8.2062L25.5563 8.2062L25.5563 28.1602Z" fill="#1D2255"/><path d="M12.2088 17.7729L15.9393 24.0031L19.0288 24.0031L19.0288 12.3687L15.7907 12.3687L15.7907 18.5935L12.0601 12.3687L8.9707 12.3687L8.9707 24.0031L12.2088 24.0031L12.2088 17.7729Z" fill="#1D2255"/></svg>',
    
    'talk' => '<svg viewBox="0 0 34 31" fill="none"><path d="M12.9629 14.4842L14.8971 14.4842L13.9675 11.6378L12.9629 14.4842Z" fill="#1D2255"/><path d="M17 1.10083C8.16263 1.10083 1 6.64888 1 13.4925C1 17.9472 4.03595 21.8503 8.59098 24.0349C8.25647 25.2581 7.3788 28.4679 7.20327 29.1547C6.98689 30.0069 7.52232 29.995 7.87449 29.7668C8.14938 29.5873 12.2584 26.85 14.0314 25.6701C14.993 25.8096 15.9854 25.8832 17.0011 25.8832C25.8374 25.8832 33 20.3362 33 13.4925C33 6.64888 25.8363 1.10083 17 1.10083ZM9.1794 16.8538C9.1816 17.6152 7.44946 17.5763 7.44725 16.8138C7.45608 15.768 7.44725 11.2247 7.44725 11.2247L5.77914 11.2247C4.80322 11.2247 4.7999 9.54511 5.77914 9.54511L10.8497 9.54511C11.8864 9.54511 11.8853 11.2668 10.8486 11.2658C9.74905 11.2647 9.18933 11.3847 9.18933 11.3847L9.18161 16.8538L9.1794 16.8538ZM15.7635 17.082C15.3584 16.0351 15.4633 15.9886 15.4633 15.9886L12.4108 15.9886L12.0785 17.1307C11.7219 17.9321 10.1884 17.2788 10.5428 16.4775C11.0352 15.3679 12.5167 11.1879 12.9274 10.3022C13.0886 9.95175 13.4706 9.81116 13.8625 9.81116C14.3361 9.81116 14.8252 10.0166 14.9621 10.3022C15.2557 10.9197 16.8775 15.2813 17.3455 16.4926C17.6734 17.3416 16.0903 17.9288 15.7624 17.0809L15.7635 17.082ZM22.0176 17.4584C21.2338 17.4584 19.4663 17.4659 18.6703 17.4659C17.8744 17.4659 18.0068 16.5564 18.0068 16.5564C18.0068 16.5564 18.0024 11.9785 17.9991 10.5574C17.9969 10.0577 18.4495 9.80791 18.9022 9.80791C19.3548 9.80791 19.803 10.0556 19.8041 10.5531C19.8074 11.5826 19.7997 15.8178 19.7997 15.8178C19.7997 15.8178 21.2294 15.8253 22.0132 15.8253C22.797 15.8253 22.8014 17.4584 22.0176 17.4584ZM27.4735 17.3308L25.2732 14.3934L24.7709 14.7882C24.7709 14.7882 24.7709 16.2395 24.7709 17.0041C24.7709 17.6617 23.0598 17.6639 23.0586 17.0063C23.0586 16.5878 23.0951 10.9554 23.0796 10.3324C23.0697 9.9896 23.5201 9.81116 23.9595 9.81116C24.3713 9.81116 24.772 9.96581 24.7809 10.287C24.8051 11.1317 24.782 12.6598 24.782 12.6598C24.782 12.6598 27.2626 10.2275 27.6159 9.88361C27.9802 9.5278 29.1085 10.6407 28.7442 10.9965C28.1193 11.6043 26.5362 13.2838 26.5362 13.2838L28.8689 16.2947C29.3127 16.87 27.9151 17.9061 27.4724 17.3318L27.4735 17.3308Z" fill="#1D2255"/></svg>',
    
    'kakao' => '<svg viewBox="0 0 34 31" fill="none"><path d="M12.9629 14.4842L14.8971 14.4842L13.9675 11.6378L12.9629 14.4842Z" fill="#1D2255"/><path d="M17 1.10083C8.16263 1.10083 1 6.64888 1 13.4925C1 17.9472 4.03595 21.8503 8.59098 24.0349C8.25647 25.2581 7.3788 28.4679 7.20327 29.1547C6.98689 30.0069 7.52232 29.995 7.87449 29.7668C8.14938 29.5873 12.2584 26.85 14.0314 25.6701C14.993 25.8096 15.9854 25.8832 17.0011 25.8832C25.8374 25.8832 33 20.3362 33 13.4925C33 6.64888 25.8363 1.10083 17 1.10083ZM9.1794 16.8538C9.1816 17.6152 7.44946 17.5763 7.44725 16.8138C7.45608 15.768 7.44725 11.2247 7.44725 11.2247L5.77914 11.2247C4.80322 11.2247 4.7999 9.54511 5.77914 9.54511L10.8497 9.54511C11.8864 9.54511 11.8853 11.2668 10.8486 11.2658C9.74905 11.2647 9.18933 11.3847 9.18933 11.3847L9.18161 16.8538L9.1794 16.8538ZM15.7635 17.082C15.3584 16.0351 15.4633 15.9886 15.4633 15.9886L12.4108 15.9886L12.0785 17.1307C11.7219 17.9321 10.1884 17.2788 10.5428 16.4775C11.0352 15.3679 12.5167 11.1879 12.9274 10.3022C13.0886 9.95175 13.4706 9.81116 13.8625 9.81116C14.3361 9.81116 14.8252 10.0166 14.9621 10.3022C15.2557 10.9197 16.8775 15.2813 17.3455 16.4926C17.6734 17.3416 16.0903 17.9288 15.7624 17.0809L15.7635 17.082ZM22.0176 17.4584C21.2338 17.4584 19.4663 17.4659 18.6703 17.4659C17.8744 17.4659 18.0068 16.5564 18.0068 16.5564C18.0068 16.5564 18.0024 11.9785 17.9991 10.5574C17.9969 10.0577 18.4495 9.80791 18.9022 9.80791C19.3548 9.80791 19.803 10.0556 19.8041 10.5531C19.8074 11.5826 19.7997 15.8178 19.7997 15.8178C19.7997 15.8178 21.2294 15.8253 22.0132 15.8253C22.797 15.8253 22.8014 17.4584 22.0176 17.4584ZM27.4735 17.3308L25.2732 14.3934L24.7709 14.7882C24.7709 14.7882 24.7709 16.2395 24.7709 17.0041C24.7709 17.6617 23.0598 17.6639 23.0586 17.0063C23.0586 16.5878 23.0951 10.9554 23.0796 10.3324C23.0697 9.9896 23.5201 9.81116 23.9595 9.81116C24.3713 9.81116 24.772 9.96581 24.7809 10.287C24.8051 11.1317 24.782 12.6598 24.782 12.6598C24.782 12.6598 27.2626 10.2275 27.6159 9.88361C27.9802 9.5278 29.1085 10.6407 28.7442 10.9965C28.1193 11.6043 26.5362 13.2838 26.5362 13.2838L28.8689 16.2947C29.3127 16.87 27.9151 17.9061 27.4724 17.3318L27.4735 17.3308Z" fill="#1D2255"/></svg>',
    
    'blog' => '<svg viewBox="0 0 32 31" fill="none"><path d="M6.98404 11.5073C6.37514 11.5073 5.88281 12.0128 5.88281 12.6397C5.88281 13.2665 6.37514 13.7704 6.98404 13.7704C7.59294 13.7704 8.08527 13.2633 8.08527 12.6397C8.08527 12.016 7.5914 11.5073 6.98404 11.5073Z" fill="#1D2255"/><path d="M17.8692 11.3891C17.2143 11.3891 16.6836 11.9341 16.6836 12.6081C16.6836 13.2822 17.2143 13.8255 17.8692 13.8255C18.5241 13.8255 19.0563 13.2806 19.0563 12.6081C19.0563 11.9356 18.5241 11.3891 17.8692 11.3891Z" fill="#1D2255"/><path d="M27.7209 0.261204L4.28068 0.261204C1.91565 0.261204 -7.04078e-09 2.22826 -1.57332e-08 4.65677L-6.6862e-08 18.9412C-7.55545e-08 21.3697 1.91565 23.3367 4.28068 23.3367L12.5598 23.3367L15.3758 30.1482C15.3758 30.1482 15.569 30.7388 16.0384 30.7388C16.5077 30.7388 16.701 30.1482 16.701 30.1482L19.5169 23.3367L27.7194 23.3367C30.0844 23.3367 32.0001 21.3697 32.0001 18.9412L32.0001 4.65677C32.0001 2.22826 30.0829 0.261204 27.7194 0.261204L27.7209 0.261204ZM10.0537 12.8888C10.0399 15.5 7.41106 15.5756 7.41106 15.5756C6.39418 15.5756 5.82056 14.8826 5.82056 14.8826L5.82056 15.3535L3.90645 15.3535L3.90645 7.24434C3.90645 7.24434 3.89725 7.24119 3.90645 7.23962L3.90645 7.24434C4.02455 7.26324 5.82056 7.23962 5.82056 7.23962L5.82056 10.3406C6.27148 9.55315 7.57363 9.56575 7.57363 9.56575C10.4095 9.83664 10.0537 12.8888 10.0537 12.8888ZM13.4249 9.81459L13.4249 15.3677L11.5506 15.3677L11.5506 9.86971C11.5506 9.12163 10.6473 8.91532 10.6473 8.91532L10.6473 6.97661C13.6411 7.10102 13.4249 9.81459 13.4249 9.81459ZM17.8681 15.5787C16.1319 15.5787 14.727 14.248 14.727 12.61C14.727 10.9721 16.1335 9.6382 17.8681 9.6382C19.6028 9.6382 21.0092 10.969 21.0092 12.61C21.0092 14.2511 19.6028 15.5787 17.8681 15.5787ZM28.1366 15.5787C28.1366 15.5787 28.1642 18.3994 25.3727 18.3994L24.5231 18.3994L24.5231 16.5725L25.0353 16.5725C25.0353 16.5725 26.2086 16.6843 26.1948 14.8291C26.1948 14.8291 25.9663 15.5803 24.3206 15.5803C24.3206 15.5803 21.9878 15.4071 21.9878 13.0715L21.9878 12.1848C21.9878 12.1848 22.0415 9.76262 24.6028 9.56733C24.6028 9.56733 25.6135 9.45708 26.2347 10.3154L26.2347 9.72009L28.1366 9.72009L28.1366 15.5803L28.1366 15.5787Z" fill="#1D2255"/><path d="M25.1556 11.4175C24.5145 11.4175 23.9961 11.9513 23.9961 12.6097C23.9961 13.268 24.516 13.8003 25.1556 13.8003C25.7952 13.8003 26.3151 13.2664 26.3151 12.6097C26.3151 11.9529 25.7952 11.4175 25.1556 11.4175Z" fill="#1D2255"/></svg>',
    
    'location' => '<svg viewBox="0 0 28 32" fill="none"><path d="M14 -4.28844e-08C7.91857 -1.91754e-08 3 4.91857 3 11C3 19.25 14 31.4286 14 31.4286C14 31.4286 25 19.25 25 11C25 4.91857 20.0814 -6.65933e-08 14 -4.28844e-08ZM14 14.9286C11.8314 14.9286 10.0714 13.1686 10.0714 11C10.0714 8.83143 11.8314 7.07143 14 7.07143C16.1686 7.07143 17.9286 8.83143 17.9286 11C17.9286 13.1686 16.1686 14.9286 14 14.9286Z" fill="#1D2255"/></svg>',
    
    'chat' => '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-3 12H7c-.55 0-1-.45-1-1s.45-1 1-1h10c.55 0 1 .45 1 1s-.45 1-1 1zm0-3H7c-.55 0-1-.45-1-1s.45-1 1-1h10c.55 0 1 .45 1 1s-.45 1-1 1zm0-3H7c-.55 0-1-.45-1-1s.45-1 1-1h10c.55 0 1 .45 1 1s-.45 1-1 1z"/></svg>',
    
    'menu' => '<svg viewBox="0 0 24 26" fill="none"><path d="M8.51113 8.18283V0.0010376H0.000976562V12.6688H4.02518C6.49851 12.6688 8.51113 10.6562 8.51113 8.18283ZM1.58115 1.58223H6.92993V8.18384C6.92993 9.78625 5.62658 11.0896 4.02417 11.0896H1.58115V1.58324V1.58223Z" fill="white"/><path d="M10.2227 21.5143C10.2227 23.9876 12.2353 26.0002 14.7086 26.0002H23.829V17.4901H10.2227V21.5143ZM11.8039 19.0713H22.2488V24.4201H14.7096C13.1072 24.4201 11.8039 23.1167 11.8039 21.5143V19.0713Z" fill="white"/><path d="M11.8028 4.48695C11.8028 2.88454 13.1062 1.58119 14.7086 1.58119H18.6954V0H14.6045V0.00505204C12.1797 0.0616315 10.2227 2.04797 10.2227 4.48594V12.6677H11.8039V4.48594L11.8028 4.48695Z" fill="white"/><path d="M23.828 10.7361C23.828 7.90515 21.5254 5.60257 18.6944 5.60257C15.8635 5.60257 13.5609 7.90515 13.5609 10.7361C13.5609 12.1153 14.1105 13.3661 14.9976 14.2895H0V15.8707H18.6944C21.5254 15.8707 23.828 13.5681 23.828 10.7372V10.7361ZM15.1411 10.7361C15.1411 8.77708 16.7354 7.18275 18.6944 7.18275C20.6535 7.18275 22.2468 8.77607 22.2468 10.7361C22.2468 12.6962 20.6535 14.2895 18.6944 14.2895C16.7354 14.2895 15.1411 12.6952 15.1411 10.7361Z" fill="white"/></svg>',
    
    'up' => '<svg viewBox="0 0 15 31" fill="none"><path d="M8.07136 0.292891C7.68084 -0.0976334 7.04768 -0.0976334 6.65715 0.292891L0.29319 6.65685C-0.0973341 7.04738 -0.0973341 7.68054 0.29319 8.07107C0.683715 8.46159 1.31688 8.46159 1.7074 8.07107L7.36426 2.41421L13.0211 8.07107C13.4116 8.46159 14.0448 8.46159 14.4353 8.07107C14.8259 7.68054 14.8259 7.04738 14.4353 6.65685L8.07136 0.292891ZM7.36426 31L8.36426 31L8.36426 0.999998L7.36426 0.999998L6.36426 0.999998L6.36426 31L7.36426 31Z" fill="#1D2255"/></svg>',
    
    'upsmall' => '<svg viewBox="0 0 7 4" fill="none"><path d="M6.5 3.5L3.5 0.5L0.5 3.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"/></svg>'
);

// ═══════════════════════════════════════════════════
// 퀵메뉴 아이템 배열
// ═══════════════════════════════════════════════════

// 원형 퀵메뉴
$qm_circle = array(
    array('name' => '네이버 예약', 'url' => 'cf_naver_booking', 'icon' => 'naver', 'class' => 'naver'),
    array('name' => '네이버 톡톡', 'url' => 'cf_naver_talk', 'icon' => 'talk', 'class' => 'talk'),
    array('name' => '카카오톡', 'url' => 'cf_kakao', 'icon' => 'kakao', 'class' => 'kakao'),
    array('name' => '블로그', 'url' => 'cf_blog', 'icon' => 'blog', 'class' => 'blog')
);

// 막대형 퀵메뉴 (2번, 3번, 4번 공통)
$qm_bar = array(
    array('name' => '네이버 예약', 'url' => 'cf_naver_booking', 'icon' => 'naver', 'class' => 'naver'),
    array('name' => '카카오톡', 'url' => 'cf_kakao', 'icon' => 'talk', 'class' => 'talk'),
    array('name' => '블로그', 'url' => 'cf_blog', 'icon' => 'blog', 'class' => 'blog'),
    array('name' => '오시는 길', 'url' => 'cf_location', 'icon' => 'location', 'class' => 'location')
);
?>

<!-- ═══════════════════════════════════════════════════ -->
<!-- CSS/JS 라이브러리 로드 -->
<!-- ═══════════════════════════════════════════════════ -->
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="/css/setting.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

<style>
/* ═══════════════════════════════════════════════════
   공통 스타일
   ═══════════════════════════════════════════════════ */

body {
    background-color: #333;
}

.aspect-1-1 svg {
    width: 33%;
}


/* ═══════════════════════════════════════════════════
   1. 원형 토글형 퀵메뉴
   ═══════════════════════════════════════════════════ */

#quick_menu_circle {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 1050;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 12px;
}

/* 원형 아이템 컨테이너 */
.qm-circle-items {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 8px;
    opacity: 0;
    visibility: hidden;
    transform: translateY(20px) scale(0.9);
    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.qm-circle-items.active {
    opacity: 1;
    visibility: visible;
    transform: translateY(0) scale(1);
}

/* 원형 개별 아이템 */
.qm-circle-item {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
    text-decoration: none;
    border: none;
}

.qm-circle-item::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.05);
    transform: translate(-50%, -50%);
    transition: width 0.4s, height 0.4s;
}

.qm-circle-item:hover::before {
    width: 100%;
    height: 100%;
}

.qm-circle-item:hover {
    transform: translateY(-4px) scale(1.05);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.16);
}

.qm-circle-item:active {
    transform: translateY(-2px) scale(0.98);
}

.qm-circle-item svg {
    width: 28px;
    height: 28px;
    position: relative;
    z-index: 1;
    transition: transform 0.3s;
}

.qm-circle-item:hover svg {
    transform: scale(1.1);
}

/* 원형 아이템 브랜드별 컬러 */
.qm-circle-item.naver {
    background: linear-gradient(135deg, #00C73C 0%, #00A832 100%);
}
.qm-circle-item.naver svg {
    filter: brightness(0) invert(1);
}

.qm-circle-item.talk {
    background: linear-gradient(135deg, #00D664 0%, #00B854 100%);
}
.qm-circle-item.talk svg {
    filter: brightness(0) invert(1);
}

.qm-circle-item.kakao {
    background: linear-gradient(135deg, #FFE500 0%, #F0D600 100%);
}
.qm-circle-item.kakao svg {
    color: #3C1E1E;
}

.qm-circle-item.blog {
    background: linear-gradient(135deg, #00D664 0%, #00BD5A 100%);
}
.qm-circle-item.blog svg {
    filter: brightness(0) invert(1);
}

.qm-circle-item.inquiry {
    background: #fff;
}
.qm-circle-item.inquiry svg {
    color: #00C73C;
}

/* 원형 토글 버튼 */
.qm-circle-toggle {
    width: 64px;
    height: 64px;
    border-radius: 50%;
    background: linear-gradient(135deg, #00C73C 0%, #00A832 100%);
    border: none;
    box-shadow: 0 6px 20px rgba(0, 199, 60, 0.25);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    position: relative;
    overflow: hidden;
}

.qm-circle-toggle::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    transform: translate(-50%, -50%);
    transition: width 0.4s, height 0.4s;
}

.qm-circle-toggle:hover::before {
    width: 100%;
    height: 100%;
}

.qm-circle-toggle:hover {
    transform: scale(1.08);
    box-shadow: 0 8px 24px rgba(0, 199, 60, 0.25);
}

.qm-circle-toggle:active {
    transform: scale(0.95);
}

.qm-circle-toggle svg {
    width: 32px;
    height: 32px;
    color: #fff;
    position: relative;
    z-index: 1;
    transition: transform 0.3s;
}

.qm-circle-toggle.active svg {
    transform: rotate(45deg);
}

/* 원형 위로가기 버튼 */
.qm-top {
    width: 56px;
    height: 56px;
    border-radius: 50%;
    background: #fff;
    border: none;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    opacity: 0;
    visibility: hidden;
}

.qm-top:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.16);
}

.qm-top svg {
    width: 24px;
    height: 24px;
    color: #1E3A8A;
    transition: transform 0.3s;
}

.qm-top:hover svg {
    transform: translateY(-2px);
}

/* 원형 아이템 순차 애니메이션 */
.qm-circle-items.active .qm-circle-item:nth-child(1) {
    animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.05s forwards;
}
.qm-circle-items.active .qm-circle-item:nth-child(2) {
    animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.1s forwards;
}
.qm-circle-items.active .qm-circle-item:nth-child(3) {
    animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.15s forwards;
}
.qm-circle-items.active .qm-circle-item:nth-child(4) {
    animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.2s forwards;
}
.qm-circle-items.active .qm-circle-item:nth-child(5) {
    animation: slideIn 0.4s cubic-bezier(0.34, 1.56, 0.64, 1) 0.25s forwards;
}


/* ═══════════════════════════════════════════════════
   2. 막대형 토글 퀵메뉴
   ═══════════════════════════════════════════════════ */

#quick_menu_bar {
    position: fixed;
    bottom: 24px;
    right: 120px;
    z-index: 1050;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.qm-bar-wrapper {
    background: transparent;
    border-radius: 50px;
    padding: 25px 5px 8px 5px;
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.qm-bar-wrapper.active {
    background: #fff;
    height: auto;
    padding: 25px 5px 8px 5px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
}

.qm-bar-items {
    opacity: 0;
    visibility: hidden;
    max-height: 0;
    transition: all 0.3s ease;
    padding: 0 8px;
}

.qm-bar-wrapper.active .qm-bar-items {
    opacity: 1;
    visibility: visible;
    max-height: 500px;
    padding: 8px;
}

.qm-bar-item {
    width: 100%;
    height: 60px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    border: none;
    background: transparent;
    border-radius: 12px;
    margin-top: 8px;
    position: relative;
}

.qm-bar-item:last-child {
    margin-bottom: 0;
}

.qm-bar-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.03);
    border-radius: 12px;
    opacity: 0;
    transition: opacity 0.3s;
}

.qm-bar-item:hover::before {
    opacity: 1;
}

.qm-bar-item:hover {
    transform: scale(1.05);
}

.qm-bar-item svg {
    width: 51px;
    height: 51px;
    margin-bottom: 4px;
    transition: transform 0.3s;
}

.qm-bar-item:hover svg {
    transform: scale(1.1);
}

.qm-bar-item-text {
    font-size: 14px;
    font-weight: 500;
    color: var(--blue);
    text-align: center;
    line-height: 1.4;
}

/* 막대형 아이템 브랜드별 컬러 */
.qm-bar-item.naver svg {
    color: #00C73C;
}
.qm-bar-item.talk svg {
    color: #00D664;
}
.qm-bar-item.blog svg {
    color: #00BD5A;
}
.qm-bar-item.location svg {
    color: #FF6B6B;
}

/* 막대형 토글 버튼 */
.qm-bar-toggle {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: var(--blue);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
    margin: 8px auto;
    position: relative;
    overflow: hidden;
}

.qm-bar-toggle:active {
    width: 50px;
    height: 50px;
}

.qm-bar-toggle svg {
    width: 75%;
    color: #fff;
    transition: transform 0.3s;
}


/* ═══════════════════════════════════════════════════
   3. 막대형 고정 퀵메뉴
   ═══════════════════════════════════════════════════ */

#quick_menu_bar_fixed {
    position: fixed;
    bottom: 24px;
    right: 220px;
    z-index: 1050;
}

.qm-bar-fixed-container {
    background: #fff;
    border-radius: 5px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
    overflow: hidden;
    width: 100px;
}

.qm-bar-fixed-items {
    padding: 25px 5px;
}

.qm-bar-fixed-item {
    width: 50px;
    margin: 0 auto;
    padding: 12px 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    border: none;
    background: transparent;
    position: relative;
    border-bottom: 1px solid #f0f0f0;
}

.qm-bar-fixed-item:last-child {
    border-bottom: none;
}

.qm-bar-fixed-item::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.03);
    opacity: 0;
    transition: opacity 0.3s;
}

.qm-bar-fixed-item:hover::before {
    opacity: 1;
}

.qm-bar-fixed-item:hover {
    transform: scale(1.02);
}

.qm-bar-fixed-item-text {
    font-size: 14px;
    white-space: nowrap;
    margin-top: 6px;
    color: var(--main-color);
    font-weight: 500;
}

/* 막대형 고정 로고 */
.qm-bar-fixed-logo {
    width: 48px;
    height: 48px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 6px;
    transition: transform 0.3s;
    background: #fff;
    border-radius: 8px;
}

.qm-bar-fixed-item:hover .qm-bar-fixed-logo {
    transform: scale(1.05);
}

.qm-bar-fixed-item.naver .qm-bar-fixed-logo {
    background: #fff;
    border: 2px solid #00C73C;
}
.qm-bar-fixed-item.naver .qm-bar-fixed-logo::before {
    content: 'N';
    font-size: 24px;
    font-weight: 900;
    color: #00C73C;
    font-family: sans-serif;
}

.qm-bar-fixed-item.talk .qm-bar-fixed-logo {
    background: #FFE500;
}
.qm-bar-fixed-item.talk .qm-bar-fixed-logo svg {
    width: 28px;
    height: 28px;
    fill: #3C1E1E;
}

.qm-bar-fixed-item.blog .qm-bar-fixed-logo {
    background: #1EC545;
    border-radius: 50%;
}
.qm-bar-fixed-item.blog .qm-bar-fixed-logo::before {
    content: 'blog';
    font-size: 11px;
    font-weight: 700;
    color: #fff;
    font-family: sans-serif;
    letter-spacing: -0.5px;
}

.qm-bar-fixed-item.location .qm-bar-fixed-logo {
    background: #fff;
    border: 2px solid #1E3A8A;
}
.qm-bar-fixed-item.location .qm-bar-fixed-logo svg {
    width: 28px;
    height: 28px;
    fill: #1E3A8A;
}

/* 막대형 고정 TOP 버튼 */
.qm-bar-fixed-top {
    width: 100px;
    height: 100px;
    background: var(--main-color);
    border: none;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
    margin: 0;
    border-radius: 5px;
}

.qm-bar-fixed-top:hover {
    background: #152D6E;
}

.qm-bar-fixed-top svg {
    width: 12px;
    height: 8px;
    color: #fff;
    margin-bottom: 2px;
}

.qm-bar-fixed-top-text {
    font-size: 14px;
    font-weight: 600;
    color: #fff;
    letter-spacing: 0.5px;
}


/* ═══════════════════════════════════════════════════
   4. 필형 토글 퀵메뉴
   ═══════════════════════════════════════════════════ */

#quick_menu_pill {
    position: fixed;
    bottom: 48px;
    left: 20px;
    z-index: 1050;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.quick_menu_pill-container {
    margin-bottom: 17px;
}

/* ★ 수정: 토글 애니메이션 추가 */
.quick_menu_pill-items {
    width: 150px;
    display: flex;
    flex-direction: column;
    gap: 13px;
    
    /* 토글 애니메이션 */
    opacity: 0;
    visibility: hidden;
    max-height: 0;
    overflow: hidden;
    transition: opacity 0.3s ease, max-height 0.3s ease, visibility 0.3s;
}

.quick_menu_pill-items.active {
    opacity: 1;
    visibility: visible;
    max-height: 500px;
}

.quick_menu_pill-items svg {
    width: 20px;
}

.quick_menu_pill-items a {
    background-color: #fff;
    width: 100%;
    border-radius: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 5px;
    flex-direction: row;
    padding: 12px 16px;
    text-decoration: none;
    transition: transform 0.2s, box-shadow 0.2s;
}

.quick_menu_pill-items a:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.quick_menu_pill-items a div {
    font-weight: 500;
    font-size: 14px;
    letter-spacing: -0.025em;
    line-height: 1.4;
    color: #333;
}

/* 필형 토글 버튼 */
.qm-pill-toggle {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: var(--blue);
    border: none;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 8px auto;
    position: relative;
    overflow: hidden;
    margin-top: 17px;
    cursor: pointer;
    transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.qm-pill-toggle svg {
    width: 75%;
    color: #fff;
    transition: transform 0.3s;
}

.qm-pill-toggle.active svg {
    transform: rotate(45deg);
}

.qm-pill-toggle:active {
    width: 50px;
    height: 50px;
}


/* ═══════════════════════════════════════════════════
   공통 애니메이션 & 툴팁
   ═══════════════════════════════════════════════════ */

@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateX(20px);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

/* 툴팁 */
.qm-tip {
    position: absolute;
    right: calc(100% + 12px);
    top: 50%;
    transform: translateY(-50%);
    background: rgba(0, 0, 0, 0.85);
    color: #fff;
    padding: 6px 12px;
    border-radius: 6px;
    font-size: 13px;
    white-space: nowrap;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s;
    pointer-events: none;
    font-weight: 500;
}

.qm-circle-item:hover .qm-tip {
    opacity: 1;
    visibility: visible;
    right: calc(100% + 16px);
}

.qm-tip::after {
    content: '';
    position: absolute;
    right: -6px;
    top: 50%;
    transform: translateY(-50%);
    width: 0;
    height: 0;
    border-left: 6px solid rgba(0, 0, 0, 0.85);
    border-top: 6px solid transparent;
    border-bottom: 6px solid transparent;
}
</style>


<!-- ═══════════════════════════════════════════════════ -->
<!-- HTML 마크업 -->
<!-- ═══════════════════════════════════════════════════ -->

<!-- 1. 원형 토글형 퀵메뉴 -->
<div id="quick_menu_circle">
    <div class="qm-circle-items">
        <?php foreach ($qm_circle as $item):
            $href = !empty($qm_conf[$item['url']]) ? htmlspecialchars($qm_conf[$item['url']]) : '#';
            $has = !empty($qm_conf[$item['url']]) ? '1' : '0';
        ?>
            <a href="<?php echo $href; ?>" target="_blank" class="qm-circle-item <?php echo $item['class']; ?>" data-has="<?php echo $has; ?>">
                <?php echo $qm_svg[$item['icon']]; ?>
                <span class="qm-tip"><?php echo $item['name']; ?></span>
            </a>
        <?php endforeach; ?>

        <button type="button" class="qm-circle-item inquiry" data-bs-toggle="modal" data-bs-target="#inquiryModal">
            <?php echo $qm_svg['chat']; ?>
            <span class="qm-tip">빠른 상담</span>
        </button>
    </div>

    <button type="button" id="qm_circle_toggle" class="qm-circle-toggle">
        <?php echo $qm_svg['menu']; ?>
    </button>

    <button type="button" id="qm_top" class="qm-top">
        <?php echo $qm_svg['up']; ?>
    </button>
</div>


<!-- 2. 막대형 토글 퀵메뉴 -->
<div id="quick_menu_bar" class="u-pretendard">
    <div class="qm-bar-wrapper">
        <div class="qm-bar-items d-flex flex-column u-gap-20">
            <?php foreach ($qm_bar as $item):
                $href = !empty($qm_conf[$item['url']]) ? htmlspecialchars($qm_conf[$item['url']]) : '#';
                $has = !empty($qm_conf[$item['url']]) ? '1' : '0';
            ?>
                <a href="<?php echo $href; ?>" target="_blank" class="qm-bar-item <?php echo $item['class']; ?>" data-has="<?php echo $has; ?>">
                    <?php echo $qm_svg[$item['icon']]; ?>
                    <div class="qm-bar-item-text"><?php echo $item['name']; ?></div>
                </a>
            <?php endforeach; ?>
        </div>

        <button type="button" id="qm_bar_toggle" class="qm-bar-toggle">
            <?php echo $qm_svg['menu']; ?>
        </button>
    </div>
    
    <button type="button" class="u-bg-white aspect-1-1 rounded-full u-bd-n shadow-sm u-mt-20" id="qm_bar_top" style="width: 60px; height: 60px">
        <?php echo $qm_svg['up']; ?>
    </button>
</div>


<!-- 3. 막대형 고정 퀵메뉴 -->
<div id="quick_menu_bar_fixed" class="u-pretendard">
    <div class="qm-bar-fixed-container">
        <div class="qm-bar-fixed-items">
            <?php foreach ($qm_bar as $item):
                $href = !empty($qm_conf[$item['url']]) ? htmlspecialchars($qm_conf[$item['url']]) : '#';
                $has = !empty($qm_conf[$item['url']]) ? '1' : '0';
            ?>
                <a href="<?php echo $href; ?>" target="_blank" class="qm-bar-fixed-item <?php echo $item['class']; ?>" data-has="<?php echo $has; ?>">
                    <?php echo $qm_svg[$item['icon']]; ?>
                    <div class="qm-bar-fixed-item-text"><?php echo $item['name']; ?></div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <button type="button" id="qm_bar_fixed_top" class="qm-bar-fixed-top">
        <?php echo $qm_svg['upsmall']; ?>
        <div class="qm-bar-fixed-top-text">TOP</div>
    </button>
</div>


<!-- 4. 필형 토글 퀵메뉴 -->
<div id="quick_menu_pill" class="u-pretendard">
    <div class="quick_menu_pill-container">
        <div class="quick_menu_pill-items">
            <?php foreach ($qm_bar as $item):
                $href = !empty($qm_conf[$item['url']]) ? htmlspecialchars($qm_conf[$item['url']]) : '#';
                $has = !empty($qm_conf[$item['url']]) ? '1' : '0';
            ?>
                <a href="<?php echo $href; ?>" target="_blank" class="qm-bar-fixed-item <?php echo $item['class']; ?>" data-has="<?php echo $has; ?>">
                    <?php echo $qm_svg[$item['icon']]; ?>
                    <div class="qm-bar-fixed-item-text"><?php echo $item['name']; ?></div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>

    <button type="button" id="qm_pill_toggle" class="qm-pill-toggle">
        <?php echo $qm_svg['menu']; ?>
    </button>

    <button type="button" class="u-bg-white aspect-1-1 rounded-full u-bd-n shadow-sm u-mt-20" id="qm_pill_top" style="width: 60px; height: 60px">
        <?php echo $qm_svg['up']; ?>
    </button>
</div>


<!-- ═══════════════════════════════════════════════════ -->
<!-- JavaScript -->
<!-- ═══════════════════════════════════════════════════ -->
<script>
(function() {
    'use strict';

    // ══════════════════════════════════════════════
    // 1. 원형 토글형 퀵메뉴
    // ══════════════════════════════════════════════
    var circleItems = document.querySelector('.qm-circle-items');
    var circleToggle = document.getElementById('qm_circle_toggle');
    var circleTop = document.getElementById('qm_top');

    if (circleToggle) {
        circleToggle.onclick = function() {
            circleItems.classList.toggle('active');
            circleToggle.classList.toggle('active');
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'circle_toggle'
                });
            }
        };
    }

    if (circleTop) {
        circleTop.onclick = function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'circle_top'
                });
            }
        };

        // 스크롤 시 TOP 버튼 표시/숨김
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                circleTop.style.opacity = '1';
                circleTop.style.visibility = 'visible';
            } else {
                circleTop.style.opacity = '0';
                circleTop.style.visibility = 'hidden';
            }
        });
    }


    // ══════════════════════════════════════════════
    // 2. 막대형 토글 퀵메뉴
    // ══════════════════════════════════════════════
    var barWrapper = document.querySelector('.qm-bar-wrapper');
    var barToggle = document.getElementById('qm_bar_toggle');
    var barTop = document.getElementById('qm_bar_top');

    if (barToggle) {
        barToggle.onclick = function() {
            barWrapper.classList.toggle('active');
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'bar_toggle'
                });
            }
        };
    }

    if (barTop) {
        barTop.onclick = function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'bar_top'
                });
            }
        };
    }


    // ══════════════════════════════════════════════
    // 3. 막대형 고정 퀵메뉴
    // ══════════════════════════════════════════════
    var barFixedTop = document.getElementById('qm_bar_fixed_top');

    if (barFixedTop) {
        barFixedTop.onclick = function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'bar_fixed_top'
                });
            }
        };
    }


    // ══════════════════════════════════════════════
    // 4. 필형 토글 퀵메뉴 (★ 수정됨)
    // ══════════════════════════════════════════════
    var pillItems = document.querySelector('.quick_menu_pill-items');
    var pillToggle = document.getElementById('qm_pill_toggle');
    var pillTop = document.getElementById('qm_pill_top');

    if (pillToggle) {
        pillToggle.onclick = function() {
            pillItems.classList.toggle('active');
            pillToggle.classList.toggle('active');
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'pill_toggle'
                });
            }
        };
    }

    if (pillTop) {
        pillTop.onclick = function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            if (typeof gtag !== 'undefined') {
                gtag('event', 'click_quick_menu', {
                    event_category: 'engagement',
                    event_label: 'pill_top'
                });
            }
        };
    }


    // ══════════════════════════════════════════════
    // 공통: 링크 체크 (URL 없으면 알림)
    // ══════════════════════════════════════════════
    var allLinks = document.querySelectorAll('.qm-circle-item, .qm-bar-item, .qm-bar-fixed-item');
    
    for (var i = 0; i < allLinks.length; i++) {
        allLinks[i].onclick = function(e) {
            var has = this.getAttribute('data-has');
            if (has === '0' && this.href && this.href.indexOf('#') !== -1) {
                e.preventDefault();
                alert('링크가 설정되지 않았습니다.');
                return false;
            }
        };
    }


    // ══════════════════════════════════════════════
    // 공통: 외부 클릭 시 메뉴 닫기
    // ══════════════════════════════════════════════
    document.addEventListener('click', function(e) {
        var circleMenu = document.getElementById('quick_menu_circle');
        var barMenu = document.getElementById('quick_menu_bar');
        var pillMenu = document.getElementById('quick_menu_pill');

        // 원형 메뉴 외부 클릭
        if (circleMenu && !circleMenu.contains(e.target) && circleItems && circleItems.classList.contains('active')) {
            circleItems.classList.remove('active');
            circleToggle.classList.remove('active');
        }

        // 막대형 토글 메뉴 외부 클릭
        if (barMenu && !barMenu.contains(e.target) && barWrapper && barWrapper.classList.contains('active')) {
            barWrapper.classList.remove('active');
        }

        // 필형 토글 메뉴 외부 클릭 (★ 추가)
        if (pillMenu && !pillMenu.contains(e.target) && pillItems && pillItems.classList.contains('active')) {
            pillItems.classList.remove('active');
            pillToggle.classList.remove('active');
        }
    });

})();
</script>

<!-- 퀵메뉴 끝 -->