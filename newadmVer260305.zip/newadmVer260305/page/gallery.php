<?php
/**
 * Gallery Templates Module
 * 병원 홈페이지용 갤러리 템플릿 모음
 */

/**
 * 기본 Swiper 슬라이드
 * @param array $images - 이미지 배열 [['src' => '경로', 'alt' => '설명'], ...]
 * @param string $id - 고유 ID (기본값: 'swiperBasic')
 */
function gallery_swiper_basic($images, $id = 'swiperBasic') {
    $html = '<div class="gallery-swiper-basic" id="' . $id . '">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    
    foreach ($images as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    $html .= '<div class="swiper-pagination"></div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    return $html;
}

/**
 * 썸네일 네비게이션 Swiper
 * @param array $images - 이미지 배열
 * @param string $id - 고유 ID (기본값: 'swiperThumbnail')
 */
function gallery_swiper_thumbnail($images, $id = 'swiperThumbnail') {
    $html = '<div class="gallery-swiper-thumbnail" id="' . $id . '">';
    
    // 메인 스와이퍼
    $html .= '<div class="swiper swiper-main">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($images as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '</div>';
    
    // 썸네일 스와이퍼
    $html .= '<div class="swiper swiper-thumbs">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($images as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 핀터레스트형 Masonry 그리드
 * @param array $images - 이미지 배열
 * @param string $id - 고유 ID (기본값: 'gridMasonry')
 */
function gallery_grid_masonry($images, $id = 'gridMasonry') {
    $html = '<div class="gallery-grid-masonry" id="' . $id . '">';
    
    foreach ($images as $img) {
        $html .= '<div class="masonry-item">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    
    $html .= '</div>';
    return $html;
}

/**
 * 3x3 그리드
 * @param array $images - 이미지 배열 (최대 9개)
 * @param string $id - 고유 ID (기본값: 'grid3x3')
 */
function gallery_grid_3x3($images, $id = 'grid3x3') {
    $html = '<div class="gallery-grid-3x3" id="' . $id . '">';
    
    $count = 0;
    foreach ($images as $img) {
        if ($count >= 9) break;
        $html .= '<div class="grid-item">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
        $count++;
    }
    
    $html .= '</div>';
    return $html;
}

/**
 * 4x4 그리드
 * @param array $images - 이미지 배열 (최대 16개)
 * @param string $id - 고유 ID (기본값: 'grid4x4')
 */
function gallery_grid_4x4($images, $id = 'grid4x4') {
    $html = '<div class="gallery-grid-4x4" id="' . $id . '">';
    
    $count = 0;
    foreach ($images as $img) {
        if ($count >= 16) break;
        $html .= '<div class="grid-item">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
        $count++;
    }
    
    $html .= '</div>';
    return $html;
}

/**
 * 좌측 제목 + 우측 슬라이드
 * @param array $data - ['title' => '제목', 'description' => '설명', 'images' => [이미지 배열]]
 * @param string $id - 고유 ID (기본값: 'swiperLeftTitle')
 */
function gallery_swiper_left_title($data, $id = 'swiperLeftTitle') {
    $html = '<div class="gallery-swiper-left-title" id="' . $id . '">';
    
    // 좌측 텍스트 영역
    $html .= '<div class="text-area">';
    $html .= '<h2>' . htmlspecialchars($data['title']) . '</h2>';
    if (isset($data['description'])) {
        $html .= '<p>' . htmlspecialchars($data['description']) . '</p>';
    }
    $html .= '</div>';
    
    // 우측 스와이퍼
    $html .= '<div class="swiper-area">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-pagination"></div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 우측 제목 + 좌측 슬라이드
 * @param array $data - ['title' => '제목', 'description' => '설명', 'images' => [이미지 배열]]
 * @param string $id - 고유 ID (기본값: 'swiperRightTitle')
 */
function gallery_swiper_right_title($data, $id = 'swiperRightTitle') {
    $html = '<div class="gallery-swiper-right-title" id="' . $id . '">';
    
    // 좌측 스와이퍼
    $html .= '<div class="swiper-area">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-pagination"></div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    // 우측 텍스트 영역
    $html .= '<div class="text-area">';
    $html .= '<h2>' . htmlspecialchars($data['title']) . '</h2>';
    if (isset($data['description'])) {
        $html .= '<p>' . htmlspecialchars($data['description']) . '</p>';
    }
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 텍스트 페이지네이션 (상단) - 이미지 위에 텍스트 불렛
 * @param array $data - ['images' => [['src' => '', 'alt' => '', 'title' => ''], ...]]
 * @param string $id - 고유 ID (기본값: 'swiperTextPaginationTop')
 */
function gallery_swiper_text_pagination_top($data, $id = 'swiperTextPaginationTop') {
    $html = '<div class="gallery-swiper-text-pagination-top" id="' . $id . '">';
    
    // 텍스트 페이지네이션 (상단)
    $html .= '<div class="text-pagination-top">';
    foreach ($data['images'] as $index => $img) {
        $active = $index === 0 ? 'active' : '';
        $title = isset($img['title']) ? htmlspecialchars($img['title']) : 'Step ' . ($index + 1);
        $html .= '<div class="text-bullet ' . $active . '" data-index="' . $index . '">';
        $html .= '<span class="bullet-number">' . ($index + 1) . '</span>';
        $html .= '<span class="bullet-text">' . $title . '</span>';
        $html .= '</div>';
    }
    $html .= '</div>';
    
    // 스와이퍼
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 텍스트 페이지네이션 (하단) - 이미지 아래에 텍스트 불렛
 * @param array $data - ['images' => [['src' => '', 'alt' => '', 'title' => ''], ...]]
 * @param string $id - 고유 ID (기본값: 'swiperTextPaginationBottom')
 */
function gallery_swiper_text_pagination_bottom($data, $id = 'swiperTextPaginationBottom') {
    $html = '<div class="gallery-swiper-text-pagination-bottom" id="' . $id . '">';
    
    // 스와이퍼
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    
    // 텍스트 페이지네이션 (하단)
    $html .= '<div class="text-pagination-bottom">';
    foreach ($data['images'] as $index => $img) {
        $active = $index === 0 ? 'active' : '';
        $title = isset($img['title']) ? htmlspecialchars($img['title']) : 'Step ' . ($index + 1);
        $html .= '<div class="text-bullet ' . $active . '" data-index="' . $index . '">';
        $html .= '<span class="bullet-number">' . ($index + 1) . '</span>';
        $html .= '<span class="bullet-text">' . $title . '</span>';
        $html .= '</div>';
    }
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 썸네일 + 텍스트 - 썸네일에 제목 추가
 * @param array $data - ['images' => [['src' => '', 'alt' => '', 'title' => '', 'desc' => ''], ...]]
 * @param string $id - 고유 ID (기본값: 'swiperThumbnailText')
 */
function gallery_swiper_thumbnail_text($data, $id = 'swiperThumbnailText') {
    $html = '<div class="gallery-swiper-thumbnail-text" id="' . $id . '">';
    
    // 메인 스와이퍼
    $html .= '<div class="swiper swiper-main">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        if (isset($img['desc'])) {
            $html .= '<div class="slide-caption">' . htmlspecialchars($img['desc']) . '</div>';
        }
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '</div>';
    
    // 썸네일 스와이퍼 with 텍스트
    $html .= '<div class="swiper swiper-thumbs-text">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        if (isset($img['title'])) {
            $html .= '<div class="thumb-title">' . htmlspecialchars($img['title']) . '</div>';
        }
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 이미지 캡션형 - 각 슬라이드마다 하단에 설명
 * @param array $data - ['images' => [['src' => '', 'alt' => '', 'caption' => ''], ...]]
 * @param string $id - 고유 ID (기본값: 'swiperCaption')
 */
function gallery_swiper_caption($data, $id = 'swiperCaption') {
    $html = '<div class="gallery-swiper-caption" id="' . $id . '">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<div class="slide-image">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
        if (isset($img['caption'])) {
            $html .= '<div class="slide-caption-text">' . htmlspecialchars($img['caption']) . '</div>';
        }
        $html .= '</div>';
    }
    
    $html .= '</div>';
    $html .= '<div class="swiper-pagination"></div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    return $html;
}

/**
 * 텍스트 페이지네이션 (10개) - 많은 단계용
 * @param array $data - ['images' => [['src' => '', 'alt' => '', 'title' => ''], ...]]
 * @param string $id - 고유 ID (기본값: 'swiperTextPagination10')
 */
function gallery_swiper_text_pagination_10($data, $id = 'swiperTextPagination10') {
    $html = '<div class="gallery-swiper-text-pagination-top" id="' . $id . '">';
    
    // 텍스트 페이지네이션
    $html .= '<div class="text-pagination-top">';
    foreach ($data['images'] as $index => $img) {
        $active = $index === 0 ? 'active' : '';
        $title = isset($img['title']) ? htmlspecialchars($img['title']) : 'Step ' . ($index + 1);
        $html .= '<div class="text-bullet ' . $active . '" data-index="' . $index . '">';
        $html .= '<span class="bullet-number">' . ($index + 1) . '</span>';
        $html .= '<span class="bullet-text">' . $title . '</span>';
        $html .= '</div>';
    }
    $html .= '</div>';
    
    // 스와이퍼
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 좌측 제목 + 우측 멀티 슬라이드 (2-3개씩 보임)
 * @param array $data - ['title' => '제목', 'description' => '설명', 'images' => [이미지 배열]]
 * @param string $id - 고유 ID
 * @param int $slidesPerView - 한번에 보일 슬라이드 수 (기본값: 2)
 */
function gallery_swiper_left_title_multi($data, $id = 'swiperLeftTitleMulti', $slidesPerView = 2) {
    $html = '<div class="gallery-swiper-left-title" id="' . $id . '">';
    
    // 좌측 텍스트 영역
    $html .= '<div class="text-area">';
    $html .= '<h2>' . htmlspecialchars($data['title']) . '</h2>';
    if (isset($data['description'])) {
        $html .= '<p>' . htmlspecialchars($data['description']) . '</p>';
    }
    $html .= '</div>';
    
    // 우측 스와이퍼 (멀티)
    $html .= '<div class="swiper-area">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}

/**
 * 우측 제목 + 좌측 멀티 슬라이드 (2-3개씩 보임)
 * @param array $data - ['title' => '제목', 'description' => '설명', 'images' => [이미지 배열]]
 * @param string $id - 고유 ID
 * @param int $slidesPerView - 한번에 보일 슬라이드 수 (기본값: 2)
 */
function gallery_swiper_right_title_multi($data, $id = 'swiperRightTitleMulti', $slidesPerView = 2) {
    $html = '<div class="gallery-swiper-right-title" id="' . $id . '">';
    
    // 좌측 스와이퍼 (멀티)
    $html .= '<div class="swiper-area">';
    $html .= '<div class="swiper">';
    $html .= '<div class="swiper-wrapper">';
    foreach ($data['images'] as $img) {
        $html .= '<div class="swiper-slide">';
        $html .= '<img src="' . htmlspecialchars($img['src']) . '" alt="' . htmlspecialchars($img['alt']) . '">';
        $html .= '</div>';
    }
    $html .= '</div>';
    $html .= '<div class="swiper-button-prev"></div>';
    $html .= '<div class="swiper-button-next"></div>';
    $html .= '</div>';
    $html .= '</div>';
    
    // 우측 텍스트 영역
    $html .= '<div class="text-area">';
    $html .= '<h2>' . htmlspecialchars($data['title']) . '</h2>';
    if (isset($data['description'])) {
        $html .= '<p>' . htmlspecialchars($data['description']) . '</p>';
    }
    $html .= '</div>';
    
    $html .= '</div>';
    return $html;
}
?>