<?php
/**
 * ============================================
 * 재사용 가능한 배너 컴포넌트
 * ============================================
 * 
 * 사용법:
 * <?php
 * include_once('./components/banner_component.php');
 * render_banner(1);  // ID 1번 배너 출력
 * render_banner();   // 메인 배너 출력
 * ?>
 */

/**
 * 배너 렌더링 함수
 * @param int|null $banner_id 배너 ID (null이면 메인 배너 사용)
 * @param array $options 추가 옵션
 */
function render_banner($banner_id = null, $options = []) {
    // 기본 옵션
    $defaults = [
        'section_id' => 'banner-' . ($banner_id ?? 'main'),
        'section_class' => 'hero-section',
        'container_class' => '',
        'enable_ga4' => true,
        'show_text' => true,
        'autoplay' => true
    ];
    
    $opts = array_merge($defaults, $options);
    
    // 배너 데이터 가져오기
    if ($banner_id) {
        // 특정 ID의 배너
        $banner_row = sql_fetch("SELECT * FROM mainbanner WHERE id = '$banner_id'");
    } else {
        // 메인 배너
        $banner_row = sql_fetch("SELECT * FROM mainbanner WHERE is_main = 1");
        
        // 메인 배너가 없으면 첫 번째 배너 사용
        if (!$banner_row) {
            $banner_row = sql_fetch("SELECT * FROM mainbanner ORDER BY id ASC LIMIT 1");
        }
    }
    
    if (!$banner_row) {
        echo '<!-- 배너 없음: ID ' . ($banner_id ?? 'main') . ' -->';
        return;
    }
    
    $banner_id = $banner_row['id'];
    $banner_images = $banner_row['images'] ? json_decode($banner_row['images'], true) : [];
    $banner_settings = $banner_row['settings'] ? json_decode($banner_row['settings'], true) : [
        'autoplay_delay' => 3000,
        'effect' => 'slide',
        'loop' => 1,
        'speed' => 600
    ];
    
    // autoplay 옵션 적용
    if (!$opts['autoplay']) {
        $banner_settings['autoplay_delay'] = 0;
    }
    
    // 배너가 비어있으면 기본 이미지
    if (empty($banner_images)) {
        $banner_images = [[
            'src' => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920',
            'visible' => true,
            'link' => '',
            'text_settings' => [
                'title' => 'Welcome',
                'description' => 'Please add banners in admin panel',
                'button_text' => '',
                'button_link' => '',
                'text_color' => '#ffffff',
                'text_position' => 'center'
            ]
        ]];
    }
    
    // HTML 출력 시작
    $swiper_id = 'swiper-' . $banner_id . '-' . rand(1000, 9999);
    ?>
    
    <!-- ✨ 배너 컴포넌트 (ID: <?= $banner_id ?>) -->
    <section id="<?= $opts['section_id'] ?>" class="<?= $opts['section_class'] ?>">
        <div class="swiper <?= $swiper_id ?> h-100 <?= $opts['container_class'] ?>">
            <div class="swiper-wrapper">
                <?php foreach ($banner_images as $index => $img):
                    if (isset($img['visible']) && !$img['visible']) continue;
                    
                    // 노출 기간 체크
                    $now = time();
                    if (isset($img['start_date']) && $img['start_date']) {
                        if (strtotime($img['start_date']) > $now) continue;
                    }
                    if (isset($img['end_date']) && $img['end_date']) {
                        if (strtotime($img['end_date'] . ' 23:59:59') < $now) continue;
                    }
                    
                    $text = isset($img['text_settings']) ? $img['text_settings'] : [
                        'title' => '',
                        'description' => '',
                        'button_text' => '',
                        'button_link' => '',
                        'text_color' => '#ffffff',
                        'text_position' => 'center'
                    ];
                    
                    $align_class = $text['text_position'] == 'left' ? 'text-start' : 
                                   ($text['text_position'] == 'right' ? 'text-end' : 'text-center');
                ?>
                    <div class="swiper-slide g-center" style="background: #111;">
                        <img src="<?= htmlspecialchars($img['src']) ?>" alt="배너" class="slide-bg-img obj-cover">
                        
                        <?php if ($opts['show_text'] && ($text['title'] || $text['description'] || $text['button_text'])): ?>
                        <div class="slide-content u-mx-auto <?= $align_class ?>" style="color: <?= htmlspecialchars($text['text_color']) ?>;">
                            <?php if ($text['title']): ?>
                                <h1 class="t-fs-60 u-mb-24 keep-all" data-aos="fade-up">
                                    <?= $text['title'] ?>
                                </h1>
                            <?php endif; ?>
                            
                            <?php if ($text['description']): ?>
                                <p class="c-fs-20 u-mb-32" style="color: <?= htmlspecialchars($text['text_color']) ?>; opacity: 0.9;">
                                    <?= htmlspecialchars($text['description']) ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if ($text['button_text'] && $text['button_link']): ?>
                                <a href="<?= htmlspecialchars($text['button_link']) ?>" 
                                   class="u-btn u-btn-main u-p-16 fw-bold rounded-full banner-cta-btn"
                                   data-banner-id="<?= $banner_id ?>"
                                   data-banner-index="<?= $index ?>"
                                   data-banner-title="<?= htmlspecialchars(strip_tags(str_replace(['<br>', '<br/>', '<br />'], ' ', $text['title']))) ?>"
                                   data-button-text="<?= htmlspecialchars($text['button_text']) ?>">
                                    <?= htmlspecialchars($text['button_text']) ?>
                                </a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
    </section>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const bannerId = <?= $banner_id ?>;
        const swiperId = '.<?= $swiper_id ?>';
        
        const swiper = new Swiper(swiperId, {
            effect: '<?= $banner_settings['effect'] ?>',
            speed: <?= $banner_settings['speed'] ?>,
            loop: <?= $banner_settings['loop'] ? 'true' : 'false' ?>,
            <?php if ($banner_settings['autoplay_delay'] > 0): ?>
            autoplay: {
                delay: <?= $banner_settings['autoplay_delay'] ?>,
                disableOnInteraction: false
            },
            <?php endif; ?>
            pagination: {
                el: swiperId + ' .swiper-pagination',
                clickable: true
            },
            on: {
                init: function() {
                    <?php if ($opts['enable_ga4']): ?>
                    if (typeof gtag !== 'undefined') {
                        gtag('event', 'banner_view', {
                            'event_category': 'engagement',
                            'event_label': 'banner_' + bannerId + '_slide_0',
                            'banner_id': bannerId,
                            'slide_index': 0
                        });
                    }
                    <?php endif; ?>
                    
                    if (typeof AOS !== 'undefined') {
                        AOS.init({ duration: 1000, once: false });
                    }
                },
                slideChange: function() {
                    <?php if ($opts['enable_ga4']): ?>
                    if (typeof gtag !== 'undefined') {
                        gtag('event', 'banner_view', {
                            'event_category': 'engagement',
                            'event_label': 'banner_' + bannerId + '_slide_' + this.realIndex,
                            'banner_id': bannerId,
                            'slide_index': this.realIndex,
                            'auto_slide': <?= $banner_settings['autoplay_delay'] > 0 ? 'true' : 'false' ?>
                        });
                    }
                    <?php endif; ?>
                },
                slideChangeTransitionEnd: function() {
                    if (typeof AOS !== 'undefined') {
                        document.querySelectorAll('.swiper-slide [data-aos]').forEach(el => el.classList.remove('aos-animate'));
                        setTimeout(() => {
                            const activeSlide = document.querySelector('.swiper-slide-active [data-aos]');
                            if (activeSlide) activeSlide.classList.add('aos-animate');
                        }, 50);
                    }
                }
            }
        });
        
        <?php if ($opts['enable_ga4']): ?>
        // 버튼 클릭 추적
        document.querySelectorAll(swiperId + ' .banner-cta-btn').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                const index = this.getAttribute('data-banner-index');
                const title = this.getAttribute('data-banner-title');
                const buttonText = this.getAttribute('data-button-text');
                
                if (typeof gtag !== 'undefined') {
                    gtag('event', 'banner_button_click', {
                        'event_category': 'engagement',
                        'event_label': 'banner_' + bannerId + '_button',
                        'banner_id': bannerId,
                        'banner_title': title,
                        'button_text': buttonText,
                        'slide_index': parseInt(index),
                        'value': 1
                    });
                }
            });
        });
        
        // 이미지 클릭 추적
        const bannerLinks = <?= json_encode(array_map(function($img) { 
            return isset($img['link']) ? $img['link'] : ''; 
        }, $banner_images)) ?>;
        
        document.querySelectorAll(swiperId + ' .slide-bg-img').forEach((img, index) => {
            const link = bannerLinks[index];
            if (link) {
                img.style.cursor = 'pointer';
                img.addEventListener('click', function() {
                    if (typeof gtag !== 'undefined') {
                        gtag('event', 'banner_image_click', {
                            'event_category': 'engagement',
                            'event_label': 'banner_' + bannerId + '_image',
                            'banner_id': bannerId,
                            'slide_index': index,
                            'link_url': link
                        });
                    }
                    window.location.href = link;
                });
            }
        });
        <?php endif; ?>
    });
    </script>
    <?php
}
?>