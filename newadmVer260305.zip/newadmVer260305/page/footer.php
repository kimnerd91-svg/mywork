<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer Test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/setting.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body>

    <?php
    // 테스트용 더미 데이터
    $conf = [
        'cf_address' => '경기도 안산시 공도읍 곡도로 78, 2층 (유플러스 건물 2층)',
        'cf_tel' => '031.616.2875',
        'cf_company_name' => '마음담은치과의원',
        'cf_ceo_name' => '김유진',
        'cf_business_number' => '5699-10-03035',
        'cf_naver_booking' => '',
        'cf_naver_talk' => '',
        'cf_kakao' => '',
        'cf_blog' => '',
        'cf_instagram' => '',
        'cf_terms' => '여기에 이용약관 내용이 들어갑니다.',
        'cf_privacy_policy' => '여기에 개인정보처리방침 내용이 들어갑니다.'
    ];

    $non_covered = [];
    ?>

    <!-- Footer -->
    <footer class="footer u-bg-dark u-pretendard u-px-20-sm u-pb-56" id="footer01">
        <div class="u-1920">
            <div>
                map
            </div>
        </div>
        <div class="u-1440 u-py-48-sm">

            <div class="g-cols-fill-4 u-mb-40 u-gap-40-sm g-cols-fit-8-sm">
                <!-- 오시는길 -->
                <div class="col-12">
                    <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-white">오시는길 <img src="/images/goldright.svg" alt=""></h5>
                    <p class="u-txt-white fw-400 t-fs-20 u-lh-175 u-mb-6" style="letter-spacing: -1px;"><?= htmlspecialchars($conf['cf_address']) ?></p>
                    <p class="footer-notice u-mb-30">* 주차장이 매우 협소합니다. 공도저류지 공영주차장 이용</p>
                    <div class="footer-bus d-flex u-gap-20 align-items-start">
                        <div>
                            <div class="bus_label d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                                <img src="/images/buswhite.svg" alt="">
                                <p class="fw-500 c-fs-18 u-txt-white u-mb-0">버스 이용 시</p>
                            </div>
                        </div>
                        <div>
                            <div class="d-flex align-items-center u-gap-4 u-mb-6">
                                <img src="/images/buslabel.svg" alt="">
                                <h6 class="c-fs-20 u-mb-0">구) 공도정류장 하차</h6>
                            </div>
                            <p class="c-fs-18 fw-500 u-lh-15 u-txt-gray-500">
                                1-4, 1-8, 7-2, 7-3, 7-5,<br>
                                7-6, 7-7, 7-11, 70, 1150
                            </p>
                        </div>
                    </div>

                </div>
                <!-- 진료시간 -->
                <div class="col-12">
                    <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-white">진료시간</h5>
                    <ul class="footer-list u-mb-20">
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-white">
                            <div class="col-3" style="letter-spacing: -2px;">월 / 화 / 목 / 금</div> <span class="c-fs-20 u-lh-175 u-txt-white">오전 09:30 ~ 오후 06:30</span>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-white">
                            <div class="col-3">수요일</div>
                            <div class="d-flex u-gap-8 flex-wrap"><span class="c-fs-20 u-lh-175 u-txt-white">오전 09:30 ~ 오후 08:30</span> <span class="badge d-flex justify-content-center align-items-center rounded-full t-fs-18 u-txt-dark u-py-4 u-px-10">야간진료</span> </div>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-white">
                            <div class="col-3">토요일</div> <span class="c-fs-20 u-lh-175 u-txt-white">오전 09:00 ~ 오후 02:00</span>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-white">
                            <div class="col-3">점심시간</div> <span class="c-fs-20 u-lh-175 u-txt-white">오후 01:00 ~ 오후 02:00</span>
                        </li>

                    </ul>
                    <p class="u-txt-gray-500 c-fs-20 fw-400">* 일요일, 공휴일 휴진 / 토요일 점심시간 없음</p>
                </div>



                <!-- SNS & 연락처 -->
                <div class="col-12">
                    <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-white">SNS</h5>
                    <div class="d-flex u-gap-18 w-max u-mb-24">
                        <a href="#" class="sns-icon"><img src="/images/blog.svg" alt=""></a>
                        <a href="#" class="sns-icon"><img src="/images/naver.svg" alt=""></a>
                        <a href="#" class="sns-icon"><img src="/images/talk.svg" alt=""></a>
                        <a href="#" class="sns-icon"><img src="/images/kakao.svg" alt=""></a>
                    </div>

                    <a href="tel:<?= preg_replace('/[^0-9]/', '', $conf['cf_tel']) ?>"
                        class="footer-phone d-block t-fs-44 fw-700 text-decoration-none"> 
                        <?= htmlspecialchars($conf['cf_tel']) ?>
                    </a>


                </div>
            </div>
            <div class="d-flex justify-content-start justify-content-md-end align-items-end u-mb-20 u-txt-gray-500 c-fs-16 u-gap-4">
                <a href="#" class="u-txt-gray-500 fw-400 c-fs-16" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a> |
                <a href="#" class="u-txt-gray-500 fw-400 c-fs-16" data-bs-toggle="modal" data-bs-target="#modalProvision">이용약관</a>
            </div>


        </div>
        <!-- Copyright -->
        <div class="u-1920 u-bt-1 u-bc-gray-500 u-solid ">
            <div class="u-1440 u-mt-48">
                <div class="col-12 d-flex u-mb-48 align-items-start align-items-md-center justify-content-between">
                    <div class="">
                        <p class="u-txt-gray-500 c-fs-16 fw-400 u-mb-0 c-fs-14-sm">
                            상호명 : <?= htmlspecialchars($conf['cf_company_name']) ?> | <br class="d-block d-md-none">
                            대표·원장 : <?= htmlspecialchars($conf['cf_ceo_name']) ?> | <br class="d-block d-md-none">
                            사업자등록번호 : <?= htmlspecialchars($conf['cf_business_number']) ?>
                        </p>
                        <p class="u-txt-gray-500 c-fs-16 fw-400 c-fs-10-sm">Copyright 2025. MAEUM DAMEUN DENTAL CLINIC All rights reserved.</p>
                    </div>
                    <div class="">
                        <button class="u-btn u-btn-accent rounded-full u-txt-black fw-bold t-fs-20 d-flex align-items-center u-py-14 u-px-48 u-px-14-sm w-max-sm u-py-4-sm  t-fs-14-sm" data-bs-toggle="modal" data-bs-target="#modalNonCovered">
                            비급여고지표
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <footer class="footer u-bg-light u-pretendard u-px-20-sm u-pt-80" id="footer02">
        <div class="u-1440">

            <div class="g-cols-fill-4 u-mb-64 u-gap-40-sm g-cols-fit-8-sm">

                <!-- 진료시간 -->
                <div class="col-12">
                    <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-dark">진료시간</h5>
                    <ul class="footer-list u-mb-20">
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                            <div class="col-3" style="letter-spacing: -2px">월 / 화 / 목 / 금</div>
                            <P class="c-fs-20 u-lh-175 u-txt-dark u-mb-0"><span class="u-txt-point">AM</span> 09:30 ~ <span class="u-txt-point">PM</span> 06:30</P>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                            <div class="col-3">수요일</div>
                            <div class="d-flex u-gap-8">
                                <P class="c-fs-20 u-lh-175 u-txt-dark u-mb-0 flex-wrap"><span class="u-txt-point">AM</span> 09:30 ~ <span class="u-txt-point">PM</span> 08:30</P> <span class="badge d-flex justify-content-center align-items-center rounded-full t-fs-18 u-txt-WHITE u-py-4 u-px-10">야간진료</span>
                            </div>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                            <div class="col-3">토요일</div>
                            <P class="c-fs-20 u-lh-175 u-txt-dark u-mb-0"><span class="u-txt-point">AM</span> 09:00 ~ <span class="u-txt-point">PM</span> 02:00</P>
                        </li>
                        <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                            <div class="col-3">점심시간</div>
                            <P class="c-fs-20 u-lh-175 u-txt-dark u-mb-0"><span class="u-txt-point">PM</span> 01:00 ~ <span class="u-txt-point">PM</span> 02:00</P>
                        </li>

                    </ul>
                    <p class="u-txt-gray-500 c-fs-18 fw-400">* 일요일, 공휴일 휴진 / 토요일 점심시간 없음</p>
                    <p class="u-txt-gray-500 c-fs-18 fw-400">* 일요일, 공휴일 휴진 / 토요일 점심시간 없음</p>
                </div>



                <!-- SNS & 연락처 -->
                <div class="col-12">
                    <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-dark">상담문의</h5>

                    <a href="tel:<?= preg_replace('/[^0-9]/', '', $conf['cf_tel']) ?>"
                        class="footer-phone d-block t-fs-44 fw-700 text-decoration-none u-txt-dark"> <img src="/images/call.svg" alt="">
                        <?= htmlspecialchars($conf['cf_tel']) ?>
                    </a>
                    <div class="u-mt-20">
                        MAP
                    </div>


                </div>

                <!-- 오시는길 -->
                <div class="col-12 d-flex flex-column u-gap-30">
                    <h5 class="footer-title fw-bold t-fs-36 u-txt-dark">오시는길 <img src="/images/goldright.svg" alt=""></h5>
                    <p class="u-txt-dark fw-400 t-fs-20 u-lh-175 u-mb-6" style="letter-spacing: -1px;"><?= htmlspecialchars($conf['cf_address']) ?></p>
                    <div class="footer-bus d-flex u-gap-20 align-items-start flex-wrap u-rgap-0">
                        <div>
                            <div class="bus_label d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                                <p class="fw-500 c-fs-18 u-txt-white u-mb-0">버스 이용 시</p>
                            </div>
                        </div>
                        <div>
                            <div class="d-flex align-items-center u-gap-4 u-mb-6">
                                <img src="/images/buslabel.svg" alt="">
                                <h6 class="c-fs-20 u-mb-0">구) 공도정류장 하차</h6>
                            </div>
                        </div>
                        <div class="col-12">
                            <p class="c-fs-18 fw-500 u-lh-15 u-txt-gray-500">
                                1-4, 1-8, 7-2, 7-3, 7-5,<br>
                                7-6, 7-7, 7-11, 70, 1150
                            </p>
                        </div>
                    </div>
                    <div class="footer-car d-flex u-gap-20 align-items-start flex-wrap u-rgap-0">
                        <div>
                            <div class="car_label d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                                <p class="fw-500 c-fs-18 u-txt-white u-mb-0">자가용 이용 시</p>
                            </div>
                        </div>
                        <div>
                            <div class="d-flex align-items-center u-gap-4 u-mb-6">
                                <h6 class="c-fs-20 u-mb-0 u-txt-gray-900">공도저류지 공영주차장 이용</h6>
                            </div>
                        </div>
                        <div class="col-12">
                            <p class="c-fs-18 fw-500 u-lh-15 u-txt-gray-500">
                                *주차장이 협소하여 공영주차장을 이용부탁드립니다.
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- Copyright -->
        <div class="u-1440 u-bg-main rounded-full u-px-48 u-py-28 rounded-20-sm u-p-30-sm">
            <div class="u-1440">
                <div class="d-flex justify-content-between align-items-start align-items-md-center flex-column flex-md-row flex-wrap">
                    <div class="d-flex u-gap-80 align-items-start align-items-md-center flex-column flex-md-row u-gap-30-sm u-mb-30-sm">
                        <a href="/">
                            <img class="w-100 w-50-sm" src="/images/logo_ex.svg" alt="">
                        </a>
                        <div>
                            <p class="u-txt-gray-500 c-fs-16 fw-400 u-mb-0 c-fs-14-sm">
                                상호명 : <?= htmlspecialchars($conf['cf_company_name']) ?> | <br class="d-block d-md-none">
                                대표·원장 : <?= htmlspecialchars($conf['cf_ceo_name']) ?> | <br class="d-block d-md-none">
                                사업자등록번호 : <?= htmlspecialchars($conf['cf_business_number']) ?>
                            </p>
                            <p class="u-txt-gray-500 c-fs-16 fw-400 c-fs-10-sm">Copyright 2025. MAEUM DAMEUN DENTAL CLINIC All rights reserved.</p>
                            <div class="d-flex justify-content-start align-items-center u-txt-gray-500 c-fs-16 u-gap-4">
                                <a href="#" class="u-txt-gray-500 fw-400 c-fs-16" data-bs-toggle="modal" data-bs-target="#modalPrivacy">개인정보처리방침</a> |
                                <a href="#" class="u-txt-gray-500 fw-400 c-fs-16" data-bs-toggle="modal" data-bs-target="#modalProvision">이용약관</a>
                            </div>
                        </div>
                    </div>
                    <div class="u-mb-30-sm">
                        <div class="d-flex u-gap-18 w-max">
                            <a href="#" class="sns-icon"><img src="/images/blog.svg" alt=""></a>
                            <a href="#" class="sns-icon"><img src="/images/naver.svg" alt=""></a>
                            <a href="#" class="sns-icon"><img src="/images/talk.svg" alt=""></a>
                            <a href="#" class="sns-icon"><img src="/images/kakao.svg" alt=""></a>
                        </div>
                    </div>
                    <div class="">
                        <button class="u-btn u-btn-accent rounded-full u-txt-black fw-bold t-fs-20 d-flex align-items-center u-py-14 u-px-28 u-px-14-sm w-max-sm u-py-4-sm  t-fs-14-sm " data-bs-toggle="modal" data-bs-target="#modalNonCovered">
                            비급여고지표
                        </button>
                    </div>

                </div>
            </div>
        </div>
    </footer>

    <style>
        #footer01 {
            background: #3a3a3a;
            color: #fff;
            padding: 60px 0 40px;
        }

        #footer01 .footer-bus h6 {
            color: #3A99E9;
            ;
        }

        #footer01 .bus_label {
            background-color: #3A99E9;
        }

        #footer01 .footer-title {
            font-size: 1.125rem;
            font-weight: 700;
            margin-bottom: 20px;
        }

        #footer01 .footer-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        #footer01 .footer-list li {
            margin-bottom: 10px;
            font-size: 0.9375rem;
        }

        #footer01 .footer-list .badge {
            background: #f1c40f;
            padding: 2px 8px;

        }

        #footer01 .footer-address {
            font-size: 0.9375rem;
            margin-bottom: 10px;
        }

        #footer01 .footer-notice {
            font-size: 0.875rem;
            color: #aaa;
            margin-bottom: 16px;
        }

        #footer01 .footer-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        #footer01 .footer-directions {
            color: #aaa;
        }

        #footer01 .footer-sns {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
        }

        #footer01 .sns-icon {
            font-size: 1.5rem;
            color: #fff;
            text-decoration: none;
        }

        #footer01 .sns-icon:hover {
            color: #f1c40f;
        }

        #footer01 .footer-phone {
            font-size: 2rem;
            font-weight: 700;
            color: #fff;
            margin-bottom: 16px;
        }

        #footer01 .footer-phone:hover {
            color: #f1c40f;
        }

        #footer01 .footer-links a {
            color: #fff;
            text-decoration: none;
        }

        #footer01 .footer-links a:hover {
            text-decoration: underline;
        }

        #footer01 .footer-copyright {
            color: #aaa;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }

        @media (max-width: 767px) {
            #footer01 .footer {
                padding: 40px 0 24px;
            }

            #footer01 .footer-phone {
                font-size: 1.5rem;
            }

            #footer01 .footer-buttons {
                flex-direction: column;
            }
        }

        #footer02 .footer-bus h6 {
            color: #3A99E9;
            ;
        }

        #footer02 .bus_label {
            background-color: #3A99E9;
        }

        #footer02 .footer-car h6 {
            color: #3A99E9;
            ;
        }

        #footer02 .car_label {
            background-color: var(--gray-700);
        }
        
        #footer02 .footer-list .badge {
            background: #f1c40f;
            padding: 2px 8px;

        }

    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>