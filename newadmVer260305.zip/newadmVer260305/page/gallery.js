/* ==================== 
   Gallery Module - Swiper.js Required
   CDN: https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js
   ==================== */

/* ==================== 
   Swiper Basic
   ==================== */
function initSwiperBasic(id = 'swiperBasic') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: `#${id} .swiper-pagination`,
            clickable: true,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
    });
    
    return swiper;
}

/* ==================== 
   Swiper Thumbnail
   ==================== */
function initSwiperThumbnail(id = 'swiperThumbnail') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiperThumbs = new Swiper(`#${id} .swiper-thumbs`, {
        spaceBetween: 10,
        slidesPerView: 5,
        freeMode: true,
        watchSlidesProgress: true,
        breakpoints: {
            320: { slidesPerView: 3 },
            768: { slidesPerView: 4 },
            1024: { slidesPerView: 5 },
        },
    });
    
    const swiperMain = new Swiper(`#${id} .swiper-main`, {
        spaceBetween: 10,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        thumbs: {
            swiper: swiperThumbs,
        },
    });
    
    return { main: swiperMain, thumbs: swiperThumbs };
}

/* ==================== 
   Grid Masonry
   ==================== */
function initGridMasonry(id = 'gridMasonry') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const items = container.querySelectorAll('.masonry-item');
    items.forEach(item => {
        item.addEventListener('click', function() {
            const img = this.querySelector('img');
            openLightbox(img.src, img.alt);
        });
    });
}

/* ==================== 
   Grid 3x3
   ==================== */
function initGrid3x3(id = 'grid3x3') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const items = container.querySelectorAll('.grid-item');
    items.forEach(item => {
        item.addEventListener('click', function() {
            const img = this.querySelector('img');
            openLightbox(img.src, img.alt);
        });
    });
}

/* ==================== 
   Grid 4x4
   ==================== */
function initGrid4x4(id = 'grid4x4') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const items = container.querySelectorAll('.grid-item');
    items.forEach(item => {
        item.addEventListener('click', function() {
            const img = this.querySelector('img');
            openLightbox(img.src, img.alt);
        });
    });
}

/* ==================== 
   Swiper Left Title
   ==================== */
function initSwiperLeftTitle(id = 'swiperLeftTitle') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        pagination: {
            el: `#${id} .swiper-pagination`,
            clickable: true,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
    });
    
    return swiper;
}

/* ==================== 
   Swiper Right Title
   ==================== */
function initSwiperRightTitle(id = 'swiperRightTitle') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        pagination: {
            el: `#${id} .swiper-pagination`,
            clickable: true,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        },
    });
    
    return swiper;
}

/* ==================== 
   Text Pagination Top - WITH PROGRESS BAR
   ==================== */
function initSwiperTextPaginationTop(id = 'swiperTextPaginationTop') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const bullets = container.querySelectorAll('.text-bullet');
    const totalBullets = bullets.length;
    const paginationContainer = container.querySelector('.text-pagination-top');
    
    function updateProgressBar(currentIndex) {
        const progress = totalBullets > 1 ? (currentIndex / (totalBullets - 1)) * 80 : 0;
        
        if (paginationContainer) {
            paginationContainer.style.setProperty('--progress', `${progress}%`);
        }
        
        bullets.forEach((bullet, index) => {
            bullet.classList.remove('active', 'completed');
            
            if (index < currentIndex) {
                bullet.classList.add('completed');
            } else if (index === currentIndex) {
                bullet.classList.add('active');
            }
        });
    }
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
        on: {
            slideChange: function() {
                updateProgressBar(this.realIndex);
            },
            init: function() {
                updateProgressBar(this.realIndex);
            }
        }
    });
    
    bullets.forEach((bullet, index) => {
        bullet.addEventListener('click', () => {
            swiper.slideToLoop(index);
        });
    });
    
    return swiper;
}

/* ==================== 
   Text Pagination Bottom - WITH PROGRESS BAR
   ==================== */
function initSwiperTextPaginationBottom(id = 'swiperTextPaginationBottom') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const bullets = container.querySelectorAll('.text-bullet');
    const totalBullets = bullets.length;
    const paginationContainer = container.querySelector('.text-pagination-bottom');
    
    function updateProgressBar(currentIndex) {
        const progress = totalBullets > 1 ? (currentIndex / (totalBullets - 1)) * 80 : 0;
        
        if (paginationContainer) {
            paginationContainer.style.setProperty('--progress', `${progress}%`);
        }
        
        bullets.forEach((bullet, index) => {
            bullet.classList.remove('active', 'completed');
            
            if (index < currentIndex) {
                bullet.classList.add('completed');
            } else if (index === currentIndex) {
                bullet.classList.add('active');
            }
        });
    }
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
        on: {
            slideChange: function() {
                updateProgressBar(this.realIndex);
            },
            init: function() {
                updateProgressBar(this.realIndex);
            }
        }
    });
    
    bullets.forEach((bullet, index) => {
        bullet.addEventListener('click', () => {
            swiper.slideToLoop(index);
        });
    });
    
    return swiper;
}

/* ==================== 
   Thumbnail with Text
   ==================== */
function initSwiperThumbnailText(id = 'swiperThumbnailText') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiperThumbsText = new Swiper(`#${id} .swiper-thumbs-text`, {
        spaceBetween: 10,
        slidesPerView: 5,
        freeMode: true,
        watchSlidesProgress: true,
        breakpoints: {
            320: { slidesPerView: 3 },
            768: { slidesPerView: 4 },
            1024: { slidesPerView: 5 },
        },
    });
    
    const swiperMain = new Swiper(`#${id} .swiper-main`, {
        spaceBetween: 10,
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        thumbs: {
            swiper: swiperThumbsText,
        },
    });
    
    return { main: swiperMain, thumbs: swiperThumbsText };
}

/* ==================== 
   Caption Swiper
   ==================== */
function initSwiperCaption(id = 'swiperCaption') {
    const container = document.getElementById(id);
    if (!container) return;
    
    const swiper = new Swiper(`#${id} .swiper`, {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        autoplay: {
            delay: 3500,
            disableOnInteraction: false,
        },
        pagination: {
            el: `#${id} .swiper-pagination`,
            clickable: true,
        },
        navigation: {
            nextEl: `#${id} .swiper-button-next`,
            prevEl: `#${id} .swiper-button-prev`,
        },
    });
    
    return swiper;
}

/* ==================== 
   Lightbox
   ==================== */
function openLightbox(src, alt) {
    const existingLightbox = document.getElementById('galleryLightbox');
    if (existingLightbox) {
        existingLightbox.remove();
    }
    
    const lightbox = document.createElement('div');
    lightbox.id = 'galleryLightbox';
    lightbox.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        cursor: pointer;
    `;
    
    const img = document.createElement('img');
    img.src = src;
    img.alt = alt;
    img.style.cssText = `
        max-width: 90%;
        max-height: 90%;
        object-fit: contain;
    `;
    
    lightbox.appendChild(img);
    document.body.appendChild(lightbox);
    
    lightbox.addEventListener('click', function() {
        this.remove();
    });
    
    const closeOnEsc = function(e) {
        if (e.key === 'Escape') {
            lightbox.remove();
            document.removeEventListener('keydown', closeOnEsc);
        }
    };
    document.addEventListener('keydown', closeOnEsc);
}

/* ==================== 
   Initialize All Galleries
   ==================== */
function initAllGalleries() {
    document.querySelectorAll('.gallery-swiper-basic').forEach(el => {
        if (el.id) initSwiperBasic(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-thumbnail').forEach(el => {
        if (el.id) initSwiperThumbnail(el.id);
    });
    
    document.querySelectorAll('.gallery-grid-masonry').forEach(el => {
        if (el.id) initGridMasonry(el.id);
    });
    
    document.querySelectorAll('.gallery-grid-3x3').forEach(el => {
        if (el.id) initGrid3x3(el.id);
    });
    
    document.querySelectorAll('.gallery-grid-4x4').forEach(el => {
        if (el.id) initGrid4x4(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-left-title').forEach(el => {
        if (el.id) initSwiperLeftTitle(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-right-title').forEach(el => {
        if (el.id) initSwiperRightTitle(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-text-pagination-top').forEach(el => {
        if (el.id) initSwiperTextPaginationTop(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-text-pagination-bottom').forEach(el => {
        if (el.id) initSwiperTextPaginationBottom(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-thumbnail-text').forEach(el => {
        if (el.id) initSwiperThumbnailText(el.id);
    });
    
    document.querySelectorAll('.gallery-swiper-caption').forEach(el => {
        if (el.id) initSwiperCaption(el.id);
    });
}

  initSwiperBasic('testSwiper1');
        initSwiperThumbnail('testThumbnail1');
        initGridMasonry('testMasonry1');
        initGrid3x3('testGrid3x3');
        initSwiperLeftTitle('testLeftTitle1');
        initSwiperRightTitle('testRightTitle1');
        initSwiperTextPaginationTop('testTextTop1');
        initSwiperTextPaginationBottom('testTextBottom1');
        initSwiperThumbnailText('testThumbnailText1');
        initSwiperCaption('testCaption1');
        
        console.log('✅ 모든 갤러리 초기화 완료 (10가지 타입)');
