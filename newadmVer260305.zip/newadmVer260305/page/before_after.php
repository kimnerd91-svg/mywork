<?php
// 비포애프터 게시판형 (한 줄에 4개)
if (!defined('_GNUBOARD_')) {
    include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');
}

$ba_table = 'dm_beforeafter';

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$ba_table}'", false);
if (!$table_check || sql_num_rows($table_check) == 0) {
    return;
}

// 로그인 여부 확인
$is_logged_in = isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'];

// 노출 가능한 데이터만 가져오기
$sql = "SELECT * FROM {$ba_table} WHERE is_visible = 1 ORDER BY display_order ASC, id DESC";
$result = sql_query($sql, false);

if (!$result || sql_num_rows($result) == 0) {
    return;
}

// 카테고리 목록 추출
$categories = ['전체'];
sql_data_seek($result, 0);
while ($row = sql_fetch_array($result)) {
    if ($row['treatment_category'] && !in_array($row['treatment_category'], $categories)) {
        $categories[] = $row['treatment_category'];
    }
}
sql_data_seek($result, 0);
?>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<!-- 비포애프터 게시판형 섹션 -->
<section class="u-py-80">
    <div class="container" style="max-width: 1400px; margin: 0 auto; padding: 0 var(--sp-20);">
        
        <!-- 헤더 -->
        <div class="text-center u-mb-60" data-aos="fade-up">
            <div class="u-txt-main fw-700 c-fs-14 u-mb-10">BEFORE & AFTER</div>
            <h2 class="t-fs-48 fw-900 u-mb-16">치료 전후 비교</h2>
            <p class="c-fs-18 u-txt-muted">실제 치료 케이스를 확인하세요</p>
        </div>

        <!-- 카테고리 탭 -->
        <div class="d-flex u-gap-12 flex-wrap justify-content-center u-mb-48">
            <?php foreach ($categories as $cat): ?>
                <button class="ba-tab <?= $cat == '전체' ? 'active' : '' ?>" 
                        onclick="filterCategory('<?= htmlspecialchars($cat) ?>')">
                    <?= htmlspecialchars($cat) ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- 케이스 그리드 (한 줄에 4개) -->
        <div class="ba-grid-4">
            <?php while ($ba = sql_fetch_array($result)): ?>
                <div class="ba-board-card" data-category="<?= htmlspecialchars($ba['treatment_category']) ?>">
                    <a href="/view_direct.php?bo_table=beforeafter&wr_id=<?= $ba['id'] ?>" class="d-block">
                        <!-- 제목 -->
                        <div class="u-p-20 u-pb-0">
                            <h3 class="t-fs-20 fw-900 u-txt-title u-mb-4" style="line-height: 1.4;">
                                <?= htmlspecialchars($ba['title']) ?>
                            </h3>

                            <!-- 로그인 후 표시 정보 -->
                            <?php if ($is_logged_in): ?>
                            <div class="d-flex flex-wrap u-gap-8 u-mb-16" style="font-size: 12px;">
                                <?php if ($ba['treatment_category']): ?>
                                    <span class="u-badge u-badge-main" style="font-size: 11px; padding: 4px 10px;"><?= htmlspecialchars($ba['treatment_category']) ?></span>
                                <?php endif; ?>
                                <?php if ($ba['patient_age'] || $ba['patient_gender']): ?>
                                    <span class="u-txt-muted">👤 <?= htmlspecialchars($ba['patient_age']) ?> <?= htmlspecialchars($ba['patient_gender']) ?></span>
                                <?php endif; ?>
                                <?php if ($ba['treatment_period']): ?>
                                    <span class="u-txt-muted">⏱️ <?= htmlspecialchars($ba['treatment_period']) ?></span>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- 이미지 (세로 배치) -->
                        <div class="d-flex flex-column u-gap-8 u-p-20 u-pt-0" style="padding-top: 0;">
                            <?php if ($ba['image_before']): ?>
                            <div class="ba-board-img">
                                <img src="<?= htmlspecialchars($ba['image_before']) ?>" alt="Before" class="obj-cover">
                                <div class="ba-img-badge">Before</div>
                            </div>
                            <?php endif; ?>

                            <?php if ($ba['image_after']): ?>
                            <div class="ba-board-img">
                                <img src="<?= htmlspecialchars($ba['image_after']) ?>" alt="After" class="obj-cover">
                                <div class="ba-img-badge">After</div>
                                
                                <!-- 블러 오버레이 -->
                                <?php if (!$is_logged_in): ?>
                                <div class="ba-blur">
                                    <div class="ba-lock">🔒</div>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</section>

<style>
/* 카테고리 탭 */
.ba-tab {
    padding: var(--sp-10) var(--sp-20);
    background: var(--white);
    border: 2px solid var(--gray-200);
    border-radius: var(--sp-16);
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s;
}

.ba-tab:hover {
    border-color: var(--main-color);
}

.ba-tab.active {
    background: var(--main-color);
    color: var(--white);
    border-color: var(--main-color);
}

/* 게시판 그리드 (한 줄에 4개) */
.ba-grid-4 {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: var(--sp-20);
}

.ba-board-card {
    background: var(--white);
    border-radius: var(--sp-16);
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    transition: transform 0.3s, box-shadow 0.3s;
}

.ba-board-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1);
}

.ba-board-img {
    position: relative;
    aspect-ratio: 16 / 10;
    border-radius: var(--sp-8);
    overflow: hidden;
    background: var(--gray-100);
}

.ba-board-img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ba-img-badge {
    position: absolute;
    bottom: var(--sp-8);
    right: var(--sp-8);
    padding: var(--sp-4) var(--sp-12);
    background: rgba(0, 0, 0, 0.75);
    color: var(--white);
    border-radius: var(--sp-8);
    font-size: 11px;
    font-weight: 700;
}

.ba-blur {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    backdrop-filter: blur(15px);
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 10;
}

.ba-lock {
    font-size: 36px;
    animation: ba-pulse 2s infinite;
}

@keyframes ba-pulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.1); }
}

/* 반응형 */
@media (max-width: 1200px) {
    .ba-grid-4 {
        grid-template-columns: repeat(3, 1fr);
    }
}

@media (max-width: 768px) {
    .ba-grid-4 {
        grid-template-columns: repeat(2, 1fr);
        gap: var(--sp-16);
    }
}

@media (max-width: 480px) {
    .ba-grid-4 {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
// 카테고리 필터링
function filterCategory(category) {
    document.querySelectorAll('.ba-tab').forEach(tab => {
        tab.classList.remove('active');
        if (tab.textContent.trim() === category) {
            tab.classList.add('active');
        }
    });
    
    document.querySelectorAll('.ba-board-card').forEach(item => {
        if (category === '전체' || item.dataset.category === category) {
            item.style.display = 'block';
        } else {
            item.style.display = 'none';
        }
    });
}
</script>