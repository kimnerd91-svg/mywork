<?php
if (!defined('_GNUBOARD_')) exit;

$dm_conf = @sql_fetch(" SELECT * FROM dm_config WHERE cf_id = 1 ");
if (!$dm_conf) {
    $dm_conf = array(
        'cf_title' => '',
        'cf_description' => '',
        'cf_og_image' => '',
        'cf_favicon' => ''
    );
}

if (!defined('G5_IS_ADMIN') && defined('G5_THEME_PATH') && is_file(G5_THEME_PATH . '/head_sub.php')) {
    require_once(G5_THEME_PATH . '/head_sub.php');
    return;
}

$g5_debug['php']['begin_time'] = $begin_time = get_microtime();

if (!isset($g5['title'])) {
    $g5['title'] = $dm_conf['cf_title'];
    $g5_head_title = $g5['title'];
} else {
    $g5_head_title = implode(' | ', array_filter(array($g5['title'], $dm_conf['cf_title'])));
}

$g5['title'] = strip_tags($g5['title']);
$g5_head_title = strip_tags($g5_head_title);

$g5['lo_location'] = addslashes($g5['title']);
if (!$g5['lo_location'])
    $g5['lo_location'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
$g5['lo_url'] = addslashes(clean_xss_tags($_SERVER['REQUEST_URI']));
if (strstr($g5['lo_url'], '/' . G5_ADMIN_DIR . '/') || $is_admin == 'super') $g5['lo_url'] = '';
?>
<!doctype html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="naver-site-verification" content="0db50ec8bf7e72dad8080d9c0f627b41f91a8bf1">
    <meta name="robots" content="index, follow">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">

    <?php if (!defined('G5_IS_ADMIN')) { ?>
        <meta name="description" content="<?php echo $dm_conf['cf_description'] ? htmlspecialchars($dm_conf['cf_description']) : '기본 설명글'; ?>">
        <meta property="og:type" content="website">
        <meta property="og:title" content="<?php echo $dm_conf['cf_title'] ? htmlspecialchars($dm_conf['cf_title']) : $g5_head_title; ?>">
        <meta property="og:description" content="<?php echo $dm_conf['cf_description'] ? htmlspecialchars($dm_conf['cf_description']) : ''; ?>">
        <?php if (!empty($dm_conf['cf_og_image'])) { ?>
            <meta property="og:image" content="<?php echo G5_DATA_URL; ?>/common/<?php echo $dm_conf['cf_og_image']; ?>">
        <?php } ?>
        <?php if (!empty($dm_conf['cf_favicon'])) { ?>
            <link rel="shortcut icon" href="<?php echo G5_DATA_URL; ?>/common/<?php echo $dm_conf['cf_favicon']; ?>" type="image/x-icon">
        <?php } ?>
    <?php } ?>

    <!-- Google Tag Manager -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5Z6FSDCD');
    </script>
    <!-- End Google Tag Manager -->

    <?php
    // GA4 스크립트 (측정 ID만 입력받아 자동 생성)
    if (isset($dm_conf['cf_ga_id']) && $dm_conf['cf_ga_id']) {
    ?>
        <!-- Google Analytics 4 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $dm_conf['cf_ga_id']; ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());
            gtag('config', '<?php echo $dm_conf['cf_ga_id']; ?>');
        </script>
    <?php
    }

    // 추가 스크립트 (GTM, 네이버 애널리틱스 등)
    if (isset($dm_conf['cf_add_script']) && trim($dm_conf['cf_add_script']) != '') {
        echo "\n    " . stripslashes($dm_conf['cf_add_script']) . "\n";
    }
    ?>

    <title><?php echo $g5_head_title; ?></title>

    <script>
        var g5_url = "<?php echo G5_URL ?>";
        var g5_bbs_url = "<?php echo G5_BBS_URL ?>";
        var g5_is_member = "<?php echo isset($is_member) ? $is_member : ''; ?>";
        var g5_is_admin = "<?php echo isset($is_admin) ? $is_admin : ''; ?>";
        var g5_is_mobile = "<?php echo G5_IS_MOBILE ?>";
    </script>

    <!-- ========================================== -->
    <!-- CSS 로드 순서 (중요!) -->
    <!-- ========================================== -->
    <!-- 1. Bootstrap 5 (먼저 로드) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/newadmin.css?ver=<?php echo G5_CSS_VER; ?>">

    <!-- 2. SETTING.CSS (BS5 덮어쓰기) -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/setting.css?ver=2">

    <!-- 3. BASE_CORE.CSS -->
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/base_core.css?ver=2">

    <!-- 4. 외부 라이브러리 CSS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.1/dist/aos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/static/pretendard.css">

    <!-- 5. 그누보드 관리자 CSS (관리자 페이지만) -->
    <?php if (defined('G5_IS_ADMIN')) { ?>
        <link rel="stylesheet" href="<?php echo G5_ADMIN_URL; ?>/css/admin.css?ver=<?php echo G5_CSS_VER; ?>">
    <?php } ?>

    <!-- 6. 커스텀 CSS -->

    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/index.css?ver=2">
    <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/sub.css">
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/implant.css">
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/simmi.css">
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/natural.css">
        <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/general.css">
          <link rel="stylesheet" href="<?php echo G5_URL; ?>/css/pain.css">
    <!-- ========================================== -->
    <!-- JS 라이브러리 (head에서 로드) -->
    <!-- ========================================== -->
    <script src="<?php echo G5_JS_URL ?>/jquery-1.12.4.min.js"></script>
    <script src="<?php echo G5_JS_URL ?>/jquery-migrate-1.4.1.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="/page/gallery.js"></script>

    <!-- GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/Flip.min.js"></script>

    <!-- CK에디터 -->
    <script src="https://cdn.ckeditor.com/ckeditor5/40.2.0/classic/ckeditor.js"></script>




    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollToPlugin.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>




    <?php
    add_javascript('<script src="' . G5_JS_URL . '/common.js?ver=' . G5_JS_VER . '"></script>', 0);
    add_javascript('<script src="' . G5_JS_URL . '/wrest.js?ver=' . G5_JS_VER . '"></script>', 0);
    ?>

</head>
<body<?php echo isset($g5['body_script']) ? $g5['body_script'] : ''; ?>>