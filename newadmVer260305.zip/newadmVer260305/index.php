<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<?php
/*
 * ============================================
 * 메인 페이지 index.php (안전 버전)
 * ============================================
 */

// 설정값 정의
define('CONFIG_TABLE', 'dm_config');
define('BANNER_TABLE', 'mainbanner');
define('POPUP_TABLE', 'dm_popup');
define('BOARD_PREFIX', 'g5_write_');
define('REVIEW_BOARD', 'review');
define('CASE_BOARD', 'case');
define('COLUMN_BOARD', 'column');

// define('BANNER_ID', '4'); // ✨ 메인 배너 자동 사용

include_once('./_common.php');

// ============================================
// 사이트 설정 안전하게 가져오기
// ============================================
function safe_get_config()
{
    // 1. 테이블 존재 확인
    $table_check = sql_query("SHOW TABLES LIKE 'dm_config'");
    if (sql_num_rows($table_check) == 0) {
        error_log("ERROR: dm_config 테이블이 존재하지 않습니다!");
        return get_default_config();
    }

    // 2. 레코드 존재 확인
    $config = @sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");

    if (!$config) {
        error_log("WARNING: dm_config에 cf_id=1 레코드가 없습니다. 자동 생성합니다.");

        // 자동으로 레코드 생성
        sql_query("INSERT INTO dm_config (cf_id) VALUES (1)");
        $config = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
    }

    // 3. 기본값으로 채우기
    $defaults = get_default_config();
    foreach ($defaults as $key => $value) {
        if (!isset($config[$key]) || $config[$key] === null) {
            $config[$key] = $value;
        }
    }

    return $config;
}

function get_default_config()
{
    return [
        'cf_title' => '사이트 제목',
        'cf_description' => '사이트 설명',
        'cf_og_image' => '',
        'cf_favicon' => '',
        'cf_logo' => '',
        'cf_site_name' => '킹덤치과',
        'cf_ga_id' => '',
        'cf_add_script' => '',
        'cf_add_body_script' => ''
    ];
}

// 안전하게 설정 가져오기
$site_config = safe_get_config();

// ============================================
// 배너 설정 가져오기 (✨ 메인 배너 자동 선택)
// ============================================
// 1. 메인 배너 찾기 (is_main = 1)
$banner_row = sql_fetch("SELECT * FROM mainbanner WHERE is_main = 1");

// 2. 메인 배너 없으면 첫 번째 배너 사용
if (!$banner_row) {
    $banner_row = sql_fetch("SELECT * FROM mainbanner ORDER BY id ASC LIMIT 1");
}

$banner_images = [];
$banner_settings = [
    'autoplay_delay' => 3000,
    'effect' => 'slide',
    'loop' => 1,
    'speed' => 600
];

if ($banner_row) {
    $banner_images = $banner_row['images'] ? json_decode($banner_row['images'], true) : [];
    if ($banner_row['settings']) {
        $banner_settings = json_decode($banner_row['settings'], true);
    }
}

// 배너가 없으면 기본 이미지
if (empty($banner_images)) {
    $banner_images = [[
        'src' => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1920',
        'visible' => true,
        'link' => '',
        'text_settings' => [
            'title' => 'Welcome to Our Site',
            'description' => 'Please add banners in admin panel',
            'button_text' => '',
            'button_link' => '',
            'text_color' => '#ffffff',
            'text_position' => 'center'
        ]
    ]];
}
// ============================================
// 칼럼 데이터 가져오기
// ============================================

// 데이터 조회
$col_result = safe_sql_query("SELECT * FROM " . BOARD_PREFIX . COLUMN_BOARD . " WHERE wr_is_comment = 0 ORDER BY wr_datetime DESC LIMIT 4");
$columns = [];
if ($col_result) {
    while ($col = safe_sql_fetch_array($col_result)) {
        $thumb = '/images/column.png';
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', stripslashes($col['wr_content']), $m)) {
            $thumb = $m[1];
        }
        $columns[] = [
            'wr_id'   => $col['wr_id'],
            'subject' => $col['wr_subject'],
            'date'    => $col['wr_datetime'] ? date('Y.m.d', strtotime($col['wr_datetime'])) : '',
            'thumb'   => $thumb,
        ];
    }
}

// ============================================
// 의료진 데이터 가져오기
// ============================================
$doctors = [];
$doc_result = safe_sql_query("SELECT * FROM dm_doctors WHERE is_visible = 1 ORDER BY display_order ASC, id ASC");
if ($doc_result) {
    while ($d = safe_sql_fetch_array($doc_result)) {
        $doctors[] = $d;
    }
}
$doc_no_img = '/images/docThumb01.png'; // 기본 이미지 fallback


// ============================================
// 안전 SQL 함수
// ============================================
function safe_sql_query($query)
{
    if (function_exists('sql_query')) return sql_query($query);
    global $connect_db;
    if ($connect_db) return mysqli_query($connect_db, $query);
    return false;
}

function safe_sql_fetch_array($result)
{
    if (function_exists('sql_fetch_array')) return sql_fetch_array($result);
    if ($result) return mysqli_fetch_assoc($result);
    return false;
}

// ============================================
// 게시글 데이터 가져오기
// ============================================
$review_result = safe_sql_query("SELECT * FROM " . BOARD_PREFIX . REVIEW_BOARD . " ORDER BY wr_datetime DESC LIMIT 3");
$case_result = safe_sql_query("SELECT * FROM " . BOARD_PREFIX . CASE_BOARD . " ORDER BY wr_datetime DESC LIMIT 6");

// 썸네일 추출 함수
function get_content_thumbnail($content)
{
    if (!$content) return null;
    $content = stripslashes($content);

    // 이미지 태그에서 추출
    if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content, $match)) {
        return $match[1];
    }

    // 유튜브 썸네일
    if (preg_match('/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/', $content, $match)) {
        return 'https://i.ytimg.com/vi/' . $match[1] . '/hqdefault.jpg';
    }

    return null;
}

// ============================================
// 팝업 HTML
// ============================================
$popup_html = '';
if (file_exists('./popup.php')) {
    ob_start();
    include_once('./popup.php');
    $popup_html = ob_get_clean();
}

// ============================================================
// sect03 데이터 준비 (index.php 상단 데이터 조회 블록에 추가)
// ============================================================

// 카테고리 → tab id 매핑
$cat_map = [
    '임플란트'       => 'implant',
    '심미치료'       => 'cosmetic',
    '자연치아 살리기' => 'natural',
    '기타'           => 'etc',
];

// 카테고리별 최신 4개 조회
$review_tabs = [];
foreach ($cat_map as $cat_name => $tab_id) {
    $esc = sql_real_escape_string($cat_name);
    $r   = safe_sql_query("SELECT * FROM dm_review WHERE is_visible = 1 AND category = '{$esc}' ORDER BY review_date DESC, id DESC LIMIT 4");
    $review_tabs[$tab_id] = [];
    if ($r) while ($row = safe_sql_fetch_array($r)) $review_tabs[$tab_id][] = $row;
}

// 전체 탭 — 최신 4개 (카테고리 무관)
$r_all = safe_sql_query("SELECT * FROM dm_review WHERE is_visible = 1 ORDER BY review_date DESC, id DESC LIMIT 4");
$review_all = [];
if ($r_all) while ($row = safe_sql_fetch_array($r_all)) $review_all[] = $row;

// 로그인 여부 (그누보드 기준)
$is_logged_in = !empty($member['mb_id']);

// 리뷰 카드 렌더링 헬퍼
function render_review_card($review, $is_logged_in)
{
    $id    = (int)$review['id'];
    $title = htmlspecialchars($review['title'] ?? '');
    $date  = $review['review_date']
        ? date('Y.m.d', strtotime($review['review_date']))
        : '';
    // 본문에서 첫 번째 이미지 추출, 없으면 기본 이미지
    $thumb = '/images/imsang.png';
    if (!empty($review['content'])) {
        $content_clean = stripslashes($review['content']);
        if (preg_match('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $content_clean, $m)) {
            $thumb = htmlspecialchars($m[1]);
        }
    }
    $overlay_style = $is_logged_in ? ' style="display:none;"' : '';
    ob_start();
?>
    <a href="/sub/case_review.php?id=<?php echo $id; ?>" class="box d-block text-decoration-none"
        data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">
        <div class="imgBox position-relative u-round-30">
            <img class="w-100" src="<?php echo $thumb; ?>" alt="<?php echo $title; ?>" />
            <div class="overlay u-round-20 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                style="top:0;left:0;background-color:rgba(0,0,0,0.8);"
                <?php echo $overlay_style; ?>>
                <h6 class="u-txt-white t-fs-14 u-lh-18 fw-bold">
                    전, 후 케이스는 로그인 후 확인 가능합니다.
                </h6>
                <p class="c-fs-8 u-lh-15 fw-300 u-txt-gray-500">
                    ※ 서울다온치과는 의료법을 준수하며 해당 게시물은<br />
                    의료법 제56조에 의거하여 로그인 후 열람이 가능합니다.
                </p>
            </div>
        </div>
        <div class="titleBox u-p-30">
            <h5 class="u-txt-black fw-500 t-fs-20 u-lh-16 u-ls-10 u-mb-8">
                <?php echo $title; ?>
            </h5>
            <p class="u-txt-gray-700 c-fs-18 fw-400 u-lh-16 u-ls-10">
                <?php echo $date; ?>
            </p>
        </div>
    </a>
<?php
    return ob_get_clean();
}

// 빈 탭 메시지
function render_empty_tab()
{
    return '<div class="d-flex justify-content-center align-items-center" style="min-height:300px;grid-column:1/-1;">
        <p class="u-txt-gray-500 c-fs-20 fw-400">작성된 리뷰가 없습니다.</p>
    </div>';
}


// ============================================
// HEAD 시작
// ============================================
include_once(G5_PATH . '/head_sub.php');
include_once(G5_PATH . '/head.php');
?>

<!-- 갤러리 CSS/JS -->
<?php include './page/gallery.php'; ?>
<link rel="stylesheet" href="/page/gallery.css">
<script src="/page/gallery.js"></script>

<!-- 팝업 -->
<?= $popup_html ?>

<!-- ============================================ -->
<!-- 메인 콘텐츠 -->
<!-- ============================================ -->
<main class="u-pretendard main">
    <section id="sect01" class="w-100 vh-100">
        <div class="swiper h-100" id="swiper-main">
            <div class="swiper-wrapper h-100">
                <?php foreach ($banner_images as $img):
                    $ts   = $img['text_settings'] ?? [];

                    // 웹/모바일 분리 구조 + 기존 단일 구조 호환
                    $web  = $ts['web']    ?? $ts;
                    $mob  = $ts['mobile'] ?? $ts;

                    // 모바일 여부 판단 (서버사이드 UA 체크)
                    $is_mobile = isset($_SERVER['HTTP_USER_AGENT']) && preg_match('/Mobile|Android|iPhone|iPad/i', $_SERVER['HTTP_USER_AGENT']);
                    $t = $is_mobile ? $mob : $web;

                    $subtitle = $t['subtitle']    ?? '';
                    $title    = $t['title']       ?? '';
                    $desc     = $t['description'] ?? '';
                    $btn_text = $t['button_text'] ?? '';
                    $btn_link = $t['button_link'] ?? '';
                    $color    = $t['text_color']  ?? '#ffffff';
                    $pos      = $t['text_position'] ?? 'left';
                    $link     = $img['link']      ?? '';

                    $pos_class = $pos === 'center' ? 'justify-content-center text-center' : ($pos === 'right' ? 'justify-content-end text-end' : 'justify-content-start');
                ?>
                    <div class="swiper-slide d-flex align-items-end  align-items-md-center <?= $pos_class ?>"
                        style="background-image: url('<?= htmlspecialchars($img['src']) ?>'); background-size: cover; background-position: center;"
                        <?= $link ? 'onclick="location.href=\'' . htmlspecialchars($link, ENT_QUOTES) . '\'" style="cursor:pointer;"' : '' ?>>
                        <div class="slide-content u-fluid  mx-auto"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="300">
                            <?php if ($subtitle): ?>
                                <h4 class="fw-600 t-fs-36 u-lh-14 u-ls-10 u-mb-20 t-fs-32-sm" style="color: <?= htmlspecialchars($color) ?>;">
                                    <?= nl2br(str_replace('&lt;br&gt;', '<br>', htmlspecialchars($subtitle))) ?>
                                </h4>
                            <?php endif; ?>
                            <?php if ($title): ?>
                                <h1 class="fw-bold t-fs-48 u-lh-14 u-ls-15 u-mb-40 t-fs-40-sm" style="color: <?= htmlspecialchars($color) ?>;">
                                    <?= nl2br(str_replace('&lt;br&gt;', '<br>', htmlspecialchars($title))) ?>
                                </h1>
                            <?php endif; ?>
                            <?php if ($desc): ?>
                                <p class="c-fs-24 u-lh-16 u-ls-10 fw-400 c-fs-24-sm c-fs-16-sm" style="color: <?= htmlspecialchars($color) ?>; opacity: 0.85;">
                                    <?= nl2br(str_replace('&lt;br&gt;', '<br>', htmlspecialchars($desc))) ?>
                                </p>
                            <?php endif; ?>
                            <?php if ($btn_text && $btn_link): ?>
                                <a href="<?= htmlspecialchars($btn_link) ?>"
                                    class="u-btn u-btn-main u-px-32 u-py-16 rounded-8 fw-700 u-mt-24 d-inline-block">
                                    <?= htmlspecialchars($btn_text) ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
         
                <?php endforeach; ?>
            </div>
                          <div class="swiper-pagination">
                
            </div>
            <div class="spinner position-absolute z-two">
                <img class="u-rotate" src="/images/spinText.svg" alt="스피너" />
            </div>
         
        </div>


    </section>
    <section
        id="sect02"
        class="d-flex align-items-center justify-content-center u-py-150">
        <div class="u-fluid u-fluid-xl-sm">
            <div
                class="mx-auto d-flex flex-column justify-content-center align-items-center sectTitle u-mb-100"
                data-aos="fade-up"
                data-aos-duration="1000">
                <img
                    class="u-mb-24"
                    src="/images/smallLogo.svg"
                    alt="다온치과로고" />
                <h6 class="fw-bold t-fs-20 u-lh-14 u-txt-sub u-mb-22">
                    SEOUL DAON DENTAL CLINIC
                </h6>
                <h3
                    class="fw-400 t-fs-48 u-ls-15 u-lh-14 u-txt-dark text-center text-lg-start">
                    <strong>온 마음을 다하는 진료,</strong><br class="d-block d-lg-none" />
                    서울다온치과
                </h3>
            </div>
            <div class="g-cols-fit-12 u-gap-24 g-flexble-2">
                <div
                    class="box"
                    data-aos="fade-up"
                    data-aos-duration="1000"
                    data-aos-delay="500">
                    <div class="imgBox position-relative u-round-30 u-mb-20">
                        <img
                            class="w-100 h-100"
                            src="/images/box01.png"
                            alt="임플란트" />
                        <div
                            class="overlay w-100 h-100 position-absolute d-flex justify-content-center align-items-center u-round-40"
                            style="top: 0; left: 0; background-color: rgba(0, 0, 0, 0.8)">
                            <ul>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        내비게이션임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        발치즉시임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        전체 임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        재수술 임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        임플란트 틀니
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        상악동 거상술
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        뼈이식 임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        가이드 임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        수면 임플란트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center"></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h6 class="u-txt-dark t-fs-28 u-lh-14 u-ls-10 fw-600 text-center">
                        임플란트
                    </h6>
                </div>
                <div
                    class="box"
                    data-aos="fade-up"
                    data-aos-duration="1000"
                    data-aos-delay="600">
                    <div class="imgBox position-relative u-round-30 u-mb-20">
                        <img
                            class="w-100 h-100"
                            src="/images/box02.png"
                            alt="심미치료" />
                        <div
                            class="overlay u-round-40 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                            style="top: 0; left: 0; background-color: rgba(0, 0, 0, 0.8)">
                            <ul>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        미백치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        라미네이트
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        레진치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        앞니 재치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        잇몸성형
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h6 class="u-txt-dark t-fs-28 u-lh-14 u-ls-10 fw-600 text-center">
                        심미치료
                    </h6>
                </div>
                <div
                    class="box"
                    data-aos="fade-up"
                    data-aos-duration="1000"
                    data-aos-delay="700">
                    <div class="imgBox position-relative u-round-30 u-mb-20">
                        <img
                            class="w-100 h-100"
                            src="/images/box03.png"
                            alt="자연치아 살리기" />
                        <div
                            class="overlay u-round-40 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                            style="top: 0; left: 0; background-color: rgba(0, 0, 0, 0.8)">
                            <ul>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        충치치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        잇몸치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        고주파플라즈마신경치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        재신경치료
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        치근단절제술
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        의도적재식술
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h6 class="u-txt-dark t-fs-28 u-lh-14 u-ls-10 fw-600 text-center">
                        자연치아 살리기
                    </h6>
                </div>
                <div
                    class="box"
                    data-aos="fade-up"
                    data-aos-duration="1000"
                    data-aos-delay="800">
                    <div class="imgBox position-relative u-round-30 u-mb-20">
                        <img
                            class="w-100 h-100"
                            src="/images/box04.png"
                            alt="통증경감 시스템" />
                        <div
                            class="overlay u-round-40 w-100 h-100 position-absolute d-flex justify-content-center align-items-center flex-column"
                            style="top: 0; left: 0; background-color: rgba(0, 0, 0, 0.8)">
                            <ul>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        가글마취
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        도포마취
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        무통마취
                                    </p>
                                </li>
                                <li>
                                    <p
                                        class="u-txt-white u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                                        의식하진정
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h6 class="u-txt-dark t-fs-28 u-lh-14 u-ls-10 fw-600 text-center">
                        통증경감 시스템
                    </h6>
                </div>
            </div>
        </div>
    </section>
    <section id="sect03" class="u-bg-light u-py-150">
        <div class="u-fluid u-fluid-xl-sm">
            <div class="mx-auto d-flex flex-column justify-content-center align-items-center sectTitle u-mb-60"
                data-aos="fade-up" data-aos-duration="1000">
                <h6 class="t-fs-20 fw-bold u-txt-sub u-lh-14 u-ls-10 text-center u-mb-10">DENTIST STORY</h6>
                <h3 class="fw-bold t-fs-48 u-lh-14 u-ls-15 u-txt-dark u-mb-28">서울다온치과 임상 증례</h3>
                <p class="u-txt-gray-700 u-lh-16 u-ls-10 fw-400 c-fs-20 text-center">
                    치아의 형태와 고민은 환자마다 모두 다릅니다.<br />
                    서울다온치과는 획일적인 치료가 아닌,<br class="d-block d-lg-none" />
                    100명의 환자에게 100가지 맞춤 치료를 설계합니다.
                </p>
            </div>

            <!-- 탭 버튼 -->
            <div class="tabs w-100 mx-auto u-mb-100" data-aos="fade-up" data-aos-duration="1000">
                <ul class="w-100 g-cols-fit-12 g-flex-3 u-gap-20 mx-auto"
                    data-aos="fade-up" data-aos-delay="500" data-aos-duration="1000">
                    <li>
                        <button type="button"
                            class="tab-btn u-solid u-bd-1 u-bc-gray-300 u-round-8 c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16 active"
                            data-tab="tab-all">전체</button>
                    </li>
                    <li>
                        <button type="button"
                            class="tab-btn u-solid u-bd-1 u-bc-gray-300 u-round-8 c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="implant">임플란트</button>
                    </li>
                    <li>
                        <button type="button"
                            class="tab-btn u-solid u-bd-1 u-bc-gray-300 u-round-8 c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="cosmetic">심미치료</button>
                    </li>
                    <li>
                        <button type="button"
                            class="tab-btn u-solid u-bd-1 u-bc-gray-300 u-round-8 c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="natural">자연치아 살리기</button>
                    </li>
                    <li>
                        <button type="button"
                            class="tab-btn u-solid u-bd-1 u-bc-gray-300 u-round-8 c-fs-18 fw-500 u-lh-16 u-ls-15 w-100 u-txt-gray-500 u-py-16"
                            data-tab="etc">기타</button>
                    </li>
                </ul>
            </div>

            <!-- 탭 컨테이너 -->
            <div class="tab-container u-mb-60" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500">

                <!-- 전체 -->
                <div class="tab-contents g-cols-fit-12 g-flexble-2 u-gap-24" id="tab-all">
                    <?php if (!empty($review_all)):
                        foreach ($review_all as $rv) echo render_review_card($rv, $is_logged_in);
                    else: echo render_empty_tab();
                    endif; ?>
                </div>

                <!-- 임플란트 -->
                <div class="tab-contents g-cols-fit-12 g-flexble-2 u-gap-24" id="implant">
                    <?php if (!empty($review_tabs['implant'])):
                        foreach ($review_tabs['implant'] as $rv) echo render_review_card($rv, $is_logged_in);
                    else: echo render_empty_tab();
                    endif; ?>
                </div>

                <!-- 심미치료 -->
                <div class="tab-contents g-cols-fit-12 g-flexble-2 u-gap-24" id="cosmetic">
                    <?php if (!empty($review_tabs['cosmetic'])):
                        foreach ($review_tabs['cosmetic'] as $rv) echo render_review_card($rv, $is_logged_in);
                    else: echo render_empty_tab();
                    endif; ?>
                </div>

                <!-- 자연치아 살리기 -->
                <div class="tab-contents g-cols-fit-12 g-flexble-2 u-gap-24" id="natural">
                    <?php if (!empty($review_tabs['natural'])):
                        foreach ($review_tabs['natural'] as $rv) echo render_review_card($rv, $is_logged_in);
                    else: echo render_empty_tab();
                    endif; ?>
                </div>

                <!-- 기타 -->
                <div class="tab-contents g-cols-fit-12 g-flexble-2 u-gap-24" id="etc">
                    <?php if (!empty($review_tabs['etc'])):
                        foreach ($review_tabs['etc'] as $rv) echo render_review_card($rv, $is_logged_in);
                    else: echo render_empty_tab();
                    endif; ?>
                </div>

            </div>

            <div class="w-100" data-aos="fade-up" data-aos-duration="1000" data-aos-delay="600">
                <button type="button"
                    class="u-round-full u-bg-white u-txt-sub mx-auto u-py-14 u-px-40 c-fs-20 u-lh-16 u-ls-10 d-flex justify-content-between align-items-center u-lift u-bd-n">
                    임상증례 전체 보기
                    <span class="material-symbols-outlined">arrow_right_alt</span>
                </button>
            </div>
        </div>
    </section>
    <section id="sect04" class="u-pt-150">
        <div class="u-fluid u-fluid-xl-sm">
            <div
                class="mx-auto d-flex flex-column justify-content-center align-items-start align-items-lg-center sectTitle u-mb-120 u-mb-40-sm"
                data-aos="fade-up"
                data-aos-duration="1000">
                <h6 class="t-fs-20 fw-bold u-txt-sub u-lh-14 u-ls-10 text-center u-mb-10">DOCTOR</h6>
                <h3 class="fw-400 t-fs-48 u-lh-14 u-ls-15 u-txt-dark u-mb-28">
                    서울다온치과 <span class="fw-bold">의료진</span>
                </h3>
                <p class="u-txt-gray-700 u-lh-16 u-ls-10 fw-400 c-fs-20 text-start text-lg-center">
                    대학병원식 분과별 전문의 4인이 통증을 줄이기 위해<br class="d-block d-lg-none"> 끝까지 고민하는 진료로<br class="d-none d-lg-block" />
                    처음부터 끝까지 여러분의 치아를 책임집니다.
                </p>
            </div>

            <?php if (!empty($doctors)): ?>
                <div class="tab-container position-relative">
                    <?php foreach ($doctors as $di => $doc):
                        $tab_id    = 'doc' . str_pad($di + 1, 2, '0', STR_PAD_LEFT);
                        $main_img  = $doc['image']     ?: $no_img;
                        $sub_img   = $doc['sub_image'] ?: $no_img;
                        $is_first  = ($di === 0);

                        $degrees = json_decode($doc['degree'], true);
                        $careers = json_decode($doc['career'], true);
                    ?>
                        <div
                            class="tab-content <?php echo $is_first ? 'flex-column-reverse flex-lg-row' : ''; ?> justify-content-between align-items-end<?php echo $is_first ? ' active' : ''; ?>"
                            <?php echo $is_first ? 'style="top:0;left:0"' : ''; ?>
                            id="<?php echo $tab_id; ?>">

                            <!-- 메인 이미지 -->
                            <div>
                                <img
                                    data-aos="fade-in"
                                    data-aos-duration="1000"
                                    class="w-100 h-100"
                                    src="<?php echo htmlspecialchars($main_img); ?>"
                                    alt="<?php echo htmlspecialchars($doc['name']); ?>" />
                            </div>

                            <!-- 우측 정보 영역 -->
                            <div class="w-100-sm">
                                <!-- 탭 버튼 목록 (모든 패널에 동일하게 렌더링) -->
                                <div class="d-flex u-gap-36 tabs u-mb-40">
                                    <?php foreach ($doctors as $ti => $td):
                                        $t_tab_id  = 'doc' . str_pad($ti + 1, 2, '0', STR_PAD_LEFT);
                                        $t_sub_img = $td['sub_image'] ?: $no_img;
                                        $is_active = ($ti === $di);
                                        $delays    = [500, 600, 700, 800, 900];
                                        $delay     = $delays[$ti] ?? 500;
                                    ?>
                                        <div
                                            class="doc-btn u-op-6 cursor-pointer u-round-full<?php echo $is_active ? ' active' : ''; ?>"
                                            data-aos="fade-up"
                                            data-aos-delay="<?php echo $delay; ?>"
                                            data-aos-duration="1000"
                                            data-tab="<?php echo $t_tab_id; ?>">
                                            <img
                                                class="u-round-full w-100"
                                                src="<?php echo htmlspecialchars($t_sub_img); ?>"
                                                alt="<?php echo htmlspecialchars($td['name']); ?>" />
                                            <p class="u-txt-gray-500 c-fs-20 fw-400 text-center u-lh-14 u-ls-10 u-mt-14 c-fs-12-sm">
                                                <?php echo htmlspecialchars($td['name']); ?> <?php echo htmlspecialchars($td['position']); ?>
                                            </p>
                                        </div>
                                    <?php endforeach; ?>
                                </div>

                                <!-- 의사 정보 -->
                                <div class="u-mb-90">
                                    <div class="u-mb-60">
                                        <!-- 이름 + 직위 (DB) -->
                                        <div class="d-flex align-items-end u-gap-20 u-mb-20">
                                            <h1 class="u-txt-dark u-lh-14 u-ls-48 fw-bold t-fs-56">
                                                <?php echo htmlspecialchars($doc['name']); ?>
                                            </h1>
                                            <p class="u-txt-dark fw-400 c-fs-28 u-lh-18 u-ls-10">
                                                <?php echo htmlspecialchars($doc['position']); ?>
                                            </p>
                                        </div>

                                        <!-- 슬로건 (고정 텍스트) -->
                                        <h6 class="u-txt-dark fw-400 u-lh-14 u-ls-10 c-fs-28 u-mb-30">
                                            치료 결과 만큼이나<br />
                                            치료 과정에서의
                                            <span class="u-txt-sub fw-bold">통증과 불안을 줄이기 위해</span><br />
                                            <strong class="fw-bold">끝까지 고민합니다.</strong>
                                        </h6>

                                        <!-- 설명 (고정 텍스트) -->
                                        <p class="fw-lg-600 c-fs-28 u-lh-14 u-ls-10 u-txt-gray-700 c-fs-14-sm fw-400">
                                            빠른 치료보다 정확한 판단을,<br />
                                            편한 설명과 신중한 선택으로<br class="d-block d-lg-none" />
                                            환자가 안심할 수 있는 진료를 지향합니다.
                                        </p>
                                    </div>

                                    <button
                                        type="button"
                                        class="u-round-full u-gap-10 u-bg-white u-txt-sub u-py-20 u-px-30 c-fs-20 u-lh-16 u-ls-10 d-flex justify-content-between align-items-center u-lift u-bd-n">
                                        더보기
                                        <span class="material-symbols-outlined">arrow_right_alt</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <section id="sect045">
        <div class="img-slider w-100 u-mt-80">
            <div class="img-slider-track d-flex u-gap-60">
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
            </div>
        </div>
    </section>
    <section id="sect05" class="u-pt-150">
        <div class="u-fluid">
            <div
                class="d-flex justify-content-between flex-column flex-md-row u-gap-50-sm">
                <aside class="position-sticky">
                    <h6 class="u-txt-sub u-mb-10 fw-bold t-fs-20 u-lh-14 u-ls-10">
                        Patient Care System
                    </h6>
                    <h4 class="fw-bold t-fs-46 u-lh-14 u-ls-15 u-txt-white u-mb-28">
                        진료 시스템
                    </h4>
                    <p class="u-txt-gray-300 c-fs-20 fw-400 u-lh-16 u-ls-10">
                        많은 환자분들이 서울다온치과를 선택한<br />
                        확실한 이유가 여기 있습니다.
                    </p>
                </aside>
                <div
                    class="d-flex u-gap-60 scroll-container u-pb-30 u-pb- flex-column flex-lg-row u-pb-80-sm">
                    <div class="d-flex flex-column u-gap-60 u-pt-72">
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="400">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="600">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="800">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                    </div>
                    <div class="d-flex flex-column u-gap-60">
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="300">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="500">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="700">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                        <div
                            class="box u-round-20 u-bg-light u-p-40 u-ratio-1-1 position-relative"
                            data-aos="fade-up"
                            data-aos-duration="1000"
                            data-aos-delay="900">
                            <h6 class="u-txt-sub fw-bold t-fs-20 u-lh-14 u-ls-10 u-mb-10">
                                System02
                            </h6>
                            <h5
                                class="fw-600 t-fs-28 u-ls-10 u-lh-14 u-txt-dark u-mb-22 t-fs-40-sm">
                                통증과 불안까지 고려한<br />
                                통증경감 시스템
                            </h5>
                            <p
                                class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-20-sm">
                                안심하고 치료를 이어갈 수 있도록<br />
                                처음부터 끝까지 책임지는 진료 시스템을 지향
                            </p>
                            <div class="position-absolute">
                                <img src="/images/boxLogo.svg" alt="" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="sect06" class="u-bg-light2 ">
        <!-- Slide Section -->
        <div
            class="slide-wrap  u-px-150 u-px-20-sm d-none d-lg-block"
            style="
            background-image: url(&quot;/images/sect06bg.png&quot;);
            background-position: unset;
            background-size: 100vw 100vh;
          ">
            <div class="sticky">
                <!-- Desktop Version -->
                <div class="pc u-fluid u-fluid-xl-sm d-none d-lg-block">
                    <!-- Left Text -->
                    <div class="left-text">
                        <ul class="service-list d-flex flex-column u-gap-16">
                            <li class="active c-fs-20 fw-600 u-lh-160 u-ls-15">
                                01. 분과별 전문의 협진
                            </li>
                            <li class="c-fs-20 fw-600 u-lh-160 u-ls-15">
                                02. 임플란트 식립 갯수
                            </li>
                            <li class="c-fs-20 fw-600 u-lh-160 u-ls-15">
                                03. 독립된 집중치료실
                            </li>
                        </ul>
                    </div>

                    <!-- Center Image -->
                    <div class="img-box">
                        <img
                            src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=450&h=600&fit=crop"
                            alt=""
                            class="img show" />
                        <img
                            src="https://images.unsplash.com/photo-1598256989800-fe5f95da9787?w=450&h=600&fit=crop"
                            alt=""
                            class="img" />
                        <img
                            src="https://images.unsplash.com/photo-1629909615184-74f495363b67?w=450&h=600&fit=crop"
                            alt=""
                            class="img" />
                    </div>

                    <!-- Right Text -->
                    <div class="right-text">
                        <h3
                            class="sub-title u-txt-dark u-lh-14 t-fs-36 u-ls-10 fw-600 u-mb-4">
                            처음부터 오래 사용할 수 있도록,<br />


                        </h3>
                        <h2 class="main-title u-lh-14 t-fs-36 u-ls-10 fw-600 u-mb-20 u-txt-sub"> 처음부터 다르게 설계합니다.</h2>
                        <p
                            class="description fw-400 c-fs-20 u-lh-16 u-ls-15 u-txt-gray-700">
                            대학병원에 가지 않아도 집 근처에서 일반진료 부터<br />
                            고난이도 진료까지 포괄적인 진료가 가능
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="slide-wrap d-block d-lg-none">
            <div class="swiper swiper-service2">
                <div class="swiper-wrapper">
                    <!-- Slide 1 -->
                    <div class="swiper-slide">
                        <p
                            class="slide-number-title u-txt-dark t-fs-48 u-lh-14 u-ls-15 fw-600">
                            01. 분과별 전문의 협진
                        </p>
                        <div class="img-box">
                            <img
                                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?w=450&h=600&fit=crop"
                                alt="" />
                        </div>
                        <div class="text-content">
                            <h3
                                class="slide-title c-fs-24-sm fw-600 u-lh-14 u-ls-10 u-txt-dark u-mb-20">
                                대학병원급 분과별<br /><span class="u-txt-sub">4인 전문의 협진</span>
                            </h3>
                            <p
                                class="slide-desc c-fs-16-sm fw-400 u-lh-15 u-ls-10 u-txt-gray-700">
                                대학병원에 가지 않아도 집 근처에서 일반진료 부터<br />고난이도
                                진료까지 포괄적인 진료가 가능
                            </p>
                        </div>
                    </div>

                    <!-- Slide 2 -->
                    <div class="swiper-slide">
                        <p
                            class="slide-number-title u-txt-dark t-fs-48 u-lh-14 u-ls-15 fw-600">
                            02. 임플란트 식립
                        </p>
                        <div class="img-box">
                            <img
                                src="https://images.unsplash.com/photo-1598256989800-fe5f95da9787?w=450&h=600&fit=crop"
                                alt="" />
                        </div>
                        <div class="text-content">
                            <h3
                                class="slide-title c-fs-24-sm fw-600 u-lh-14 u-ls-10 u-txt-dark u-mb-20">
                                누적 식립 <span class="u-txt-sub">1만 건</span> 이상
                                <br />숫자가 증명하는 차별화된 전문성
                            </h3>
                            <p
                                class="slide-desc c-fs-16-sm fw-400 u-lh-15 u-ls-10 u-txt-gray-700">
                                26년 3월 기준<br />
                                임플란트 누적 식립 개수
                            </p>
                        </div>
                    </div>

                    <!-- Slide 3 -->
                    <div class="swiper-slide">
                        <p
                            class="slide-number-title u-txt-dark t-fs-48 u-lh-14 u-ls-15 fw-600">
                            03. 가정동 대형 치과
                        </p>
                        <div class="img-box">
                            <img
                                src="https://images.unsplash.com/photo-1629909615184-74f495363b67?w=450&h=600&fit=crop"
                                alt="" />
                        </div>
                        <div class="text-content">
                            <h3
                                class="slide-title c-fs-24-sm fw-600 u-lh-14 u-ls-10 u-txt-dark u-mb-20">
                                가정동
                                <span class="u-txt-sub">150평 대형치과</span>,<br />독립된
                                집중치료실 구축
                            </h3>
                            <p
                                class="slide-desc c-fs-16-sm fw-400 u-lh-15 u-ls-10 u-txt-gray-700">
                                환자 한 분 한 분에게 온전히 집중하고, <br />편안한
                                상태에서의 최선의 치료 결과를 제공하기 위함
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Pagination -->
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </section>
    <section id="sect07" class="u-py-150">
        <div class="u-fluid u-fluid-xl-sm">
            <div
                class="mx-auto d-flex flex-column justify-content-center align-items-center sectTitle u-mb-60"
                data-aos="fade-up"
                data-aos-duration="1000">
                <h6
                    class="t-fs-20 fw-bold u-txt-sub u-lh-14 u-ls-10 text-center u-mb-10">
                    NEWS
                </h6>
                <h3
                    class="fw-400 t-fs-48 u-lh-14 u-ls-15 u-txt-dark u-mb-28 text-center text-lg-start">
                    <strong class="fw-bold">언론에서 주목하는</strong><br class="d-block d-lg-none" />
                    서울다온치과
                </h3>
            </div>
            <div
                class="d-flex align-items-center justify-content-between flex-column flex-lg-row"
                data-aos="fade-up"
                data-aos-duration="1000">
                <div>
                    <img class="w-100" src="/images/sect07News.png" alt="" />
                </div>
                <div class="u-mt-40-sm">
                    <div class="d-flex u-gap-38 u-mb-60 u-gap-60-sm">
                        <div>
                            <h6 class="t-fs-20 u-lh-14 u-ls-10 fw-600 u-txt-sub u-mb-10">
                                서울다온치과 신병열 대표원장
                            </h6>
                            <h2
                                class="t-fs-48 fw-bold u-lh-14 u-ls-15 u-txt-dark t-fs-24-sm">
                                대한민국 100대 명의<br />'임플란트' 부문 수상
                            </h2>
                        </div>
                        <div>
                            <img src="/images/sect07Medal.png" alt="" />
                        </div>
                    </div>
                    <div>
                        <h2 class="fw-bold t-fs-36 u-lh-14 u-ls-10 u-txt-dark u-mb-22">
                            "임플란트, <br />
                            한 번의 선택이 평생을 좌우한다"
                        </h2>
                        <p
                            class="u-txt-gray-700 fw-400 c-fs-20 u-lh-16 u-ls-10 c-fs-16-sm">
                            치료의 기본 원칙은 언제나 자연 치아 보존에 있으며, <br />
                            임플란트는 최선이 아닌 차선의 선택이라는 인식이 필요하다.
                            <br />
                            결국 임플란트 치료의 성공 여부는 정확한 진단과
                            <br class="d-block d-lg-none" />
                            체계적인 치료 계획, <br class="d-none d-lg-block" />
                            그리고 이를 실행하는 의료진의 경험과
                            <br class="d-block d-lg-none" />
                            철학에 달려 있다고 할 수 있다.
                        </p>
                    </div>
                </div>
            </div>
            <button
                type="button"
                data-aos="fade-up"
                data-aos-duration="1000"
                data-aos-delay="500"
                class="mx-auto u-mt-60 u-round-full u-gap-10 u-bg-gray-100 u-txt-sub u-py-20 u-px-30 c-fs-20 u-lh-16 u-ls-10 d-flex justify-content-between align-items-center u-lift u-bd-n">
                기사 보러 가기
                <span class="material-symbols-outlined"> arrow_right_alt </span>
            </button>
        </div>
        <em
            class="d-block u-fluid u-fluid-xl-sm w-100 u-bg-sub u-my-150 u-op-3"
            style="height: 1px"></em>
        <div class="u-fluid u-fluid-xl-sm">
            <div class="mx-auto d-flex flex-column justify-content-center align-items-center sectTitle u-mb-60"
                data-aos="fade-up" data-aos-duration="1000">
                <h6 class="t-fs-20 fw-bold u-txt-sub u-lh-14 u-ls-10 text-center u-mb-10">COLUMN</h6>
                <h3 class="fw-bold t-fs-48 u-lh-14 u-ls-15 u-txt-dark u-mb-28 u-txt-center">
                    서울다온치과 <strong class="fw-bold">원장님 칼럼</strong>
                </h3>
            </div>

            <div class="g-cols-fit-12 g-flexible-2 u-gap-24 u-mb-60 g-flexible-1-sm"
                data-aos="fade-up" data-aos-duration="1000">
                <?php if (!empty($columns)): ?>
                    <?php foreach ($columns as $col): ?>
                        <div class="box u-press shadow-soft">
                            <a href="/sub/column.php?wr_id=<?php echo $col['wr_id']; ?>&bo_table=<?php echo COLUMN_BOARD; ?>" class="d-block w-100 h-100">
                                <div>
                                    <img class="w-100" src="<?php echo htmlspecialchars($col['thumb']); ?>" alt="" />
                                    <div class="u-p-30">
                                        <h6 class="u-txt-gray-800 u-lh-14 u-ls-10 c-fs-20 fw-400 u-mb-8"><?php echo htmlspecialchars($col['subject']); ?></h6>
                                        <p class="c-fs-16 u-lh-16 u-ls-10 u-txt-gray-700 fw-400"><?php echo $col['date']; ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="w-100 text-center u-py-60 u-txt-gray-500 c-fs-18">
                        등록된 칼럼이 없습니다.
                    </div>
                <?php endif; ?>
            </div>

            <button type="button"
                data-aos="fade-up" data-aos-duration="1000" data-aos-delay="500"
                onclick="location.href='/sub/column_list.php'"
                class="mx-auto u-round-full u-gap-10 u-bg-gray-100 u-txt-sub u-py-20 u-px-30 c-fs-20 u-lh-16 u-ls-10 d-flex justify-content-between align-items-center u-lift u-bd-n">
                원장님 칼럼 더보기
                <span class="material-symbols-outlined">arrow_right_alt</span>
            </button>
        </div>
    </section>
    <section id="sect08" data-aos="fade-in" data-aos-duration="1000">
        <img
            class="w-100 d-none d-lg-block"
            src="/images/sect08Img.png"
            alt="서울다온치과" />
        <img
            class="w-100 d-block d-lg-none"
            src="/images/sect08Imgsm.png"
            alt="서울다온치과" />
    </section>
    <section id="sect09" class="u-py-150 u-pb-0-sm">
        <div class="u-fluid u-fluid-xl-sm">
            <div
                class="mx-auto d-flex flex-column justify-content-center align-items-center sectTitle u-mb-60"
                data-aos="fade-up"
                data-aos-duration="1000">
                <h6
                    class="t-fs-20 fw-bold u-txt-sub u-lh-14 u-ls-10 text-center u-mb-10">
                    INTERIOR
                </h6>
                <h3 class="fw-400 t-fs-48 u-lh-14 u-ls-15 u-txt-dark u-mb-28">
                    서울다온치과 <strong class="fw-bold"> 인테리어 </strong>
                </h3>
            </div>
            <div>
                <!-- 탭 버튼 -->
                <div class="sect09-tabs d-flex u-gap-20 u-mb-100 mx-auto w-100">
                    <button
                        data-aos="fade-up"
                        data-aos-duration="1000"
                        class="sect09-tab-btn w-100 u-px-80 u-px-40-sm u-py-16 u-shimmer u-solid u-bd-1 u-bc-gray-300 u-bg-white fw-400 c-fs-20 u-lh-14 u-ls-10 active u-round-4"
                        data-tab="tab1">
                        1F
                    </button>
                    <button
                        data-aos="fade-up"
                        data-aos-duration="1000"
                        data-aos-delay="300"
                        class="sect09-tab-btn w-100 u-px-80 u-px-40-sm u-py-16 u-shimmer u-solid u-bd-1 u-bc-gray-300 u-bg-white fw-400 c-fs-20 u-lh-14 u-ls-10 u-round-4"
                        data-tab="tab2">
                        2F
                    </button>
                    <button
                        data-aos="fade-up"
                        data-aos-duration="1000"
                        data-aos-delay="500"
                        class="sect09-tab-btn w-100 u-px-80 u-px-40-sm u-py-16 u-shimmer u-solid u-bd-1 u-bc-gray-300 u-bg-white fw-400 c-fs-20 u-lh-14 u-ls-10 u-round-4"
                        data-tab="tab3">
                        3F
                    </button>
                </div>

                <!-- 탭 컨텐츠 -->
                <div
                    class="sect09-tab-content active"
                    id="tab1"
                    data-aos="fade-up"
                    data-aos-duration="1000">
                    <div class="swiper swiper-tab1">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f01.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f01sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-4 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>01</span>
                                        안내데스크
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f02.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f02sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-4 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>02</span>
                                        대기실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f03.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f03sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>03</span>
                                        대기실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f04.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f04sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>04</span>
                                        상담실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f05.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f05sm.png"
                                    alt="" />>
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>05</span>
                                        파우더룸
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f06.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f06sm.png"
                                    alt="" />>
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>06</span>
                                        회복실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/1f07.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/1f07sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>07</span>
                                        진료실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div
                    class="sect09-tab-content"
                    id="tab2"
                    data-aos="fade-up"
                    data-aos-duration="1000">
                    <div class="swiper swiper-tab2">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f01.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f01sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>01</span>
                                        대기실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f02.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f02sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>02</span>
                                        상담실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f03.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f03sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>03</span>
                                        파우더룸
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f04.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f04sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>04</span>
                                        진료실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f05.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f05sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>05</span>
                                        소독실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f06.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f06sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>06</span>
                                        진료실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/2f07.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/2f07sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>07</span>
                                        임플란트실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div
                    class="sect09-tab-content"
                    id="tab3"
                    data-aos="fade-up"
                    data-aos-duration="1000">
                    <div class="swiper swiper-tab3">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/3f01.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/3f01sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>01</span>
                                        진료실 복도
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/3f02.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/3f02sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>02</span>
                                        진료실 복도
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/3f03.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/3f03sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>03</span>
                                        룸 진료실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide position-relative u-ratio-7-6-sm">
                                <img
                                    class="w-100 d-none d-lg-block"
                                    src="/images/3f04.png"
                                    alt="" />
                                <img
                                    class="w-100 d-block d-lg-none"
                                    src="/images/3f04sm.png"
                                    alt="" />
                                <div
                                    class="placeTitle d-flex position-absolute col-12 col-lg-3 justify-content-between">
                                    <h4
                                        class="u-txt-white fw-600 t-fs-28 u-lh-14 u-ls-10 u-gap-24 u-p-30 u-pr-0 d-flex align-items-center">
                                        <span>04</span>
                                        룸 진료실
                                    </h4>
                                    <div class="d-flex col-6">
                                        <div
                                            class="swiper-button-prev u-bg-transparent u-txt-white col-6 h-100"></div>
                                        <div
                                            class="swiper-button-next u-bg-sub u-txt-white col-6 h-100"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <div class="swiper-pagination"></div> -->
                    </div>
                </div>
            </div>
        </div>

        <div class="img-slider w-100 u-mt-80">
            <div class="img-slider-track d-flex u-gap-60">
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
                <img class="w-max" src="/images/maruburi.svg" alt="다온" />
            </div>
        </div>
    </section>
</main>


<!-- 스무스 스크롤 -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    });
</script>

<?php
include_once(G5_PATH . '/tail.php');
include_once(G5_PATH . '/tail_sub.php');
?>