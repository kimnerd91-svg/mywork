<?php
if (!defined('_GNUBOARD_')) exit;

// 1. [핵심수정] 팝업 매니저가 저장하는 dm_popup 테이블에서 설정값 가져오기
$conf_sql = " SELECT cf_popup_type FROM `dm_popup` LIMIT 1 ";
$conf_res = sql_fetch($conf_sql);
$current_mode = (isset($conf_res['cf_popup_type']) && $conf_res['cf_popup_type']) ? $conf_res['cf_popup_type'] : 'general';

$cur_time = date('Y-m-d H:i:s');

// 2. 활성화된 팝업 리스트 가져오기 (링크 필드 추가)
$sql = " SELECT * FROM dm_popup 
         WHERE nw_status = 1 
         AND nw_begin_time <= '$cur_time' 
         AND nw_end_time >= '$cur_time' 
         ORDER BY nw_id ASC ";
$result = sql_query($sql);

$popup_count = sql_num_rows($result);
echo "<script>console.log('현재 설정 모드: {$current_mode}');</script>";
echo "<script>console.log('활성화된 팝업 개수: {$popup_count}개');</script>";

$popups = [];
while ($row = sql_fetch_array($result)) {
    $ck_name = 'ck_pop_' . $row['nw_id'];
    
    // PHP에서 쿠키 확인
    if (isset($_COOKIE[$ck_name]) && $_COOKIE[$ck_name]) {
        continue; 
    }
    $active_ids[] = $row['nw_id'];

    // 이미지 경로 및 존재 여부 체크 (형님 원본 로직 유지)
    $img_file = trim($row['nw_img']);
    $img_path = G5_DATA_PATH . '/popup/' . $img_file;
    if (defined('G5_DATA_URL') && G5_DATA_URL) {
        $img_url = G5_DATA_URL . '/popup/' . $img_file;
    } else {
        $img_url = '/data/popup/' . $img_file;
    }

    $row['image_exists'] = ($img_file && file_exists($img_path));
    $row['img_url'] = $img_url;
    $row['img_file'] = $img_file;

    // 링크 정보 추가
    $row['nw_link'] = isset($row['nw_link']) ? trim($row['nw_link']) : '';
    $row['nw_target'] = isset($row['nw_target']) ? $row['nw_target'] : '_blank';

    $popups[] = $row;
}

if (count($popups) == 0) return;

// 3. 모드별 출력 분기
if ($current_mode == 'slide') {
?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <style>
        .pop-modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .pop-modal-content {
            position: relative;
            width: <?php echo $popups[0]['nw_width']; ?>px;
            background: #fff;
            box-shadow: 0 30px 60px rgba(0, 0, 0, 0.5);
        }


        .pop-swiper-container {
            width: 100%;
            height: <?php echo $popups[0]['nw_height']; ?>px;
        }

        .swiper-slide {
            position: relative;
        }

        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .swiper-slide.has-link {
            cursor: pointer !important;
        }

        .swiper-slide.has-link::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }

        /* 커스텀 페이지네이션 (텍스트 탭 형태) */
        .pop-pagination-custom {
            display: flex;
            background: #fff;
            border-top: 1px solid #eee;
        }

        .pop-pagination-item {
            flex: 1;
            padding: 12px 5px;
            text-align: center;
            font-size: 13px;
            color: #666;
            cursor: pointer;
            border-bottom: 3px solid #eee;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: all 0.3s;
            font-weight: 500;
        }

        .pop-pagination-item.swiper-pagination-bullet-active {
            color: #2196f3;
            border-bottom-color: #2196f3;
            background: #f8faff;
            font-weight: 800;
        }

        /* 하단 닫기 바 */
        .pop-modal-footer {
            background: #000;
            color: #fff;
            padding: 10px 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
        }

        .pop-modal-footer label {
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .pop-modal-footer a {
            color: #fff;
            text-decoration: none;
            font-size: 20px;
            font-weight: 300;
        }

        .swiper-pagination-bullet-active {
            height: auto !important;
            width: 100% !important;
            border-radius: 0 !important;
            background: #000 !important;
            border: none !important;
            margin: 0 !important;
            color: #fff !important;
            font-size: 16px !important;
        }

        .swiper-pagination-bullet {
            height: auto !important;
            width: 100% !important;
            border-radius: 0 !important;
            background: #ccc;
            border: none !important;
            margin: 0 !important;
            color: #fff !important;
            font-size: 16px !important;
        }

        @media screen and (max-width: 640px) {
            .pop-modal-content {
                width: 90vw !important;
                aspect-ratio: 1/1 !important;
            }

            .pop-swiper-container {
                height: 100% !important;
            }
             [id^="nw_pop_"] {
        max-width: 90vw !important;
        left: 5vw !important;
        /* transform: translateX(-50%); */
    }
    [id^="nw_pop_"] {
        width: 90vw !important;
        left: 5vw !important;
        right: auto !important;
    }
    [id^="nw_pop_"] a,
    [id^="nw_pop_"] > div:not([style*="background:#222"]) {
        width: 90vw !important;
        height: auto !important;
    }
    [id^="nw_pop_"] img {
        width: 100% !important;
        height: auto !important;
    }
        }
    </style>

    <div id="pop_modal_overlay" class="pop-modal-overlay">
        <div class="pop-modal-content">
            <div class="swiper pop-swiper-container">
                <div class="swiper-wrapper">
                    <?php foreach ($popups as $idx => $pop) { ?>
                        <div class="swiper-slide <?php echo $pop['nw_link'] ? 'has-link' : ''; ?>" data-slide-index="<?php echo $idx; ?>">
                            <img src="<?php echo $pop['img_url']; ?>" alt="<?php echo htmlspecialchars($pop['nw_subject']); ?>">
                        </div>
                    <?php } ?>
                </div>
            </div>

            <div class="pop-pagination-custom"></div>

            <div class="pop-modal-footer">
                <label><input type="checkbox" id="close_today_slide" onclick="close_modal_popup();" > 하루동안 보지 않기</label>
                <a href="javascript:void(0);" onclick="close_modal_popup();">✕</a>
            </div>
        </div>
    </div>

    <script>
        // 팝업 데이터 배열 생성
        var popupData = [
            <?php foreach ($popups as $pop) { ?> {
                    title: "<?php echo addslashes($pop['nw_subject']); ?>",
                    link: "<?php echo addslashes($pop['nw_link']); ?>",
                    target: "<?php echo $pop['nw_target']; ?>"
                },
            <?php } ?>
        ];

        var popSwiper = new Swiper('.pop-swiper-container', {
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false
            },
            pagination: {
                el: '.pop-pagination-custom',
                clickable: true,
                renderBullet: function(index, className) {
                    return '<div class="' + className + ' pop-pagination-item">' + popupData[index].title + '</div>';
                },
            },
            on: {
                click: function(swiper, event) {
                    // 실제 슬라이드 인덱스 가져오기 (loop 모드에서는 realIndex 사용)
                    var realIndex = swiper.realIndex;
                    var popup = popupData[realIndex];

                    console.log('클릭된 슬라이드:', realIndex);
                    console.log('링크:', popup.link);

                    if (popup.link) {
                        window.open(popup.link, popup.target);
                    }
                }
            }
        });

        function close_modal_popup() {
    var is_expire = document.getElementById('close_today_slide').checked;
    
    if (is_expire) {
        var date = new Date();
        // 오늘 날짜의 자정으로 설정
        date.setHours(23, 59, 59, 999);
        var expires = "expires=" + date.toUTCString();
        
        // 현재 로드된 모든 팝업에 대해 쿠키 생성
        <?php foreach ($popups as $pop) { ?>
            document.cookie = "ck_pop_<?php echo $pop['nw_id']; ?>=1; " + expires + "; path=/;";
        <?php } ?>
        
        console.log("쿠키 생성 완료: 내일 자정까지 유지");
    }
    
    document.getElementById('pop_modal_overlay').style.display = 'none';
}
    </script>

    <?php } else {
    // ==========================================
    // [B] 일반 개별형 (링크 기능 추가)
    // ==========================================
    foreach ($popups as $row) {
        $has_link = !empty($row['nw_link']);
    ?>
        <div id="nw_pop_<?php echo $row['nw_id']; ?>"
            style="position:fixed; top:<?php echo $row['nw_top']; ?>px; left:<?php echo $row['nw_left']; ?>px; z-index:10000; border:1px solid #ddd; background:#fff; box-shadow:0 10px 20px rgba(0,0,0,0.2); border-radius:8px; overflow:hidden;">

            <?php if ($has_link) { ?>
                <a href="<?php echo htmlspecialchars($row['nw_link']); ?>"
                    target="<?php echo $row['nw_target']; ?>"
                    style="display:block; line-height:0; width:<?php echo $row['nw_width']; ?>px; height:<?php echo $row['nw_height']; ?>px; text-decoration:none;">
                <?php } else { ?>
                    <div style="line-height:0; width:<?php echo $row['nw_width']; ?>px; height:<?php echo $row['nw_height']; ?>px;">
                    <?php } ?>

                    <?php if ($row['image_exists']) { ?>
                        <img src="<?php echo $row['img_url']; ?>"
                            alt="팝업"
                            style="display:block; width:<?php echo $row['nw_width']; ?>px; height:<?php echo $row['nw_height']; ?>px; object-fit:cover;"
                            onerror="handleImageError(this, <?php echo $row['nw_id']; ?>, '<?php echo addslashes($row['img_file']); ?>');">
                    <?php } else { ?>
                        <div style="padding:40px; background:#fff3e0; text-align:center; color:#e65100; display:flex; flex-direction:column; align-items:center; justify-content:center; width:100%; height:100%;"><strong>파일 없음</strong></div>
                    <?php } ?>

                    <?php if ($has_link) { ?>
                </a>
            <?php } else { ?>
        </div>
    <?php } ?>

    <div style="background:#222; color:#fff; padding:12px; text-align:right; font-size:12px;">
        <a href="javascript:void(0);" onclick="close_popup('<?php echo $row['nw_id']; ?>', 1); return false;" style="color:#fff; text-decoration:none;">오늘 하루 열지 않기</a>
        <span style="margin:0 10px; opacity:0.3;">|</span>
        <a href="javascript:void(0);" onclick="close_popup('<?php echo $row['nw_id']; ?>', 0); return false;" style="color:#fff; font-weight:700; text-decoration:none;">닫기</a>
    </div>
    </div>
<?php } ?>

<script>
    function close_popup(id, expire) {
        if (expire) {
            var date = new Date();
            date.setHours(23, 59, 59, 999);
            document.cookie = "ck_pop_" + id + "=1; path=/; expires=" + date.toUTCString();
        }
        var el = document.getElementById('nw_pop_' + id);
        if (el) {
            el.style.display = 'none';
            setTimeout(function() {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, 100);
        }
    }
</script>
<?php } ?>

<script>
    function handleImageError(img, popupId, filename) {
        console.error('❌ 로드 실패 - ID: ' + popupId);
        img.parentElement.innerHTML = '<div style="padding:20px; text-align:center; color:#c62828;">이미지 로드 실패</div>';
    }
    // 페이지 로드 시 쿠키를 체크하여 이미 닫은 팝업이면 숨김 처리
window.addEventListener('DOMContentLoaded', function() {
    <?php foreach ($popups as $pop) { ?>
        if (document.cookie.indexOf('ck_pop_<?php echo $pop['nw_id']; ?>=1') !== -1) {
            // 슬라이드 모드인 경우 전체 레이어 숨김
            var overlay = document.getElementById('pop_modal_overlay');
            if (overlay) overlay.style.display = 'none';
            
            // 일반 모드인 경우 해당 ID 숨김
            var singlePop = document.getElementById('nw_pop_<?php echo $pop['nw_id']; ?>');
            if (singlePop) singlePop.style.display = 'none';
        }
    <?php } ?>
});
</script>
<script>
if (window.innerWidth <= 640) {
    document.querySelectorAll('[id^="nw_pop_"]').forEach(function(el) {
        el.style.width = '98vw';
        el.style.left = '1vw';
        el.querySelectorAll('*').forEach(function(child) {
            child.style.width = '100%';
            child.style.height = 'auto';
        });
    });
}
</script>
