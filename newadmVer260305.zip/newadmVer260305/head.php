<?php
include_once('./_common.php');
$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
include_once(G5_PATH . '/head_sub.php');
?>

<?php
// GTM Body 코드 (noscript) 출력
if (isset($dm_conf['cf_add_body_script']) && $dm_conf['cf_add_body_script']) {
  echo stripslashes($dm_conf['cf_add_body_script']) . "\n";
}
?>

<!-- <header class="main-header z-header blur-12 u-bd-b-1 u-bc-gray-900">
    <div class="container d-flex justify-content-between align-items-center u-p-20">
        <div class="logo fw-800 c-fs-24">
            <a href="<?= G5_URL ?>" class="t-fs-28 fw-900 u-txt-main">
                <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']) { ?>
                    <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:50px;">
                <?php } else { ?>
                    <?= $dm_conf['cf_site_name'] ?: 'LOGO' ?>
                <?php } ?>
            </a>
        </div>

        <nav class="d-none d-md-flex align-items-center u-gap-32">
            <a href="#hero" class="u-txt-white fw-600 c-fs-14">Home</a>
            <a href="#review" class="u-txt-white fw-600 c-fs-14">Review</a>
            <a href="#gallery" class="u-txt-white fw-600 c-fs-14">Case</a>

            <?php if ($is_member) { ?>
                <span class="u-txt-white fw-600 c-fs-14"><?= $member['mb_nick'] ?>님</span>
                <a href="<?= G5_URL ?>/plugin/social_login/logout.php" class="u-txt-gray-600 fw-600">로그아웃</a>
            <?php } else { ?>
                <a href="<?= G5_BBS_URL ?>/login.php" class="u-txt-gray-600 fw-600">로그인</a>
            <?php } ?>

            <?php if ($is_admin == 'super') { ?>
                <a href="<?= G5_URL ?>/newadm/" class="u-txt-main fw-700">관리자</a>
            <?php } ?>
        </nav>
    </div>

</header> -->
<header class="demo-header header-flyout u-pretendard">
  <div
    class="w-100 header-container desktop-menu mx-auto d-none d-lg-block">
    <div
      class="d-flex justify-content-between align-items-center h-100 u-px-60 u-bg-white">
      <div class="logo t-fs-24">
        <a href="<?= G5_URL ?>" class="t-fs-28 fw-900 u-txt-main">
          <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']) { ?>
            <img class="w-100" src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:50px;">
          <?php } else { ?>
            <?= $dm_conf['cf_site_name'] ?: 'LOGO' ?>
          <?php } ?>
        </a>
      </div>
      <ul class="menu u-gap-30 g-auto-flow">
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            임플란트 클리닉
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
            <li>
              <a href="/sub/implant/csd_implant.php" class="c-fs-16 text-center">의식하진정 임플란트</a>
            </li>
            <li>
             <a href="/sub/implant/hl_01.php" class="c-fs-16 text-center">고난이도 임플란트</a>
            </li>
            <li>
              <a href="/sub/implant/navigation_implant.php" class="c-fs-16 text-center">네비게이션 임플란트</a>
            </li>
            <li>
              <a href="/sub/implant/extraction_implant.php" class="c-fs-16 text-center">발치즉시 임플란트</a>
            </li>
          </ul>
        </li>
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            심미치료 클리닉
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
            <li><a href="/sub/implant/simmi_01.php" class="c-fs-16 text-center">치아미백</a></li>
             <li><a href="/sub/implant/simmi_02.php" class="c-fs-16 text-center">라미네이트</a></li>
             <li><a href="/sub/implant/simmi_03.php" class="c-fs-16 text-center">레진치료</a></li>
            <li><a href="/sub/implant/simmi_04.php" class="c-fs-16 text-center">잇몸성형</a></li>
          </ul>
        </li>
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            자연치아 살리기 클리닉
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
            <li><a href="/sub/natural/natural_01.php" class="c-fs-16 text-center">충치치료</a></li>
            <li><a href="/sub/natural/natural_02.php"class="c-fs-16 text-center">잇몸치료</a></li>
            <li><a href="/sub/natural/natural_03.php" class="c-fs-16 text-center">신경치료</a></li>
          </ul>
        </li>
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            일반진료 클리닉
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
           <li><a href="/sub/general/general_01.php" class="c-fs-16 text-center">사랑니 발치</a></li>
             <li><a href="/sub/general/general_02.php" class="c-fs-16 text-center">스케일링</a></li>
            <li><a href="/sub/general/general_03.php" class="c-fs-16 text-center">턱관절 치료</a></li>
            <li><a href="/sub/general/general_04.php" class="c-fs-16 text-center">수액주사</a></li>
          </ul>
        </li>
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            통증 경감 시스템
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
             <li><a href="/sub/pain/pain_01.php"  class="c-fs-16 text-center">수면치료</a></li>
            <li><a href="/sub/pain/pain_02.php" class="c-fs-16 text-center">단계별 통증 경감 시스템</a>
            </li>
          </ul>
        </li>
        <li>
          <a
            href="#"
            class="t-fs-18 fw-400 text-center justify-content-center u-ls-15">
            서울다온치과
            <span class="material-symbols-outlined">
              keyboard_arrow_down
            </span>
          </a>
          <ul class="shadow-soft u-p-10 u-round-10 submenu u-bg-sub">
            <li><a href="/sub/introduce.php" class="c-fs-16 text-center">진료철학</a></li>
            <li>
              <a href="/sub/doctors.php" class="c-fs-16 text-center">의료진소개</a>
            </li>

            <li><a href="/sub/device.php" class="c-fs-16 text-center">장비소개</a></li>
            <li><a href="/sub/info.php" class="c-fs-16 text-center">오시는 길</a></li>
            <li><a href="/sub/case_list.php" class="c-fs-16 text-center">임상증례</a></li>
            <li><a href="/sub/column_list.php" class="c-fs-16 text-center">원장님 칼럼</a></li>
          </ul>
        </li>
      </ul>
      <!-- 슬라이더 -->
      <div class="promo-slider u-round-full">
        <div class="promo-content u-bg-main">
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/medal.svg" alt="" />임플란트 부문 대한민국
            <span class="u-txt-point fw-bold">100대 명의</span>
          </div>
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/hy.svg" alt="" />한양대학교 치과병원
            <span class="u-txt-point fw-bold">외래교수</span>
          </div>
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/imp.svg" alt="" />임플란트
            <span class="u-txt-point fw-bold">1만건 이상 식립</span>
          </div>
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/hos.svg" alt="" />가정동
            <span class="u-txt-point fw-bold">최대 규모 150평</span> 치과
          </div>
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/heart.svg" alt="" /><span
              class="u-txt-point fw-bold">통증을 줄이는</span>
            진료 시스템
          </div>
          <div
            class="promo-item c-fs-16 fw-400 u-gap-4 u-ls-10 text-center">
            <img src="/images/bag.svg" alt="" /><span
              class="u-txt-point fw-bold">안전한 수면</span>
            진료 시스템
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 모바일 헤더 -->
  <div class="header-container mobile-header d-block d-lg-none u-bg-white">
    <div class="d-flex justify-content-between align-items-center u-p-20">
      <div class="logo t-fs-24">
        <a href="<?= G5_URL ?>" class="t-fs-28 fw-900 u-txt-main">
          <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']) { ?>
            <img class="w-50-sm" src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:50px;">
          <?php } else { ?>
            <?= $dm_conf['cf_site_name'] ?: 'LOGO' ?>
          <?php } ?>
        </a>
      </div>
      <button
        class="hamburger-btn u-bd-n u-bg-transparent"
        data-bs-toggle="offcanvas"
        data-bs-target="#mobileMenu5"
        style="width: 30px; height: 30px">
        <span class="material-symbols-outlined">
          menu
        </span>
      </button>
    </div>
  </div>

  <!-- 모바일 Offcanvas -->
  <div
    class="offcanvas offcanvas-end offcanvas-dark u-bg-main"
    id="mobileMenu5">
    <div class="offcanvas-header justify-content-end d-flex u-py-24">
      <button
        type="button"
        class="u-bg-sub u-ratio-1-1 u-m-0 u-p-0 u-bd-n"
        style="width: 30px; height: 30px"
        data-bs-dismiss="offcanvas">
        <span class="material-symbols-outlined u-txt-white"> close </span>
      </button>
    </div>
    <div class="offcanvas-body u-p-0">
      <ul class="mobile-menu-list d-flex flex-column u-gap-30">
        <li class="mobile-menu-item">
          <a
            href="/sub/implant/csd_implant.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-1">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">임플란트 클리닉</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-1">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
             href="/sub/implant/csd_implant.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">의식하진정 임플란트</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
             href="/sub/implant/hl_01.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">고난이도 임플란트</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
             href="/sub/implant/navigation_implant.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">네비게이션 임플란트</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                 href="/sub/implant/extraction_implant.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">발치즉시 임플란트</a>
            </li>
          </ul>
        </li>
        <li class="mobile-menu-item">
          <a
        href="/sub/simmi/simmi_01.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-2">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">심미치료 클리닉</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-2">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                href="/sub/simmi/simmi_01.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">치아미백</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
           href="/sub/simmi/simmi_02.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">라미네이트</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
          href="/sub/simmi/simmi_03.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">레진치료</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
        href="/sub/simmi/simmi_04.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">잇몸성형</a>
            </li>
          </ul>
        </li>
        <li class="mobile-menu-item">
          <a
            href="/sub/natural/natural_01.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-3">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">자연치아 살리기 클리닉</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-3">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                href="/sub/natural/natural_01.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">충치치료</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
               href="/sub/natural/natural_02.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">잇몸치료</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
              href="/sub/natural/natural_03.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">신경치료</a>
            </li>
          </ul>
        </li>
        <li class="mobile-menu-item">
          <a
             href="/sub/general/general_01.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-4">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">일반진료 클리닉</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-4">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
               href="/sub/general/general_01.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">사랑니 발치</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
             href="/sub/general/general_02.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">스케일링</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
             href="/sub/general/general_03.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">턱관절 치료</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
          href="/sub/general/general_04.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">수액주사</a>
            </li>
          </ul>
        </li>
        <li class="mobile-menu-item">
          <a
          href="/sub/pain/pain_01.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-5">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">통증 경감 시스템</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-5">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                 href="/sub/pain/pain_01.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">수면치료</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
               href="/sub/pain/pain_02.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">단계별 통증 경감 시스템</a>
            </li>
          </ul>
        </li>
        <li class="mobile-menu-item">
          <a
            href="/sub/introduce.php"
            class="mobile-menu-link d-flex justify-content-between align-items-center u-px-30 u-py-10 t-fs-28 u-txt-white fw-600"
            data-bs-toggle="collapse"
            data-bs-target="#submenu5-6">
            <span class="t-fs-28 fw-400 u-ls-10 u-txt-white">서울다온치과</span>
            <i class="bi bi-chevron-down"></i>
          </a>
          <ul class="mobile-submenu collapse" id="submenu5-6">
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                href="/sub/introduce.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">진료철학</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
            href="/sub/doctors.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">의료진소개</a>
            </li>
               <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
              href="/sub/device.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">장비소개</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
              href="/sub/info.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">오시는 길</a>
            </li>
         
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
               href="/sub/case_list.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">임상증례</a>
            </li>
            <li
              class="u-bg-transparent u-py-10 u-px-30 d-flex align-items-center">
              <a
                 href="/sub/column_list.php"
                class="mobile-submenu-link c-fs-20 u-lh-15 u-ls-10 u-txt-gray-400">원장님 칼럼</a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</header>

<script type="text/javascript">
  (function() {
    // 중복 실행 방지
    if (window.googleTranslateInitialized) return;
    window.googleTranslateInitialized = true;

    var userLang = (navigator.language || navigator.userLanguage).toLowerCase();
    var target = 'ko';
    if (userLang.indexOf('ja') !== -1) target = 'ja';
    else if (userLang.indexOf('en') !== -1) target = 'en';

    var deleteCookie = function(name) {
      var domain = document.domain;
      var path = '/';
      document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + ";";
      document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + "; domain=" + domain + ";";
      document.cookie = name + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=" + path + "; domain=." + domain + ";";
    };

    if (target !== 'ko') {
      document.cookie = "googtrans=/ko/" + target + "; path=/;";
      document.cookie = "googtrans=/ko/" + target + "; domain=" + document.domain + "; path=/;";
    } else {
      deleteCookie('googtrans');
    }

    window.googleTranslateElementInit = function() {
      if (window.googleTranslateElement) return;
      window.googleTranslateElement = new google.translate.TranslateElement({
        pageLanguage: 'ko',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
        autoDisplay: false
      }, 'google_translate_element');
    };
  })();
</script>
<script>
  // AOS 중복 방지
  if (typeof AOS !== 'undefined' && !window.aosInitialized) {
    AOS.init();
    window.aosInitialized = true;
  }
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<style>
  .skiptranslate,
  .goog-te-banner-frame {
    display: none !important;
  }

  body {
    top: 0px !important;
  }
</style>
<div id="google_translate_element" style="display:none;"></div>