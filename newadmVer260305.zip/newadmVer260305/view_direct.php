<?php
include_once('./_common.php');

// URL 파라미터 받기
$bo_table = isset($_GET['bo_table']) ? preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']) : '';
$wr_id = isset($_GET['wr_id']) ? (int)$_GET['wr_id'] : 0;

if (!$bo_table || !$wr_id) {
    alert_toast("잘못된 접근입니다.", "./", "error");
    exit;
}

// 비포앤애프터 특별 처리
$is_beforeafter = ($bo_table == 'beforeafter');

if ($is_beforeafter) {
    // 비포앤애프터 테이블에서 데이터 가져오기
    $ba_table = 'dm_beforeafter';
    $view = sql_fetch("SELECT * FROM {$ba_table} WHERE id = '{$wr_id}'");
    
    if (!$view['id']) {
        alert_toast("존재하지 않는 게시물입니다.", "./", "error");
        exit;
    }
    
    // 로그인 여부 확인
    $is_logged_in = isset($_SESSION['ss_mb_id']) && $_SESSION['ss_mb_id'];
    
    if (!$is_logged_in) {
        alert_toast("회원 전용 콘텐츠입니다. 로그인 후 이용해주세요.", "/bbs/login.php", "error");
        exit;
    }
    
} else {
    // 일반 게시판 처리
    $write_table = $g5['write_prefix'] . $bo_table;
    $view = sql_fetch("SELECT * FROM {$write_table} WHERE wr_id = '{$wr_id}'");
    
    if (!$view['wr_id']) {
        alert_toast("존재하지 않는 게시물입니다.", "./", "error");
        exit;
    }
    
    // 조회수 증가
    sql_query("UPDATE {$write_table} SET wr_hit = wr_hit + 1 WHERE wr_id = '{$wr_id}'");
    
    // 카테고리 정보
    $ca_name = '';
    if (!empty($view['wr_10'])) {
        $category_table = $g5['write_prefix'] . $bo_table . '_category';
        $cat = sql_fetch("SELECT ca_name FROM {$category_table} WHERE ca_id = '{$view['wr_10']}'", false);
        if ($cat) {
            $ca_name = $cat['ca_name'];
        }
    }
}

include_once(G5_PATH . '/head_sub.php');
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="/css/direct_module.css">
<link rel="stylesheet" href="/css/setting.css">

<style>
header, .gnb, #hd { all: unset; display: block; }
a { text-decoration: none; }
.main-header { position: fixed; top: 0; left: 0; right: 0; background: rgba(10, 10, 10, 0.8); }

<?php if ($is_beforeafter): ?>
/* 비포앤애프터 전용 스타일 */
#direct_v_wrap {
    background-color: #222222;
}

.ba-slider-container {
    position: relative;
    aspect-ratio: 16 / 10;
    border-radius: var(--sp-16);
    overflow: hidden;
    background: var(--gray-800);
    margin-bottom: var(--sp-32);
}

.ba-slider-container img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.ba-img-before {
    z-index: 2;
    clip-path: inset(0 50% 0 0);
}

.ba-img-after {
    z-index: 1;
}

.ba-slider-handle {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 60px;
    height: 60px;
    background: var(--white);
    border-radius: 50%;
    cursor: ew-resize;
    z-index: 5;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
    display: flex;
    align-items: center;
    justify-content: center;
}

.ba-slider-handle::before {
    content: '';
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    width: 4px;
    height: 100vh;
    background: var(--white);
    z-index: -1;
}

.ba-slider-handle::after {
    content: '◀ ▶';
    font-size: 18px;
    letter-spacing: 4px;
    color: var(--gray-700);
}

.ba-info-section {
    padding: var(--sp-24);
    background: rgba(255, 255, 255, 0.05);
    border-radius: var(--sp-12);
    margin-bottom: var(--sp-24);
}

.ba-info-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: var(--sp-20);
    margin-bottom: var(--sp-24);
}

.ba-info-item {
    text-align: center;
}

.ba-info-label {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.5);
    margin-bottom: var(--sp-8);
    font-weight: 700;
    text-transform: uppercase;
}

.ba-info-value {
    font-size: 18px;
    color: var(--white);
    font-weight: 700;
}

.ba-description {
    color: rgba(255, 255, 255, 0.8);
    line-height: 1.8;
    white-space: pre-wrap;
    font-size: 15px;
}

@media (max-width: 768px) {
    .ba-info-grid {
        grid-template-columns: 1fr;
    }
}
<?php endif; ?>
</style>

<?php if (file_exists('./head.php')) include_once('./head.php'); ?>

<div class="d-flex w-100 h-100v justify-content-center" id="direct_v_wrap_wrap">
    <div id="direct_v_wrap">
        <aside class="v_side_info">
            <?php if ($is_beforeafter): ?>
            <!-- 비포앤애프터 좌측 정보 -->
            <span class="v_label"><?= $view['treatment_category'] ?: '기타' ?></span>
            <h1 class="v_subject"><?= htmlspecialchars($view['title']) ?></h1>

            <div class="v_meta_group">
                <?php if ($view['patient_age']): ?>
                <div class="v_meta_item">
                    <span class="meta_label">나이</span>
                    <span class="meta_value"><?= htmlspecialchars($view['patient_age']) ?></span>
                </div>
                <?php endif; ?>
                
                <?php if ($view['patient_gender']): ?>
                <div class="v_meta_item">
                    <span class="meta_label">성별</span>
                    <span class="meta_value"><?= htmlspecialchars($view['patient_gender']) ?></span>
                </div>
                <?php endif; ?>
                
                <?php if ($view['treatment_period']): ?>
                <div class="v_meta_item">
                    <span class="meta_label">시술 기간</span>
                    <span class="meta_value"><?= htmlspecialchars($view['treatment_period']) ?></span>
                </div>
                <?php endif; ?>
                
                <div class="v_meta_item">
                    <span class="meta_label">등록일</span>
                    <span class="meta_value"><?= date("Y.m.d", strtotime($view['created_at'])) ?></span>
                </div>
            </div>

            <div class="v_nav_buttons">
                <a href="javascript:history.back()" class="btn_v_list">목록</a>
                <?php if ($is_admin == 'super') { ?>
                    <a href="/newadm/hospital/beforeafter_manager.php" class="btn_v_edit">관리</a>
                <?php } ?>
            </div>
            
            <?php else: ?>
            <!-- 일반 게시판 좌측 정보 -->
            <span class="v_label"><?php echo $ca_name ?: '일반'; ?></span>
            <h1 class="v_subject"><?php echo htmlspecialchars($view['wr_subject']); ?></h1>

            <div class="v_meta_group">
                <div class="v_meta_item">
                    <span class="meta_label">작성자</span>
                    <span class="meta_value"><?php echo htmlspecialchars($view['wr_name']); ?></span>
                </div>
                <div class="v_meta_item">
                    <span class="meta_label">조회수</span>
                    <span class="meta_value"><?php echo number_format($view['wr_hit']); ?></span>
                </div>
                <div class="v_meta_item">
                    <span class="meta_label">작성일</span>
                    <span class="meta_value"><?php echo date("Y.m.d", strtotime($view['wr_datetime'])); ?></span>
                </div>
            </div>

            <div class="v_nav_buttons">
                <a href="<?php echo G5_URL; ?>/newadm/board/board_post_list.php?bo_table=<?php echo $bo_table; ?>" class="btn_v_list">목록</a>
                <?php if ($is_admin == 'super') { ?>
                    <a href="<?php echo G5_URL; ?>/newadm/board/write_direct.php?bo_table=<?php echo $bo_table; ?>&mode=modify&wr_id=<?php echo $wr_id; ?>" class="btn_v_edit">수정</a>
                <?php } ?>
            </div>
            <?php endif; ?>
        </aside>

        <main class="v_main_content">
            <?php if ($is_beforeafter): ?>
            <!-- 비포앤애프터 우측 콘텐츠 -->
            <div class="v_content_body u-mt-60">
                <!-- 슬라이더 -->
                <div class="ba-slider-container" id="baSlider">
                    <?php if ($view['image_before']): ?>
                        <img src="<?= htmlspecialchars($view['image_before']) ?>" alt="Before" class="ba-img-before" id="beforeImg">
                    <?php endif; ?>
                    <?php if ($view['image_after']): ?>
                        <img src="<?= htmlspecialchars($view['image_after']) ?>" alt="After" class="ba-img-after">
                    <?php endif; ?>
                    <div class="ba-slider-handle" id="sliderHandle"></div>
                </div>

                <!-- 상세 설명 -->
                <?php if ($view['description']): ?>
                <div class="ba-info-section">
                    <h3 style="color: var(--white); font-size: 20px; font-weight: 700; margin-bottom: var(--sp-16);">상세 설명</h3>
                    <div class="ba-description"><?= nl2br(htmlspecialchars($view['description'])) ?></div>
                </div>
                <?php endif; ?>
            </div>
            
            <?php else: ?>
            <!-- 일반 게시판 우측 콘텐츠 -->
            <div class="v_content_body">
                <?php echo stripslashes($view['wr_content']); ?>
            </div>
            <?php endif; ?>
        </main>
    </div>
</div>

<?php if ($is_beforeafter): ?>
<script>
// 슬라이더 드래그 기능
document.addEventListener('DOMContentLoaded', function() {
    const slider = document.getElementById('baSlider');
    const handle = document.getElementById('sliderHandle');
    const beforeImg = document.getElementById('beforeImg');
    
    if (!slider || !handle || !beforeImg) return;
    
    let isDragging = false;
    
    function updateSlider(clientX) {
        const rect = slider.getBoundingClientRect();
        const x = clientX - rect.left;
        const percentage = (x / rect.width) * 100;
        const clampedPercentage = Math.max(0, Math.min(100, percentage));
        
        handle.style.left = clampedPercentage + '%';
        beforeImg.style.clipPath = `inset(0 ${100 - clampedPercentage}% 0 0)`;
    }
    
    // 마우스 이벤트
    handle.addEventListener('mousedown', () => {
        isDragging = true;
    });
    
    document.addEventListener('mousemove', (e) => {
        if (isDragging) {
            updateSlider(e.clientX);
        }
    });
    
    document.addEventListener('mouseup', () => {
        isDragging = false;
    });
    
    // 터치 이벤트
    handle.addEventListener('touchstart', () => {
        isDragging = true;
    });
    
    document.addEventListener('touchmove', (e) => {
        if (isDragging) {
            updateSlider(e.touches[0].clientX);
        }
    });
    
    document.addEventListener('touchend', () => {
        isDragging = false;
    });
});
</script>
<?php endif; ?>

<?php include_once(G5_PATH . '/tail.sub.php'); ?>