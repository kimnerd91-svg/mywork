<?php
// newadm/device_manager.php
include_once('../_common.php');
include_once('../_auth_check.php');

// ============================================================
// 이미지 AJAX 업로드 처리
// ============================================================
if (isset($_FILES['eq_image']['name'])) {
    while (ob_get_level()) ob_end_clean();
    $upload_dir = G5_DATA_PATH . '/equipment/' . date('Ym');
    $upload_url = G5_DATA_URL  . '/equipment/' . date('Ym');
    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, G5_DIR_PERMISSION, true);
        @chmod($upload_dir, G5_DIR_PERMISSION);
    }
    $ext = strtolower(pathinfo($_FILES['eq_image']['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        header('Content-Type: application/json');
        echo json_encode(['success' => 0, 'message' => '이미지 파일만 업로드 가능합니다.']);
        exit;
    }
    $new_name = time() . '_' . md5(uniqid()) . '.' . $ext;
    if (move_uploaded_file($_FILES['eq_image']['tmp_name'], $upload_dir . '/' . $new_name)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => 1, 'url' => $upload_url . '/' . $new_name]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => 0, 'message' => '업로드 실패. 폴더 권한을 확인하세요.']);
    }
    exit;
}

// ============================================================
// 테이블 자동 생성
// ============================================================
sql_query("CREATE TABLE IF NOT EXISTS `dm_equipment` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `category` VARCHAR(100) NOT NULL DEFAULT '',
    `description` TEXT,
    `image_outer` VARCHAR(500) DEFAULT '',
    `image_inner` VARCHAR(500) DEFAULT '',
    `youtube_url` VARCHAR(500) DEFAULT '',
    `tags` VARCHAR(500) DEFAULT '',
    `display_order` INT(11) DEFAULT 0,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 기존 테이블에 tags 컬럼 없으면 자동 추가
$col_chk = sql_query("SHOW COLUMNS FROM dm_equipment LIKE 'tags'");
if (sql_num_rows($col_chk) == 0) {
    sql_query("ALTER TABLE dm_equipment ADD `tags` VARCHAR(500) DEFAULT '' AFTER `youtube_url`");
}

// ============================================================
// 삭제
// ============================================================
if (isset($_GET['delete_id'])) {
    sql_query("DELETE FROM dm_equipment WHERE id = " . (int)$_GET['delete_id']);
    alert_toast('장비가 삭제되었습니다.', './device_manager.php');
}

// ============================================================
// 추가
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'add_equipment') {
    $name          = sql_real_escape_string(trim($_POST['name']));
    $category      = sql_real_escape_string(trim($_POST['category']));
    $description   = sql_real_escape_string(trim($_POST['description']));
    $image_outer   = sql_real_escape_string(trim($_POST['image_outer']));
    $image_inner   = sql_real_escape_string(trim($_POST['image_inner']));
    $youtube_url   = sql_real_escape_string(trim($_POST['youtube_url']));
    $tags          = sql_real_escape_string(trim($_POST['tags']));
    $display_order = (int)$_POST['display_order'];
    sql_query("INSERT INTO dm_equipment SET
        name='{$name}', category='{$category}', description='{$description}',
        image_outer='{$image_outer}', image_inner='{$image_inner}',
        youtube_url='{$youtube_url}', tags='{$tags}',
        display_order='{$display_order}', created_at=NOW()");
    alert_toast('장비가 추가되었습니다.', './device_manager.php', 'success');
}

// ============================================================
// 수정
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'update_equipment') {
    $id            = (int)$_POST['id'];
    $name          = sql_real_escape_string(trim($_POST['name']));
    $category      = sql_real_escape_string(trim($_POST['category']));
    $description   = sql_real_escape_string(trim($_POST['description']));
    $image_outer   = sql_real_escape_string(trim($_POST['image_outer']));
    $image_inner   = sql_real_escape_string(trim($_POST['image_inner']));
    $youtube_url   = sql_real_escape_string(trim($_POST['youtube_url']));
    $tags          = sql_real_escape_string(trim($_POST['tags']));
    $display_order = (int)$_POST['display_order'];
    sql_query("UPDATE dm_equipment SET
        name='{$name}', category='{$category}', description='{$description}',
        image_outer='{$image_outer}', image_inner='{$image_inner}',
        youtube_url='{$youtube_url}', tags='{$tags}',
        display_order='{$display_order}'
        WHERE id={$id}");
    alert_toast('장비 정보가 수정되었습니다.', './device_manager.php', 'success');
}

// ============================================================
// 목록 조회
// ============================================================
$result = sql_query("SELECT * FROM dm_equipment ORDER BY display_order ASC, id ASC");
$equipments = [];
while ($row = sql_fetch_array($result)) $equipments[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>장비 관리 - NEW ADM</title>
    <style>
        #admin_wrapper { display:grid; grid-template-columns:280px 1fr; min-height:100vh; }
        .content_area  { background-color:var(--bg-soft); padding:var(--sp-40); }
        .card_custom   { background:#fff; border-radius:24px; padding:var(--sp-32); margin-bottom:24px; box-shadow:0 4px 20px rgba(0,0,0,.03); }

        .equipment-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:20px; }
        @media(max-width:1400px){ .equipment-grid{ grid-template-columns:repeat(3,1fr); } }
        @media(max-width:1024px){ .equipment-grid{ grid-template-columns:repeat(2,1fr); } }
        @media(max-width:640px) { .equipment-grid{ grid-template-columns:1fr; } }

        .eq-card { background:#fff; border-radius:16px; overflow:hidden; box-shadow:0 4px 16px rgba(0,0,0,.06); transition:transform .2s,box-shadow .2s; }
        .eq-card:hover { transform:translateY(-4px); box-shadow:0 8px 24px rgba(0,0,0,.1); }
        .eq-card .thumb { width:100%; aspect-ratio:4/3; object-fit:cover; display:block; }
        .eq-card .thumb-placeholder { width:100%; aspect-ratio:4/3; background:#f1f3f5; display:flex; align-items:center; justify-content:center; color:#adb5bd; font-size:14px; }
        .eq-card .eq-body { padding:16px; }
        .eq-card .eq-category { display:inline-block; background:#e7f5ff; color:#1971c2; font-size:12px; font-weight:600; padding:3px 10px; border-radius:100px; margin-bottom:8px; }
        .eq-card .eq-name { font-size:16px; font-weight:700; color:var(--dark); margin-bottom:6px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .eq-card .eq-desc { font-size:13px; color:#868e96; line-height:1.5; display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; margin-bottom:8px; }
        .eq-card .eq-tags { display:flex; flex-wrap:wrap; gap:4px; margin-bottom:12px; }
        .eq-card .eq-tag { background:#e7f5ff; color:#1971c2; font-size:11px; font-weight:600; padding:2px 8px; border-radius:100px; }
        .eq-card .eq-actions { display:flex; gap:8px; }

        .modal-content { border-radius:24px; overflow:hidden; border:0; }
        .form-label { font-weight:700; font-size:14px; display:block; margin-bottom:6px; }
        .form-input { width:100%; box-sizing:border-box; padding:10px 14px; border:1px solid #dee2e6; border-radius:8px; font-size:14px; outline:none; transition:border-color .2s; }
        .form-input:focus { border-color:var(--main-color); }
        textarea.form-input { resize:vertical; min-height:80px; }

        .upload-zone {
            border:2px dashed #dee2e6; border-radius:12px;
            padding:20px 12px; text-align:center; cursor:pointer;
            transition:border-color .2s, background .2s;
            position:relative; background:#fafafa;
            display:flex; flex-direction:column; align-items:center; justify-content:center;
            min-height:90px;
        }
        .upload-zone:hover, .upload-zone.dragover { border-color:var(--main-color); background:#f0f7ff; }
        .upload-zone input[type="file"] { position:absolute; inset:0; opacity:0; cursor:pointer; width:100%; height:100%; }
        .upload-zone .zone-icon { font-size:24px; margin-bottom:4px; pointer-events:none; }
        .upload-zone .zone-text { font-size:12px; color:#868e96; line-height:1.5; pointer-events:none; }
        .upload-zone .zone-text strong { color:var(--main-color); }
        .upload-preview { width:100%; height:100px; object-fit:cover; border-radius:10px; margin-top:8px; border:1px solid #dee2e6; display:none; }
        .upload-loading { display:none; font-size:12px; color:#868e96; margin-top:6px; text-align:center; }

        .tag-preview-wrap { margin-top:8px; display:flex; flex-wrap:wrap; gap:6px; min-height:24px; }
        .tag-chip { background:#e7f5ff; color:#1971c2; padding:4px 10px; border-radius:100px; font-size:12px; font-weight:600; }
        a { text-decoration:none; }
        .modal-body {
            max-height: 80vh;
            overflow-y: scroll;
        }
    </style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>
    <main class="content_area">
        <div class="d-flex justify-content-between align-items-center u-mb-32">
            <h2 class="t-fs-32 fw-900">🔧 장비 관리</h2>
            <button onclick="openAddModal()" class="u-bg-main u-txt-white u-px-24 u-py-12 rounded-8 fw-700 u-press u-btn">+ 새 장비 추가</button>
        </div>
        <section class="card_custom">
            <?php if (!empty($equipments)): ?>
            <div class="equipment-grid">
                <?php foreach ($equipments as $eq): ?>
                <div class="eq-card">
                    <?php if ($eq['image_outer']): ?>
                        <img class="thumb" src="<?= htmlspecialchars($eq['image_outer']) ?>" alt="<?= htmlspecialchars($eq['name']) ?>">
                    <?php else: ?>
                        <div class="thumb-placeholder">이미지 없음</div>
                    <?php endif; ?>
                    <div class="eq-body">
                        <?php if ($eq['category']): ?>
                            <span class="eq-category"><?= htmlspecialchars($eq['category']) ?></span>
                        <?php endif; ?>
                        <div class="eq-name"><?= htmlspecialchars($eq['name']) ?></div>
                        <div class="eq-desc"><?= htmlspecialchars($eq['description']) ?></div>
                        <?php if ($eq['tags']): ?>
                       <div class="eq-tags">
    <?php foreach (explode('#', $eq['tags']) as $tag):
        $tag = trim($tag);
        if (!$tag) continue;
    ?>
    <span class="eq-tag">#<?= htmlspecialchars($tag) ?></span>
    <?php endforeach; ?>
</div>
                        <?php endif; ?>
                        <div class="eq-actions">
                            <button type="button" onclick='openEditModal(<?= json_encode($eq, JSON_HEX_QUOT|JSON_HEX_TAG) ?>)' class="u-btn u-btn-main flex-grow-1 rounded-4 fw-700 u-py-8 u-press">수정</button>
                            <button type="button" onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='?delete_id=<?= $eq['id'] ?>'" class="u-btn u-btn-gray flex-grow-1 rounded-4 fw-700 u-py-8 u-press" style="color:#fa5252;">삭제</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center u-py-60 u-txt-muted">등록된 장비가 없습니다.</div>
            <?php endif; ?>
        </section>
    </main>
</div>

<!-- ============================================================ -->
<!-- 추가 모달 -->
<!-- ============================================================ -->
<div class="modal fade" id="addEquipmentModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header u-px-32 u-pt-32 border-0">
                <h5 class="modal-title t-fs-24 fw-800">🔧 새 장비 추가</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" id="addForm">
                <input type="hidden" name="action" value="add_equipment">
                <input type="hidden" name="image_outer" id="add_outer_val">
                <input type="hidden" name="image_inner" id="add_inner_val">
                <div class="modal-body u-px-32">
                    <div class="row g-3">
                        <div class="col-8">
                            <label class="form-label">장비명 <span style="color:#fa5252">*</span></label>
                            <input type="text" name="name" class="form-input" placeholder="장비 이름" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label">카테고리</label>
                            <input type="text" name="category" class="form-input" placeholder="예: CT, 레이저">
                        </div>
                        <div class="col-6">
                            <label class="form-label">외부 이미지</label>
                            <div class="upload-zone"
                                ondragover="event.preventDefault(); this.classList.add('dragover')"
                                ondragleave="this.classList.remove('dragover')"
                                ondrop="handleDrop(event,'add_outer_val','add_outer_preview','add_outer_loading')">
                                <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_outer_val','add_outer_preview','add_outer_loading')">
                                <div class="zone-icon">🖼️</div>
                                <div class="zone-text">클릭하거나 <strong>드래그</strong>해서 업로드<br><span style="font-size:11px">JPG · PNG · WEBP · GIF</span></div>
                            </div>
                            <div class="upload-loading" id="add_outer_loading">⏳ 업로드 중...</div>
                            <img id="add_outer_preview" class="upload-preview">
                        </div>
                        <div class="col-6">
                            <label class="form-label">내부 이미지</label>
                            <div class="upload-zone"
                                ondragover="event.preventDefault(); this.classList.add('dragover')"
                                ondragleave="this.classList.remove('dragover')"
                                ondrop="handleDrop(event,'add_inner_val','add_inner_preview','add_inner_loading')">
                                <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'add_inner_val','add_inner_preview','add_inner_loading')">
                                <div class="zone-icon">🏥</div>
                                <div class="zone-text">클릭하거나 <strong>드래그</strong>해서 업로드<br><span style="font-size:11px">JPG · PNG · WEBP · GIF</span></div>
                            </div>
                            <div class="upload-loading" id="add_inner_loading">⏳ 업로드 중...</div>
                            <img id="add_inner_preview" class="upload-preview">
                        </div>
                        <div class="col-8">
                            <label class="form-label">유튜브 링크</label>
                            <input type="text" name="youtube_url" class="form-input" placeholder="https://youtube.com/...">
                        </div>
                        <div class="col-4">
                            <label class="form-label">표시 순서</label>
                            <input type="number" name="display_order" class="form-input" value="0">
                        </div>
                        <div class="col-12">
                            <label class="form-label">설명</label>
                            <textarea name="description" class="form-input" placeholder="장비 설명을 입력하세요"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">해시태그</label>
                            <input type="text" name="tags" id="add_tags" class="form-input" placeholder="#임플란트 #CT #레이저 (띄어쓰기로 구분)">
                            <div class="tag-preview-wrap" id="add_tags_preview"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer u-px-32 u-pb-32 border-0 d-flex u-gap-12">
                    <button type="button" class="u-btn u-btn-gray flex-grow-1 u-py-12 rounded-8 fw-600" data-bs-dismiss="modal">취소</button>
                    <button type="submit" class="u-btn flex-grow-1 u-py-12 rounded-8 fw-700" style="background:var(--main-color);color:#fff;">추가하기</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ============================================================ -->
<!-- 수정 모달 -->
<!-- ============================================================ -->
<div class="modal fade" id="editEquipmentModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header u-px-32 u-pt-32 border-0">
                <h5 class="modal-title t-fs-24 fw-800">📝 장비 수정</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="post" id="editForm">
                <input type="hidden" name="action" value="update_equipment">
                <input type="hidden" name="id" id="edit_id">
                <input type="hidden" name="image_outer" id="edit_outer_val">
                <input type="hidden" name="image_inner" id="edit_inner_val">
                <div class="modal-body u-px-32">
                    <div class="row g-3">
                        <div class="col-8">
                            <label class="form-label">장비명 <span style="color:#fa5252">*</span></label>
                            <input type="text" name="name" id="edit_name" class="form-input" required>
                        </div>
                        <div class="col-4">
                            <label class="form-label">카테고리</label>
                            <input type="text" name="category" id="edit_category" class="form-input">
                        </div>
                        <div class="col-6">
                            <label class="form-label">외부 이미지</label>
                            <div class="upload-zone"
                                ondragover="event.preventDefault(); this.classList.add('dragover')"
                                ondragleave="this.classList.remove('dragover')"
                                ondrop="handleDrop(event,'edit_outer_val','edit_outer_preview','edit_outer_loading')">
                                <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_outer_val','edit_outer_preview','edit_outer_loading')">
                                <div class="zone-icon">🖼️</div>
                                <div class="zone-text">클릭하거나 <strong>드래그</strong>해서 교체</div>
                            </div>
                            <div class="upload-loading" id="edit_outer_loading">⏳ 업로드 중...</div>
                            <img id="edit_outer_preview" class="upload-preview">
                        </div>
                        <div class="col-6">
                            <label class="form-label">내부 이미지</label>
                            <div class="upload-zone"
                                ondragover="event.preventDefault(); this.classList.add('dragover')"
                                ondragleave="this.classList.remove('dragover')"
                                ondrop="handleDrop(event,'edit_inner_val','edit_inner_preview','edit_inner_loading')">
                                <input type="file" accept="image/*" onchange="uploadImage(this.files[0],'edit_inner_val','edit_inner_preview','edit_inner_loading')">
                                <div class="zone-icon">🏥</div>
                                <div class="zone-text">클릭하거나 <strong>드래그</strong>해서 교체</div>
                            </div>
                            <div class="upload-loading" id="edit_inner_loading">⏳ 업로드 중...</div>
                            <img id="edit_inner_preview" class="upload-preview">
                        </div>
                        <div class="col-8">
                            <label class="form-label">유튜브 링크</label>
                            <input type="text" name="youtube_url" id="edit_youtube_url" class="form-input">
                        </div>
                        <div class="col-4">
                            <label class="form-label">표시 순서</label>
                            <input type="number" name="display_order" id="edit_display_order" class="form-input">
                        </div>
                        <div class="col-12">
                            <label class="form-label">설명</label>
                            <textarea name="description" id="edit_description" class="form-input"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">해시태그</label>
                            <input type="text" name="tags" id="edit_tags" class="form-input" placeholder="#임플란트 #CT #레이저 (띄어쓰기로 구분)">
                            <div class="tag-preview-wrap" id="edit_tags_preview"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer u-px-32 u-pb-32 border-0 d-flex u-gap-12">
                    <button type="button" class="u-btn u-btn-gray flex-grow-1 u-py-12 rounded-8 fw-600" data-bs-dismiss="modal">취소</button>
                    <button type="submit" class="u-btn flex-grow-1 u-py-12 rounded-8 fw-700" style="background:var(--main-color);color:#fff;">수정완료</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ── 이미지 업로드 ──
function uploadImage(file, hiddenId, previewId, loadingId) {
    if (!file) return;
    const loading = document.getElementById(loadingId);
    const preview = document.getElementById(previewId);
    const hidden  = document.getElementById(hiddenId);

    loading.style.display = 'block';
    preview.style.display = 'none';

    const fd = new FormData();
    fd.append('eq_image', file);

    fetch('./device_manager.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            loading.style.display = 'none';
            if (data.success) {
                hidden.value = data.url;
                preview.src  = data.url;
                preview.style.display = 'block';
            } else {
                alert(data.message || '업로드 실패');
            }
        })
        .catch(() => { loading.style.display = 'none'; alert('업로드 중 오류 발생'); });
}

// ── 드랍 이벤트 ──
function handleDrop(event, hiddenId, previewId, loadingId) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    const file = event.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) {
        uploadImage(file, hiddenId, previewId, loadingId);
    } else {
        alert('이미지 파일만 업로드 가능합니다.');
    }
}

// ── 해시태그 미리보기 ──
function renderTags(inputId, previewId) {
    const input   = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    input.addEventListener('input', function () {
        const tags = this.value.split('#').map(t => t.trim()).filter(t => t);
        preview.innerHTML = tags.map(t => {
            return `<span class="tag-chip">#${t}</span>`;
        }).join('');
    });
}
renderTags('add_tags', 'add_tags_preview');
renderTags('edit_tags', 'edit_tags_preview');

// ── 추가 모달 ──
function openAddModal() {
    document.getElementById('addForm').reset();
    ['add_outer_val', 'add_inner_val'].forEach(id => document.getElementById(id).value = '');
    ['add_outer_preview', 'add_inner_preview'].forEach(id => {
        document.getElementById(id).src = '';
        document.getElementById(id).style.display = 'none';
    });
    ['add_outer_loading', 'add_inner_loading'].forEach(id => document.getElementById(id).style.display = 'none');
    document.getElementById('add_tags').value = '';
    document.getElementById('add_tags_preview').innerHTML = '';
new bootstrap.Modal(document.getElementById('addEquipmentModal'), { backdrop: 'static' }).show();
}

// ── 수정 모달 ──
function openEditModal(data) {
    document.getElementById('edit_id').value            = data.id;
    document.getElementById('edit_name').value          = data.name;
    document.getElementById('edit_category').value      = data.category;
    document.getElementById('edit_description').value   = data.description;
    document.getElementById('edit_youtube_url').value   = data.youtube_url;
    document.getElementById('edit_display_order').value = data.display_order;
    document.getElementById('edit_outer_val').value     = data.image_outer;
    document.getElementById('edit_inner_val').value     = data.image_inner;

    const setPreview = (id, url) => {
        const el = document.getElementById(id);
        if (url) { el.src = url; el.style.display = 'block'; }
        else     { el.src = ''; el.style.display = 'none'; }
    };
    setPreview('edit_outer_preview', data.image_outer);
    setPreview('edit_inner_preview', data.image_inner);
    ['edit_outer_loading', 'edit_inner_loading'].forEach(id => document.getElementById(id).style.display = 'none');

    // 태그
    document.getElementById('edit_tags').value = data.tags || '';
    document.getElementById('edit_tags').dispatchEvent(new Event('input'));

  new bootstrap.Modal(document.getElementById('editEquipmentModal'), { backdrop: 'static' }).show();
}
</script>
</body>
</html>