<?php
// 1. 공통 파일 로드
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');

// 2. DB 테이블 및 컬럼 강제 생성 (누락 방지)
sql_query(" CREATE TABLE IF NOT EXISTS `dm_popup` (
    `nw_id` int(11) NOT NULL AUTO_INCREMENT,
    `nw_subject` varchar(255) DEFAULT '',
    `nw_begin_time` datetime DEFAULT '0000-00-00 00:00:00',
    `nw_end_time` datetime DEFAULT '0000-00-00 00:00:00',
    `nw_width` int(11) DEFAULT '0',
    `nw_height` int(11) DEFAULT '0',
    `nw_left` int(11) DEFAULT '0',
    `nw_top` int(11) DEFAULT '0',
    `nw_img` varchar(255) DEFAULT '',
    `nw_status` tinyint(4) DEFAULT '1',
    `nw_type` varchar(20) DEFAULT 'general',
    PRIMARY KEY (`nw_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ");

// 설정 테이블에 컬럼이 없으면 추가
sql_query(" ALTER TABLE `dm_popup` ADD IF NOT EXISTS `cf_popup_type` VARCHAR(20) DEFAULT 'general' ");

// ✨ 3. 만료된 팝업 자동 비활성화 (페이지 로드 시 자동 실행)
$expired_result = sql_query("
    UPDATE dm_popup 
    SET nw_status = 0 
    WHERE nw_status = 1 
    AND nw_end_time < NOW()
    AND nw_end_time != '0000-00-00 00:00:00'
");

// ✨ 만료된 팝업 목록 가져오기 (Toast 알림용)
$expired_list = sql_query("
    SELECT nw_id, nw_subject, nw_end_time 
    FROM dm_popup 
    WHERE nw_status = 0 
    AND nw_end_time < NOW()
    AND nw_end_time != '0000-00-00 00:00:00'
    AND DATE(nw_end_time) >= DATE(NOW() - INTERVAL 7 DAY)
    ORDER BY nw_end_time DESC
");

$expired_popups = [];
while ($exp = sql_fetch_array($expired_list)) {
    $expired_popups[] = $exp;
}

// 4. 운영 모드 저장 로직
if (isset($_POST['update_pop_mode'])) {
    $new_mode = sql_real_escape_string($_POST['pop_mode']);
    
    // 테이블에 데이터가 하나라도 있는지 확인
    $check = sql_fetch(" SELECT count(*) as cnt FROM `dm_popup` ");
    
    if ($check['cnt'] == 0) {
        sql_query(" INSERT INTO `dm_popup` SET cf_id = 1, cf_popup_type = '$new_mode' ");
    } else {
        sql_query(" UPDATE `dm_popup` SET cf_popup_type = '$new_mode' LIMIT 1 ");
    }
    
    goto_url('./popup_manager.php'); 
}

// 5. 현재 설정값 로드
$conf = sql_fetch(" SELECT cf_popup_type FROM `dm_popup` LIMIT 1 ");
$current_mode = (isset($conf['cf_popup_type']) && $conf['cf_popup_type']) ? $conf['cf_popup_type'] : 'general';

$result = sql_query(" SELECT * FROM dm_popup ORDER BY nw_id DESC ");
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>팝업 관리 매니저</title>

    <style>
        #admin_wrapper { display: flex; min-height: 100vh; }
        .content_area { flex: 1; padding: 40px; background: #f8f9fa; }
        .popup-preview-img { width: 100px; height: 60px; object-fit: cover; border-radius: 4px; background: #f0f0f0; border: 1px solid #eee; }
        .status-badge { padding: 4px 12px; border-radius: 20px; font-weight: 800; font-size: 11px; }

        /* 라디오 버튼 커스텀 UI */
        .mode-radio-group { display: flex; gap: 10px; }
        .mode-radio-item { position: relative; }
        .mode-radio-item input[type="radio"] { position: absolute; opacity: 0; width: 0; height: 0; }
        .mode-label { 
            display: inline-block; padding: 12px 24px; cursor: pointer; border-radius: 8px;
            border: 2px solid #ddd; background: #fff; font-weight: 800; transition: all 0.2s;
        }
        .mode-radio-item input[type="radio"]:checked + .mode-label { 
            border-color: #2196f3; background: #e3f2fd; color: #2196f3; 
        }
        
        /* 슬라이드 모드 활성화 시 행 강조 */
        .active-row { background-color: #f0f7ff !important; border-left: 4px solid #2196f3; }
        
        /* ✨ 만료된 팝업 행 스타일 */
        .expired-row { 
            background-color: #ffebee !important; 
            border-left: 4px solid #f44336; 
            opacity: 0.7;
        }
        
        /* ✨ Toast 알림 스타일 */
        .toast-notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #fff;
            border-left: 4px solid #ff9800;
            padding: 16px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 9999;
            min-width: 300px;
            max-width: 400px;
            animation: slideIn 0.3s ease-out;
        }
        
        .toast-notification.error {
            border-left-color: #f44336;
        }
        
        .toast-notification.warning {
            border-left-color: #ff9800;
        }
        
        .toast-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }
        
        .toast-title {
            font-weight: 800;
            font-size: 14px;
            color: #333;
        }
        
        .toast-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #999;
            padding: 0;
            line-height: 1;
        }
        
        .toast-close:hover {
            color: #333;
        }
        
        .toast-body {
            font-size: 13px;
            color: #666;
            line-height: 1.5;
        }
        
        .toast-list {
            margin: 8px 0 0 0;
            padding-left: 20px;
        }
        
        .toast-list li {
            margin: 4px 0;
            font-size: 12px;
        }
        
        @keyframes slideIn {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOut {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(400px);
                opacity: 0;
            }
        }
        
        .toast-notification.hiding {
            animation: slideOut 0.3s ease-out forwards;
        }
    </style>
</head>
<body>

<div id="admin_wrapper">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <main class="content_area">
        <div class="g-cols-fit-12 w-100 justify-content-between align-center u-mb-32">
            <h2 class="t-fs-32 fw-900 w-nowrap">✨ 팝업 관리 매니저</h2>
            <a href="./popup_form.php" class="u-bg-main c-fs-16 u-btn u-txt-white u-px-24 u-py-8 rounded-8 fw-800 decoration-none g-self-start g-self-end-md">새 팝업 등록</a>
        </div>

        <section class="card_custom u-mb-32" style="background: #fff; border: 2px solid #2196f3;">
            <form method="post">
                <input type="hidden" name="update_pop_mode" value="1">
                <div class=" align-center justify-content-between g-cols-fit-10">
                    <div>
                        <h3 class="t-fs-20 fw-800 u-mb-8">사이트 전체 팝업 운영 모드</h3>
                        <p class="u-txt-muted c-fs-14">현재 적용 모드: <b style="color:red; text-transform:uppercase;"><?= $current_mode ?></b></p>
                    </div>
                    <div class=" align-center u-gap-12 g-cols-fit-12">
                        <div class="mode-radio-group w-100  g-self-end flex-column flex-lg-row" >
                            <div class="mode-radio-item w-100">
                                <input type="radio" name="pop_mode" id="opt_gen" value="general" <?= ($current_mode == 'general') ? 'checked' : '' ?>>
                                <label for="opt_gen" class="mode-label w-100 text-center">일반 개별형</label>
                            </div>
                            <div class="mode-radio-item w-100">
                                <input type="radio" name="pop_mode" id="opt_slide" value="slide" <?= ($current_mode == 'slide') ? 'checked' : '' ?>>
                                <label for="opt_slide" class="mode-label w-100 text-center">슬라이드 통합형</label>
                            </div>
                        </div>
                        <button type="submit" class="u-btn u-bg-main u-txt-white fw-800 u-px-24 u-py-8 rounded-8  g-self-end">설정 저장</button>
                    </div>
                </div>
            </form>
        </section>

        <section class="card_custom p-0 u-overflow-hidden table-responsive">
            <div class="u-p-20 border-bottom bg-light">
                <span class="fw-700 c-fs-16">
                    현재 사이트는 <b class="u-txt-main"><?= ($current_mode == 'slide' ? '슬라이드 통합형' : '일반 개별형') ?></b> 모드로 작동 중입니다.
                </span>
            </div>
            <table style="width:100%; border-collapse: collapse;" class="table-responsive">
                <thead>
                    <tr style="background: #fafafa; border-bottom: 1px solid #eee;">
                        <th class="u-px-20 u-py-12 text-left" width="120">미리보기</th>
                        <th class="u-px-20 u-py-12 text-left">팝업 제목 / 기간</th>
                        <th class="u-px-20 u-py-12 text-center" width="180">상태</th>
                        <th class="u-px-20 u-py-12 text-center" width="150">관리</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    for ($i = 0; $row = sql_fetch_array($result); $i++) {
                        $img_url = $row['nw_img'] ? G5_DATA_URL . '/popup/' . $row['nw_img'] : '';
                        $is_on = (bool)$row['nw_status'];
                        
                        // ✨ 만료 여부 체크
                        $is_expired = false;
                        if ($row['nw_end_time'] != '0000-00-00 00:00:00' && strtotime($row['nw_end_time']) < time()) {
                            $is_expired = true;
                        }
                        
                        $row_class = '';
                        if ($is_expired) {
                            $row_class = 'expired-row';
                        } elseif ($is_on && $current_mode == 'slide') {
                            $row_class = 'active-row';
                        }
                    ?>
                    <tr style="border-bottom: 1px solid #f5f5f5; opacity: <?= $is_on ? '1' : '0.4' ?>;" class="<?= $row_class ?>">
                        <td class="u-px-20 u-py-16">
                            <?php if ($img_url) { ?><img src="<?= $img_url ?>" class="popup-preview-img"><?php } ?>
                        </td>
                        <td class="u-px-20 u-py-16">
                            <div class="fw-800 t-fs-17">
                                <?= $row['nw_subject'] ?>
                                <?php if ($is_expired) { ?>
                                    <span style="color: #f44336; font-size: 12px; margin-left: 8px;">⏰ 만료됨</span>
                                <?php } ?>
                            </div>
                            <div class="u-txt-muted c-fs-12"><?= substr($row['nw_begin_time'], 2, 14) ?> ~ <?= substr($row['nw_end_time'], 2, 14) ?></div>
                        </td>
                        <td class="u-px-20 u-py-16 text-center">
                            <?php if ($is_expired) { ?>
                                <span class="status-badge mx-auto d-block w-fit" style="background:#f44336; color:#fff;">
                                    기간 만료
                                </span>
                            <?php } else { ?>
                                <span class="status-badge mx-auto d-block w-fit" style="background:<?= ($is_on ? ($current_mode == 'slide' ? '#2196f3' : '#4caf50') : '#eee') ?>; color:<?= ($is_on ? '#fff' : '#999') ?>;">
                                    <?= ($is_on ? ($current_mode == 'slide' ? '슬라이드 활성' : '개별 노출중') : '중지') ?>
                                </span>
                            <?php } ?>
                        </td>
                        <td class="u-px-20 u-py-16 text-center">
                            <div class="d-flex u-gap-8 justify-center">
                                <a href="./popup_form.php?nw_id=<?= $row['nw_id'] ?>" class="u-btn u-btn-main rounded-8 u--px-12 u-py-4 c-fs-13 fw-700 decoration-none">수정</a>
                                <a href="javascript:void(0);" onclick="if(confirm('정말 삭제하시겠습니까?')) location.href='popup_update.php?mode=d&nw_id=<?= $row['nw_id'] ?>';" class="u-btn u-btn-gray u-txt-red rounded-8 u-px-12 u-py-4 c-fs-13 fw-700 decoration-none">삭제</a>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>
</div>

<!-- ✨ Toast 알림 스크립트 -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // PHP에서 만료된 팝업 목록 받기
    const expiredPopups = <?= json_encode($expired_popups) ?>;
    
    if (expiredPopups.length > 0) {
        showExpiredPopupToast(expiredPopups);
    }
});

function showExpiredPopupToast(popups) {
    const toast = document.createElement('div');
    toast.className = 'toast-notification warning';
    
    let popupList = '';
    popups.forEach(popup => {
        const endDate = popup.nw_end_time.substring(0, 16).replace(' ', ' ');
        popupList += `<li><strong>${popup.nw_subject}</strong> (${endDate} 종료)</li>`;
    });
    
    toast.innerHTML = `
        <div class="toast-header">
            <span class="toast-title">⚠️ 만료된 팝업 알림 (${popups.length}개)</span>
            <button class="toast-close" onclick="closeToast(this)">×</button>
        </div>
        <div class="toast-body">
            다음 팝업의 노출 기한이 종료되어 자동으로 비활성화되었습니다:
            <ul class="toast-list">${popupList}</ul>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    // 10초 후 자동으로 닫기
    setTimeout(() => {
        closeToast(toast.querySelector('.toast-close'));
    }, 10000);
}

function closeToast(button) {
    const toast = button.closest('.toast-notification');
    toast.classList.add('hiding');
    setTimeout(() => {
        toast.remove();
    }, 300);
}
</script>

</body>
</html>