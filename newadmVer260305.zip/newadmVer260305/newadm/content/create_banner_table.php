<?php
/**
 * 배너 테이블 자동 생성 스크립트
 * 한 번만 실행하면 됩니다
 * * 실행 방법: 브라우저에서 /newadm/content/create_banner_table.php 접속
 */

// 그누보드 연결 - 현재 파일 위치가 /newadm/content/ 이므로 
// 상위의 상위(/www/common.php)를 찾거나 DOCUMENT_ROOT를 사용합니다.
include_once($_SERVER['DOCUMENT_ROOT'].'/common.php');

// 이미 테이블이 있는지 확인
$check_query = "SHOW TABLES LIKE 'mainbanner'";
$check_result = sql_query($check_query);
$table_exists = sql_num_rows($check_result) > 0;

if($table_exists) {
    die('
        <div style="padding:40px; text-align:center; font-family:sans-serif;">
            <h2 style="color:#ffc107;">⚠️ 이미 테이블이 존재합니다</h2>
            <p>mainbanner 테이블이 이미 생성되어 있습니다.</p>
            <a href="./banner_manager.php" style="display:inline-block; margin-top:20px; padding:10px 20px; background:#007bff; color:#fff; text-decoration:none; border-radius:6px;">배너 관리로 이동</a>
        </div>
    ');
}

// 테이블 생성 SQL
$create_table_sql = "
CREATE TABLE `mainbanner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT '배너 그룹 이름',
  `images` longtext DEFAULT NULL COMMENT '이미지 배열 (JSON)',
  `settings` text DEFAULT NULL COMMENT 'Swiper 설정 (JSON)',
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
";

// 테이블 생성 실행
$result = sql_query($create_table_sql, false);

if($result) {
    // 성공 페이지
    echo '
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>배너 테이블 생성 완료</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                margin: 0;
            }
            .success-box {
                background: #fff;
                border-radius: 20px;
                padding: 50px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                max-width: 600px;
                text-align: center;
            }
            .icon {
                font-size: 80px;
                margin-bottom: 20px;
            }
            h1 {
                color: #28a745;
                margin-bottom: 20px;
                font-size: 32px;
            }
            .info-box {
                background: #f8f9fa;
                padding: 25px;
                border-radius: 12px;
                margin: 25px 0;
                text-align: left;
            }
            .info-row {
                padding: 10px 0;
                border-bottom: 1px solid #e9ecef;
            }
            .info-row:last-child {
                border-bottom: none;
            }
            .label {
                font-weight: 600;
                color: #666;
                display: inline-block;
                width: 120px;
            }
            .value {
                color: #007bff;
                font-weight: 700;
            }
            .btn {
                display: inline-block;
                padding: 15px 40px;
                background: #007bff;
                color: #fff;
                text-decoration: none;
                border-radius: 10px;
                font-weight: 700;
                margin-top: 20px;
                transition: all 0.3s;
            }
            .btn:hover {
                background: #0056b3;
                transform: translateY(-2px);
                box-shadow: 0 10px 20px rgba(0,123,255,0.3);
            }
            .warning {
                background: #fff3cd;
                border: 2px solid #ffc107;
                border-radius: 10px;
                padding: 20px;
                margin: 25px 0;
                color: #856404;
            }
            .warning strong {
                display: block;
                margin-bottom: 10px;
                font-size: 18px;
            }
        </style>
    </head>
    <body>
        <div class="success-box">
            <div class="icon">✅</div>
            <h1>테이블 생성 완료!</h1>
            
            <div class="info-box">
                <div class="info-row">
                    <span class="label">테이블명:</span>
                    <span class="value">mainbanner</span>
                </div>
                <div class="info-row">
                    <span class="label">필드:</span>
                    <span class="value">id, name, images, settings, created_at</span>
                </div>
                <div class="info-row">
                    <span class="label">엔진:</span>
                    <span class="value">InnoDB</span>
                </div>
                <div class="info-row">
                    <span class="label">인코딩:</span>
                    <span class="value">utf8mb4</span>
                </div>
            </div>
            
            <div class="warning">
                <strong>⚠️ 주의사항</strong>
                <ul style="margin: 10px 0 0 20px; text-align: left; line-height: 1.8;">
                    <li>테이블이 정상적으로 생성되었습니다.</li>
                    <li>이제 배너 관리 페이지를 사용할 수 있습니다.</li>
                    <li>보안을 위해 이 파일을 서버에서 삭제하거나 이름을 변경하세요.</li>
                </ul>
            </div>
            
            <a href="./banner_manager.php" class="btn">배너 관리 페이지로 이동</a>
        </div>
    </body>
    </html>
    ';
} else {
    // 실패 페이지
    echo '
    <!DOCTYPE html>
    <html lang="ko">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>테이블 생성 실패</title>
        <style>
            body {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                margin: 0;
            }
            .error-box {
                background: #fff;
                border-radius: 20px;
                padding: 50px;
                box-shadow: 0 20px 60px rgba(0,0,0,0.3);
                max-width: 600px;
                text-align: center;
            }
            .icon {
                font-size: 80px;
                margin-bottom: 20px;
            }
            h1 {
                color: #dc3545;
                margin-bottom: 20px;
            }
            .error-msg {
                background: #f8d7da;
                border: 1px solid #f5c6cb;
                color: #721c24;
                padding: 20px;
                border-radius: 10px;
                margin: 20px 0;
                text-align: left;
                font-family: monospace;
                font-size: 14px;
                word-break: break-all;
            }
        </style>
    </head>
    <body>
        <div class="error-box">
            <div class="icon">❌</div>
            <h1>테이블 생성 실패</h1>
            <p>데이터베이스 오류가 발생했습니다.</p>
            <div class="error-msg">'.sql_error().'</div>
            <p style="margin-top: 20px; color: #666;">
                관리자에게 문의하거나 DB 권한을 확인해주세요.
            </p>
        </div>
    </body>
    </html>
    ';
}
?>