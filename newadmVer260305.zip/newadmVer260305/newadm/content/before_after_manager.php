<?php
// ✅ AJAX/POST 핸들러는 head_sub.php 포함 전에 처리
include_once('../_common.php');
include_once('../_auth_check.php');

$ba_table = 'dm_beforeafter';

// ============================================
// 테이블 자동 생성
// ============================================
$table_exists = sql_query("SHOW TABLES LIKE '{$ba_table}'");
if (sql_num_rows($table_exists) == 0) {
    sql_query("
    CREATE TABLE `{$ba_table}` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `title` varchar(255) NOT NULL,
      `image_before` varchar(255) DEFAULT NULL,
      `image_after` varchar(255) DEFAULT NULL,
      `treatment_category` varchar(100) DEFAULT NULL,
      `patient_age` varchar(50) DEFAULT NULL,
      `patient_gender` varchar(10) DEFAULT NULL,
      `treatment_period` varchar(100) DEFAULT NULL,
      `description` text,
      `is_visible` tinyint(1) DEFAULT 1,
      `display_order` int(11) DEFAULT 0,
      `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
    $table_created = true;
}

// ============================================
// 삭제
// ============================================
if (isset($_POST['action']) && $_POST['action'] === 'delete') {
    $id = (int)$_POST['id'];
    $ba = sql_fetch("SELECT image_before, image_after FROM {$ba_table} WHERE id = {$id}");
    foreach (['image_before', 'image_after'] as $f) {
        if (!empty($ba[$f]) && file_exists($_SERVER['DOCUMENT_ROOT'] . $ba[$f])) {
            @unlink($_SERVER['DOCUMENT_ROOT'] . $ba[$f]);
        }
    }
    sql_query("DELETE FROM {$ba_table} WHERE id = {$id}");
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 저장 / 수정
// ============================================
if (isset($_POST['action']) && in_array($_POST['action'], ['save', 'update'])) {
    $id                 = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $title              = sql_real_escape_string(trim($_POST['title'] ?? ''));
    $treatment_category = sql_real_escape_string(trim($_POST['treatment_category'] ?? ''));
    $patient_age        = sql_real_escape_string(trim($_POST['patient_age'] ?? ''));
    $patient_gender     = sql_real_escape_string(trim($_POST['patient_gender'] ?? ''));
    $treatment_period   = sql_real_escape_string(trim($_POST['treatment_period'] ?? ''));
    $description        = sql_real_escape_string(trim($_POST['description'] ?? ''));
    $is_visible         = isset($_POST['is_visible']) ? 1 : 0;

    $upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/data/beforeafter/';
    if (!is_dir($upload_dir)) @mkdir($upload_dir, 0755, true);

    $image_before_path = '';
    $image_after_path  = '';

    foreach (['image_before', 'image_after'] as $field) {
        if (!empty($_FILES[$field]) && $_FILES[$field]['error'] == 0) {
            $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
                $new_name  = $field . '_' . time() . '_' . uniqid() . '.' . $ext;
                $dest_path = $upload_dir . $new_name;
                if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest_path)) {
                    $new_path = '/data/beforeafter/' . $new_name;
                    if ($id > 0) {
                        $old = sql_fetch("SELECT {$field} FROM {$ba_table} WHERE id = {$id}");
                        if (!empty($old[$field]) && file_exists($_SERVER['DOCUMENT_ROOT'] . $old[$field])) {
                            @unlink($_SERVER['DOCUMENT_ROOT'] . $old[$field]);
                        }
                    }
                    if ($field === 'image_before') $image_before_path = $new_path;
                    else                           $image_after_path  = $new_path;
                }
            }
        }
    }

    if ($id > 0) {
        $sql  = "UPDATE {$ba_table} SET
                    title='{$title}', treatment_category='{$treatment_category}',
                    patient_age='{$patient_age}', patient_gender='{$patient_gender}',
                    treatment_period='{$treatment_period}', description='{$description}',
                    is_visible={$is_visible}";
        if ($image_before_path) $sql .= ", image_before='{$image_before_path}'";
        if ($image_after_path)  $sql .= ", image_after='{$image_after_path}'";
        $sql .= " WHERE id={$id}";
    } else {
        $sql = "INSERT INTO {$ba_table}
                (title, image_before, image_after, treatment_category, patient_age, patient_gender, treatment_period, description, is_visible)
                VALUES ('{$title}','{$image_before_path}','{$image_after_path}','{$treatment_category}','{$patient_age}','{$patient_gender}','{$treatment_period}','{$description}',{$is_visible})";
    }

    sql_query($sql);
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 노출 토글
// ============================================
if (isset($_POST['action']) && $_POST['action'] === 'toggle_visible') {
    $id         = (int)$_POST['id'];
    $is_visible = (int)$_POST['is_visible'];
    sql_query("UPDATE {$ba_table} SET is_visible = {$is_visible} WHERE id = {$id}");
    header('Content-Type: application/json');
    echo json_encode(['success' => true]);
    exit;
}

// ============================================
// 목록 조회
// ============================================
$result = sql_query("SELECT * FROM {$ba_table} ORDER BY display_order ASC, id DESC");
$cases  = [];
while ($row = sql_fetch_array($result)) $cases[] = $row;

// ✅ HTML 출력 전에만 head_sub.php 포함
include_once(G5_PATH . '/head_sub.php');
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>비포앤애프터 관리</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <style>
        /* 카드 그리드 */
        .ba-card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: var(--sp-20);
        }
        .ba-card-item {
            border: 1px solid var(--gray-200);
            border-radius: var(--sp-16);
            overflow: hidden;
            cursor: pointer;
            transition: box-shadow 0.2s, transform 0.2s;
            background: var(--white);
        }
        .ba-card-item:hover { box-shadow: 0 6px 24px rgba(0,0,0,0.10); transform: translateY(-2px); }

        /* 카드 상단: Before/After 이미지 반반 */
        .ba-card-images {
            display: flex;
            flex-direction: column;
            height: 200px;
        }
        .ba-card-img-row {
            flex: 1;
            position: relative;
            overflow: hidden;
        }
        .ba-card-img-row img {
            width: 100%; height: 100%;
            object-fit: cover; display: block;
        }
        .ba-card-img-row .ba-badge {
            position: absolute; top: 6px; left: 8px;
            font-size: 11px; font-weight: 700;
            padding: 2px 8px; border-radius: 100px;
            background: rgba(0,0,0,0.5); color: #fff;
        }
        .ba-card-img-row.after-row .ba-badge { background: var(--main-color); }
        .ba-card-divider { height: 1px; background: var(--gray-200); }

        /* 카드 하단: 정보 */
        .ba-card-info { padding: var(--sp-12) var(--sp-14); }
        .ba-card-title { font-size: 14px; font-weight: 600; color: var(--dark); margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .ba-card-meta  { font-size: 12px; color: var(--gray-500); }

        /* 카드 하단 액션 */
        .ba-card-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: var(--sp-10) var(--sp-14);
            border-top: 1px solid var(--gray-100);
        }
        .ba-no-img {
            width: 100%; height: 100%;
            background: var(--gray-100);
            display: flex; align-items: center; justify-content: center;
            font-size: 12px; color: var(--gray-500);
        }

        /* 스위치 */
        .switch { position: relative; display: inline-block; width: 44px; height: 22px; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; inset: 0; background: var(--gray-400); transition: .3s; border-radius: 22px; }
        .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background: var(--white); transition: .3s; border-radius: 50%; }
        input:checked + .slider { background: var(--main-color); }
        input:checked + .slider:before { transform: translateX(22px); }

        /* 모달 */
        .modal { display: none; position: fixed; z-index: var(--z-modal); inset: 0; background: rgba(0,0,0,0.5); overflow-y: auto; }
        .modal-content { background: var(--white); margin: 3% auto; padding: var(--sp-40); border-radius: var(--sp-20); width: 90%; max-width: 700px; max-height: 90vh; overflow-y: auto; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--sp-32); gap: var(--sp-16); }
        .modal-header-left { display: flex; align-items: center; gap: var(--sp-16); }
        .modal-visible-label { display: flex; align-items: center; gap: 6px; font-size: 13px; color: var(--gray-600); white-space: nowrap; }
        .close { color: var(--gray-500); font-size: 28px; font-weight: bold; cursor: pointer; line-height: 1; }
        .close:hover { color: var(--black); }

        /* 이미지 업로드 */
        .image-upload-wrapper { position: relative; width: 100%; height: 200px; border: 2px dashed var(--gray-300); border-radius: var(--sp-12); overflow: hidden; cursor: pointer; margin-bottom: var(--sp-8); }
        .image-upload-wrapper:hover { border-color: var(--main-color); }
        .image-preview { width: 100%; height: 100%; object-fit: cover; display: none; }
        .image-preview.active { display: block; }
        .image-upload-label { position: absolute; top: 50%; left: 50%; transform: translate(-50%,-50%); text-align: center; color: var(--gray-500); pointer-events: none; }
        .image-upload-label.hidden { display: none; }
        .upload-icon { font-size: 40px; margin-bottom: 8px; }
        input[type="file"] { display: none; }

        /* 성별 */
        .gender-radio { display: flex; gap: var(--sp-20); align-items: center; height: 50px; }
        .gender-radio label { cursor: pointer; }
        .gender-radio input { display: inline-block; width: auto; margin-right: 6px; }

        .modal-footer { display: flex; gap: var(--sp-10); margin-top: var(--sp-32); }
        .modal-footer .u-btn { flex: 1; }
        .btn-delete { background: none; color: var(--error-color, #dc3545); border: 1px solid var(--error-color, #dc3545); padding: 5px 12px; font-size: 12px; border-radius: var(--sp-4); cursor: pointer; }
        .align-center { display: flex; justify-content: space-between; align-items: center; }
        .alert-success { padding: var(--sp-16); background: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: var(--sp-8); margin-bottom: var(--sp-20); }
        .empty-state { text-align: center; padding: 60px 0; color: var(--gray-500); }
    </style>
</head>
<body>

<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area">

        <?php if (isset($table_created)): ?>
        <div class="alert-success">✔ <strong>비포앤애프터 테이블이 자동 생성되었습니다!</strong></div>
        <?php endif; ?>

        <div class="align-center u-mb-32">
            <h2 class="admin-card-title">📸 비포앤애프터 관리</h2>
            <button onclick="openModal()" class="u-btn u-btn-main rounded-8">+ 케이스 추가</button>
        </div>

        <section class="card_custom">
            <?php if (empty($cases)): ?>
                <div class="empty-state">
                    <p>등록된 비포앤애프터가 없습니다.</p>
                </div>
            <?php else: ?>
            <div class="ba-card-grid">
                <?php foreach ($cases as $ba): ?>
                <div class="ba-card-item" onclick="editCase(<?= $ba['id'] ?>)">

                    <!-- 이미지: 위 Before / 아래 After -->
                    <div class="ba-card-images">
                        <div class="ba-card-img-row">
                            <span class="ba-badge">Before</span>
                            <?php if ($ba['image_before']): ?>
                                <img src="<?= htmlspecialchars($ba['image_before']) ?>" alt="Before">
                            <?php else: ?>
                                <div class="ba-no-img">전 사진 없음</div>
                            <?php endif; ?>
                        </div>
                        <div class="ba-card-divider"></div>
                        <div class="ba-card-img-row after-row">
                            <span class="ba-badge">After</span>
                            <?php if ($ba['image_after']): ?>
                                <img src="<?= htmlspecialchars($ba['image_after']) ?>" alt="After">
                            <?php else: ?>
                                <div class="ba-no-img">후 사진 없음</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- 정보 -->
                    <div class="ba-card-info">
                        <?php if ($ba['treatment_category']): ?>
                            <span class="badge badge-blue" style="font-size:11px;"><?= htmlspecialchars($ba['treatment_category']) ?></span>
                        <?php endif; ?>
                        <p class="ba-card-title u-mt-4"><?= htmlspecialchars($ba['title']) ?></p>
                        <p class="ba-card-meta">
                            <?= htmlspecialchars($ba['patient_age']) ?> <?= htmlspecialchars($ba['patient_gender']) ?>
                            <?php if ($ba['treatment_period']): ?> · <?= htmlspecialchars($ba['treatment_period']) ?><?php endif; ?>
                        </p>
                    </div>

                    <!-- 액션 -->
                    <div class="ba-card-actions" onclick="event.stopPropagation()">
                        <label class="switch" title="노출 여부">
                            <input type="checkbox" <?= $ba['is_visible'] ? 'checked' : '' ?>
                                   onchange="toggleVisible(<?= $ba['id'] ?>, this.checked)">
                            <span class="slider"></span>
                        </label>
                        <button class="btn-delete" onclick="deleteCase(<?= $ba['id'] ?>)">삭제</button>
                    </div>

                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </section>
    </main>
</div>

<!-- 모달 -->
<div id="baModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <div class="modal-header-left">
                <h2 id="modalTitle" class="t-fs-24 fw-700">케이스 추가</h2>
                <!-- 노출 스위치: 타이틀 옆 -->
                <label class="modal-visible-label">
                    <label class="switch">
                        <input type="checkbox" id="isVisible" name="is_visible" checked>
                        <span class="slider"></span>
                    </label>
                    노출
                </label>
            </div>
            <span class="close" onclick="closeModal()">&times;</span>
        </div>

        <form id="baForm" enctype="multipart/form-data">
            <input type="hidden" id="baId" name="id">

            <!-- 이미지 업로드 -->
            <div class="g-cols-fit-12 u-gap-16">
                <div class="u-input-group">
                    <label class="u-label">전 사진 (Before)</label>
                    <div class="image-upload-wrapper" onclick="document.getElementById('imageBeforeInput').click()">
                        <img id="imageBeforePreview" class="image-preview" src="" alt="미리보기">
                        <div id="imageBeforeLabel" class="image-upload-label">
                            <div class="upload-icon">📷</div>
                            <div>시술 전 사진 업로드</div>
                        </div>
                    </div>
                    <input type="file" id="imageBeforeInput" name="image_before" accept="image/*" onchange="previewImage(this,'Before')">
                </div>
                <div class="u-input-group">
                    <label class="u-label">후 사진 (After)</label>
                    <div class="image-upload-wrapper" onclick="document.getElementById('imageAfterInput').click()">
                        <img id="imageAfterPreview" class="image-preview" src="" alt="미리보기">
                        <div id="imageAfterLabel" class="image-upload-label">
                            <div class="upload-icon">📷</div>
                            <div>시술 후 사진 업로드</div>
                        </div>
                    </div>
                    <input type="file" id="imageAfterInput" name="image_after" accept="image/*" onchange="previewImage(this,'After')">
                </div>
            </div>

            <!-- 제목 -->
            <div class="u-input-group">
                <label class="u-label" for="title">제목 *</label>
                <input type="text" id="title" name="title" class="u-input" placeholder="예: 30대 남성 임플란트 케이스" required>
            </div>

            <!-- 카테고리 -->
            <div class="u-input-group">
                <label class="u-label" for="category">시술 카테고리</label>
                <select id="category" name="treatment_category" class="u-input u-select">
                    <option value="">선택</option>
                    <option value="임플란트">임플란트</option>
                    <option value="교정">교정</option>
                    <option value="심미치료">심미치료</option>
                    <option value="보철">보철</option>
                    <option value="기타">기타</option>
                </select>
            </div>

            <div class="g-cols-fit-12 u-gap-16">
                <div class="u-input-group">
                    <label class="u-label" for="age">환자 나이</label>
                    <input type="text" id="age" name="patient_age" class="u-input" placeholder="예: 30대">
                </div>
                <div class="u-input-group">
                    <label class="u-label">환자 성별</label>
                    <div class="gender-radio">
                        <label><input type="radio" name="patient_gender" value="남"> 남성</label>
                        <label><input type="radio" name="patient_gender" value="여"> 여성</label>
                    </div>
                </div>
            </div>

            <!-- 시술 기간 -->
            <div class="u-input-group">
                <label class="u-label" for="period">시술 기간</label>
                <input type="text" id="period" name="treatment_period" class="u-input" placeholder="예: 3개월">
            </div>

            <!-- 상세 설명 -->
            <div class="u-input-group">
                <label class="u-label">상세 설명</label>
                <div id="description"></div>
            </div>

            <div class="modal-footer">
                <button type="button" class="u-btn u-btn-gray" onclick="closeModal()">취소</button>
                <button type="submit" class="u-btn u-btn-main">저장</button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
<script>
// ── Toast (alert_toast 미정의 시 자체 구현) ──
if (typeof alert_toast === 'undefined') {
    // 토스트 컨테이너 생성
    const _tc = document.createElement('div');
    _tc.id = '_toast_container';
    _tc.style.cssText = 'position:fixed;top:24px;right:24px;z-index:99999;display:flex;flex-direction:column;gap:10px;';
    document.body.appendChild(_tc);

    window.alert_toast = function(msg, type = 'success') {
        const colors = { success: '#28a745', error: '#dc3545', info: '#17a2b8' };
        const t = document.createElement('div');
        t.style.cssText = `background:${colors[type]||colors.success};color:#fff;padding:14px 22px;border-radius:10px;font-size:14px;font-weight:600;box-shadow:0 4px 16px rgba(0,0,0,.18);min-width:200px;opacity:0;transition:opacity .3s;`;
        t.textContent = msg;
        _tc.appendChild(t);
        requestAnimationFrame(() => t.style.opacity = '1');
        setTimeout(() => {
            t.style.opacity = '0';
            setTimeout(() => t.remove(), 300);
        }, 2500);
    };
}

// ── 케이스 데이터 (PHP → JS) ──
const CASES = <?= json_encode(array_column($cases, null, 'id')) ?>;

// ── CKEditor ──
let descriptionEditor = null;
ClassicEditor.create(document.querySelector('#description'), {
    language: 'ko',
    toolbar: ['heading','|','bold','italic','underline','|','bulletedList','numberedList','|','link','|','undo','redo'],
}).then(editor => {
    descriptionEditor = editor;
    editor.editing.view.change(w => w.setStyle('min-height','200px', editor.editing.view.document.getRoot()));
}).catch(console.error);

// ── 모달 열기/닫기 (외부 클릭 비활성화) ──
function openModal(id = null) {
    const modal = document.getElementById('baModal');
    document.getElementById('baForm').reset();
    document.getElementById('baId').value = '';
    resetImagePreview('Before');
    resetImagePreview('After');
    if (descriptionEditor) descriptionEditor.setData('');

    document.getElementById('modalTitle').textContent = id ? '케이스 수정' : '케이스 추가';
    document.getElementById('isVisible').checked = true;

    if (id && CASES[id]) {
        const ba = CASES[id];
        document.getElementById('baId').value           = ba.id;
        document.getElementById('title').value          = ba.title || '';
        document.getElementById('category').value       = ba.treatment_category || '';
        document.getElementById('age').value            = ba.patient_age || '';
        document.getElementById('period').value         = ba.treatment_period || '';
        document.getElementById('isVisible').checked   = ba.is_visible == 1;
        if (descriptionEditor) descriptionEditor.setData(ba.description || '');
        document.querySelectorAll('[name="patient_gender"]').forEach(r => { r.checked = r.value === ba.patient_gender; });
        if (ba.image_before) {
            document.getElementById('imageBeforePreview').src = ba.image_before;
            document.getElementById('imageBeforePreview').classList.add('active');
            document.getElementById('imageBeforeLabel').classList.add('hidden');
        }
        if (ba.image_after) {
            document.getElementById('imageAfterPreview').src = ba.image_after;
            document.getElementById('imageAfterPreview').classList.add('active');
            document.getElementById('imageAfterLabel').classList.add('hidden');
        }
    }
    modal.style.display = 'block';
}

function closeModal() {
    document.getElementById('baModal').style.display = 'none';
}

// ✅ 모달 외부 클릭 시 닫히지 않음 — window.onclick 없음

// ── 이미지 미리보기 ──
function previewImage(input, type) {
    if (!input.files?.[0]) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('image'+type+'Preview').src = e.target.result;
        document.getElementById('image'+type+'Preview').classList.add('active');
        document.getElementById('image'+type+'Label').classList.add('hidden');
    };
    reader.readAsDataURL(input.files[0]);
}
function resetImagePreview(type) {
    document.getElementById('image'+type+'Preview').classList.remove('active');
    document.getElementById('image'+type+'Label').classList.remove('hidden');
}

function editCase(id) { openModal(id); }

// ── 폼 제출 ──
document.getElementById('baForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    const id = document.getElementById('baId').value;
    formData.set('action', id ? 'update' : 'save');
    // isVisible 체크박스 — 언체크 시 FormData에 포함 안 되므로 명시 처리
    if (!document.getElementById('isVisible').checked) {
        formData.delete('is_visible');
    }
    if (descriptionEditor) formData.set('description', descriptionEditor.getData());

    $.ajax({
        url: '',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function(res) {
            let data = typeof res === 'string' ? JSON.parse(res) : res;
            if (data.success) {
                closeModal();
                alert_toast('저장되었습니다.', 'success');
                setTimeout(() => location.reload(), 1000);
            } else {
                alert_toast(data.msg || '저장 실패', 'error');
            }
        },
        error: function(xhr) {
            console.error('저장 오류:', xhr.responseText);
            alert_toast('저장 중 오류가 발생했습니다.', 'error');
        }
    });
});

// ── 노출 토글 ──
function toggleVisible(id, isVisible) {
    $.post('', { action: 'toggle_visible', id: id, is_visible: isVisible ? 1 : 0 }, function(res) {
        let data = typeof res === 'string' ? JSON.parse(res) : res;
        if (!data.success) { alert_toast('오류', 'error'); location.reload(); }
    });
}

// ── 삭제 ──
function deleteCase(id) {
    if (!confirm('정말 삭제하시겠습니까?')) return;
    $.post('', { action: 'delete', id: id }, function(res) {
        let data = typeof res === 'string' ? JSON.parse(res) : res;
        if (data.success) { alert_toast('삭제되었습니다.', 'success'); setTimeout(() => location.reload(), 800); }
        else { alert_toast('삭제 실패', 'error'); }
    }).fail(function() { alert_toast('오류가 발생했습니다.', 'error'); });
}
</script>

</body>
</html>