<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/head_sub.php');

// ============================================================
// 헬퍼 함수 (반드시 상단에 정의)
// ============================================================
function build_ts() {
    // HTML 태그 허용 (XSS 방지를 위해 허용 태그만 필터링)
    $allowed = '<p><br><span><strong><em><b><i><u><small><h1><h2><h3><h4><h5><h6><a>';
    $g  = function($k) { return isset($_POST[$k]) ? trim($_POST[$k]) : ''; };
    $gh = function($k) use ($allowed) { return isset($_POST[$k]) ? strip_tags(trim($_POST[$k]), $allowed) : ''; };
    return array(
        'web' => array(
            'subtitle'      => $gh('web_subtitle'),
            'title'         => $gh('web_title'),
            'description'   => $gh('web_description'),
            'button_text'   => $g('web_button_text'),
            'button_link'   => $g('web_button_link'),
            'text_color'    => $g('web_text_color')    ?: '#ffffff',
            'text_position' => $g('web_text_position') ?: 'left',
        ),
        'mobile' => array(
            'subtitle'      => $gh('mob_subtitle'),
            'title'         => $gh('mob_title'),
            'description'   => $gh('mob_description'),
            'button_text'   => $g('mob_button_text'),
            'button_link'   => $g('mob_button_link'),
            'text_color'    => $g('mob_text_color')    ?: '#ffffff',
            'text_position' => $g('mob_text_position') ?: 'left',
        ),
    );
}

function txFields($type, $scope = 'add') {
    $pfx      = ($scope === 'add') ? ($type . '_') : ('edit_' . $type . '_');
    $name_pfx = $type . '_';
    $html_note = '<small style="font-weight:400;color:#9b59b6">HTML 허용: &lt;br&gt; &lt;p&gt; &lt;span style=""&gt; &lt;strong&gt; 등 인라인스타일 가능</small>';
    ob_start();
?>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:4px">
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">소제목 <?php echo $html_note; ?></label>
    <textarea name="<?php echo $name_pfx; ?>subtitle" id="<?php echo $pfx; ?>subtitle" class="u-input" rows="2" placeholder="예: 대한민국 100대 명의&#10;<br> 줄바꿈, <span style=&quot;color:#ffd700&quot;>강조색</span> 가능"></textarea>
  </div>
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">제목 <?php echo $html_note; ?></label>
    <textarea name="<?php echo $name_pfx; ?>title" id="<?php echo $pfx; ?>title" class="u-input" rows="3" placeholder="메인 제목&#10;<strong>굵게</strong>, <br> 줄바꿈, <span style=&quot;font-size:1.2em&quot;>크게</span> 등 가능"></textarea>
  </div>
  <div class="form-group" style="grid-column:1/-1">
    <label class="form-label">설명 문구 <?php echo $html_note; ?></label>
    <textarea name="<?php echo $name_pfx; ?>description" id="<?php echo $pfx; ?>description" class="u-input" rows="3" placeholder="설명 문구&#10;<p>단락</p>, <br> 줄바꿈, <em>기울임</em> 등 가능"></textarea>
  </div>
  <div class="form-group">
    <label class="form-label">버튼 텍스트</label>
    <input type="text" name="<?php echo $name_pfx; ?>button_text" id="<?php echo $pfx; ?>button_text" class="u-input" placeholder="예: 자세히 보기">
  </div>
  <div class="form-group">
    <label class="form-label">버튼 링크</label>
    <input type="url" name="<?php echo $name_pfx; ?>button_link" id="<?php echo $pfx; ?>button_link" class="u-input" placeholder="https://...">
  </div>
  <div class="form-group">
    <label class="form-label">텍스트 색상</label>
    <div class="color-row">
      <input type="color" name="<?php echo $name_pfx; ?>text_color" id="<?php echo $pfx; ?>text_color" value="#ffffff" class="color-swatch"
             oninput="document.getElementById('<?php echo $pfx; ?>text_color_hex').value=this.value">
      <input type="text" id="<?php echo $pfx; ?>text_color_hex" value="#ffffff" class="u-input" readonly style="flex:1">
    </div>
  </div>
  <div class="form-group">
    <label class="form-label">텍스트 정렬</label>
    <select name="<?php echo $name_pfx; ?>text_position" id="<?php echo $pfx; ?>text_position" class="u-input">
      <option value="left">왼쪽</option>
      <option value="center">중앙</option>
      <option value="right">오른쪽</option>
    </select>
  </div>
</div>
<?php
    return ob_get_clean();
}

// ============================================================
// 테이블 자동 생성
// ============================================================
sql_query("CREATE TABLE IF NOT EXISTS `mainbanner` (
    `id`            INT(11) NOT NULL AUTO_INCREMENT,
    `name`          VARCHAR(255) DEFAULT NULL,
    `images`        LONGTEXT DEFAULT NULL,
    `settings`      LONGTEXT DEFAULT NULL,
    `text_settings` LONGTEXT DEFAULT NULL,
    `is_main`       TINYINT(1) DEFAULT 0,
    `created_at`    DATETIME DEFAULT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ============================================================
// AJAX 처리
// ============================================================
if (isset($_POST['set_main_banner'])) {
    sql_query("UPDATE mainbanner SET is_main = 0");
    sql_query("UPDATE mainbanner SET is_main = 1 WHERE id = " . (int)$_POST['banner_id']);
    echo json_encode(array('success' => true, 'message' => '메인 배너로 설정되었습니다.'));
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'reorder_images') {
    $bid  = (int)$_POST['banner_id'];
    $ord  = json_decode($_POST['order'], true);
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();
    $re = array();
    foreach ($ord as $idx) {
        if (isset($imgs[$idx])) $re[] = $imgs[$idx];
    }
    foreach ($re as $i => &$img) $img['order'] = $i + 1;
    unset($img);
    $json = addslashes(json_encode($re, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    ob_clean();
    echo json_encode(array('success' => true));
    exit;
}

// ============================================================
// POST 처리
// ============================================================
if (isset($_POST['action']) && $_POST['action'] === 'create_group') {
    $name = sql_real_escape_string(trim($_POST['banner_name']));
    $now  = date('Y-m-d H:i:s');
    sql_query("INSERT INTO mainbanner (name, created_at) VALUES ('$name', '$now')");
    alert_toast('배너 그룹이 생성되었습니다.', './banner_manager.php');
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'update_settings') {
    $bid = (int)$_POST['banner_id'];
    $s   = addslashes(json_encode(array(
        'autoplay_delay' => (int)$_POST['autoplay_delay'],
        'effect'         => sql_real_escape_string($_POST['effect']),
        'loop'           => isset($_POST['loop']) ? 1 : 0,
        'speed'          => (int)$_POST['speed'],
    )));
    sql_query("UPDATE mainbanner SET settings = '$s' WHERE id = $bid");
    alert_toast('설정이 저장되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'add_image' && isset($_FILES['banner_image'])) {
    $bid = (int)$_POST['banner_id'];
    $dir = $_SERVER['DOCUMENT_ROOT'] . '/data/banner/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $file    = $_FILES['banner_image'];
    $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed = array('jpg', 'jpeg', 'png', 'gif', 'webp');

    if (!in_array($ext, $allowed)) {
        alert_toast('허용되지 않는 파일입니다.', "./banner_manager.php?edit=$bid");
        exit;
    }
    $fn = 'banner_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
    if (!move_uploaded_file($file['tmp_name'], $dir . $fn)) {
        alert_toast('업로드 실패.', "./banner_manager.php?edit=$bid");
        exit;
    }
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();
    // 모바일 이미지 업로드 처리
    $fn_mob = '';
    if (isset($_FILES['banner_image_mobile']) && $_FILES['banner_image_mobile']['error'] === UPLOAD_ERR_OK) {
        $file_mob = $_FILES['banner_image_mobile'];
        $ext_mob  = strtolower(pathinfo($file_mob['name'], PATHINFO_EXTENSION));
        if (in_array($ext_mob, $allowed)) {
            $fn_mob = 'banner_mob_' . time() . '_' . rand(1000, 9999) . '.' . $ext_mob;
            if (!move_uploaded_file($file_mob['tmp_name'], $dir . $fn_mob)) $fn_mob = '';
        }
    }

    $imgs[] = array(
        'src'           => '/data/banner/' . $fn,
        'src_mobile'    => $fn_mob ? '/data/banner/' . $fn_mob : '',
        'order'         => count($imgs) + 1,
        'visible'       => isset($_POST['visible']) ? 1 : 0,
        'link'          => isset($_POST['link']) ? trim($_POST['link']) : '',
        'link_target'   => isset($_POST['link_target']) ? '_blank' : '_self',
        'start_date'    => (isset($_POST['start_date']) && trim($_POST['start_date'])) ? trim($_POST['start_date']) : null,
        'end_date'      => (isset($_POST['end_date'])   && trim($_POST['end_date']))   ? trim($_POST['end_date'])   : null,
        'text_settings' => build_ts(),
    );
    $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    alert_toast('이미지가 추가되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

if (isset($_POST['action']) && $_POST['action'] === 'update_image') {
    $bid = (int)$_POST['banner_id'];
    $idx = (int)$_POST['image_index'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (!is_array($imgs)) $imgs = array();
    if (!isset($imgs[$idx])) {
        alert_toast('이미지를 찾을 수 없습니다.', "./banner_manager.php?edit=$bid");
        exit;
    }
    $imgs[$idx]['visible']       = isset($_POST['visible']) ? 1 : 0;
    $imgs[$idx]['link']          = isset($_POST['link']) ? trim($_POST['link']) : '';
    $imgs[$idx]['link_target']   = isset($_POST['link_target']) ? '_blank' : '_self';
    $imgs[$idx]['start_date']    = (isset($_POST['start_date']) && trim($_POST['start_date'])) ? trim($_POST['start_date']) : null;
    $imgs[$idx]['end_date']      = (isset($_POST['end_date'])   && trim($_POST['end_date']))   ? trim($_POST['end_date'])   : null;
    $imgs[$idx]['text_settings'] = build_ts();

    // 모바일 이미지 교체 (새 파일 선택 시에만)
    if (isset($_FILES['banner_image_mobile']) && $_FILES['banner_image_mobile']['error'] === UPLOAD_ERR_OK) {
        $dir2     = $_SERVER['DOCUMENT_ROOT'] . '/data/banner/';
        $file_mob = $_FILES['banner_image_mobile'];
        $ext_mob  = strtolower(pathinfo($file_mob['name'], PATHINFO_EXTENSION));
        $allowed2 = array('jpg','jpeg','png','gif','webp');
        if (in_array($ext_mob, $allowed2)) {
            // 기존 모바일 이미지 삭제
            if (!empty($imgs[$idx]['src_mobile'])) {
                $old_mob = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
                if (file_exists($old_mob)) @unlink($old_mob);
            }
            $fn_mob = 'banner_mob_' . time() . '_' . rand(1000,9999) . '.' . $ext_mob;
            if (move_uploaded_file($file_mob['tmp_name'], $dir2 . $fn_mob)) {
                $imgs[$idx]['src_mobile'] = '/data/banner/' . $fn_mob;
            }
        }
    }
    // 모바일 이미지 삭제 요청
    if (isset($_POST['delete_mobile_img']) && $_POST['delete_mobile_img'] == '1') {
        if (!empty($imgs[$idx]['src_mobile'])) {
            $old_mob = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
            if (file_exists($old_mob)) @unlink($old_mob);
        }
        $imgs[$idx]['src_mobile'] = '';
    }
    $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
    sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    alert_toast('수정되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

// ============================================================
// GET 처리
// ============================================================
if (isset($_GET['delete_group'])) {
    $bid  = (int)$_GET['delete_group'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (is_array($imgs)) {
        foreach ($imgs as $img) {
            $f = $_SERVER['DOCUMENT_ROOT'] . $img['src'];
            if (file_exists($f)) @unlink($f);
            if (!empty($img['src_mobile'])) {
                $fm = $_SERVER['DOCUMENT_ROOT'] . $img['src_mobile'];
                if (file_exists($fm)) @unlink($fm);
            }
        }
    }
    sql_query("DELETE FROM mainbanner WHERE id = $bid");
    alert_toast('삭제되었습니다.', './banner_manager.php');
    exit;
}

if (isset($_GET['delete_image'])) {
    $bid  = (int)$_GET['banner_id'];
    $idx  = (int)$_GET['delete_image'];
    $row  = sql_fetch("SELECT images FROM mainbanner WHERE id = $bid");
    $imgs = json_decode($row['images'], true);
    if (is_array($imgs) && isset($imgs[$idx])) {
        $f = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src'];
        if (file_exists($f)) @unlink($f);
        // 모바일 이미지도 삭제
        if (!empty($imgs[$idx]['src_mobile'])) {
            $fm = $_SERVER['DOCUMENT_ROOT'] . $imgs[$idx]['src_mobile'];
            if (file_exists($fm)) @unlink($fm);
        }
        array_splice($imgs, $idx, 1);
        foreach ($imgs as $i => &$img) $img['order'] = $i + 1;
        unset($img);
        $json = addslashes(json_encode($imgs, JSON_UNESCAPED_UNICODE));
        sql_query("UPDATE mainbanner SET images = '$json' WHERE id = $bid");
    }
    alert_toast('삭제되었습니다.', "./banner_manager.php?edit=$bid");
    exit;
}

// ============================================================
// 화면 데이터
// ============================================================
$banners_result = sql_query("SELECT * FROM mainbanner ORDER BY is_main DESC, created_at DESC");
$edit_mode      = isset($_GET['edit']);
$edit_id        = $edit_mode ? (int)$_GET['edit'] : 0;
$edit_banner    = null;
$edit_images    = array();
$edit_settings  = array('autoplay_delay' => 3000, 'effect' => 'slide', 'loop' => 1, 'speed' => 600);

if ($edit_mode) {
    $edit_banner = sql_fetch("SELECT * FROM mainbanner WHERE id = $edit_id");
    if (!$edit_banner) {
        alert_toast('배너를 찾을 수 없습니다.', './banner_manager.php');
        exit;
    }
    $edit_images = json_decode($edit_banner['images'], true);
    if (!is_array($edit_images)) $edit_images = array();
    $saved = json_decode($edit_banner['settings'], true);
    if (is_array($saved)) $edit_settings = $saved;
}

$no_img = "https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg";
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>배너 관리</title>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
<style>
#admin_wrapper { display:grid; grid-template-columns:280px 1fr; min-height:100vh; }
.content_area  { background:var(--bg-soft); }
.card_custom   { background:#fff; border-radius:20px; box-shadow:0 4px 20px rgba(0,0,0,.04); padding:32px; margin-bottom:24px; }

/* 배너 목록 카드 */
.banner-card { border:2px solid var(--gray-200); border-radius:16px; padding:20px; position:relative; transition:.3s; max-width: 450px; }
.banner-card:hover { border-color:var(--main-color); box-shadow:0 8px 24px rgba(0,123,255,.1); }
.banner-card.main-banner { border-color:#4caf50; background:linear-gradient(135deg,#f0fff4,#e8f5e9); }
.main-badge { position:absolute; top:-10px; right:-10px; background:linear-gradient(135deg,#4caf50,#2e7d32); color:#fff; padding:5px 12px; border-radius:20px; font-size:12px; font-weight:800; box-shadow:0 4px 12px rgba(76,175,80,.4); animation:pulse 2s infinite; z-index:10; }
@keyframes pulse { 0%,100%{box-shadow:0 0 0 0 rgba(76,175,80,.7)} 50%{box-shadow:0 0 0 8px rgba(76,175,80,0)} }
.id-badge { display:inline-flex; align-items:center; gap:6px; background:#e3f2fd; color:#1976d2; padding:4px 10px; border-radius:8px; font-size:12px; font-weight:700; cursor:pointer; transition:.2s; }
.id-badge:hover { background:#1976d2; color:#fff; }

/* 이미지 카드 그리드 */
#imageList { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:16px; }
.img-card { background:#fff; border:2px solid var(--gray-200); border-radius:14px; overflow:hidden; cursor:grab; transition:.2s; position:relative; }
.img-card:hover { border-color:var(--main-color); box-shadow:0 6px 20px rgba(0,123,255,.1); }
.img-card-thumb { width:100%; height:160px; object-fit:cover; display:block; }
.img-card-body  { padding:12px; }
.img-badge      { position:absolute; top:8px; right:8px; background:var(--main-color); color:#fff; border-radius:20px; padding:3px 10px; font-size:11px; font-weight:800; z-index:5; }
.img-badge.off  { background:var(--gray-500); }
.sortable-ghost { opacity:.4; border:2px dashed var(--main-color) !important; }

/* 추가 폼 2컬럼 */
.add-grid { display:grid; grid-template-columns:1fr 1fr; gap:24px; }
@media(max-width:860px){ .add-grid { grid-template-columns:1fr; } }

/* 미리보기 */
.preview-wrap { position:sticky; top:20px; background:#000; border-radius:14px; overflow:hidden; aspect-ratio:16/9; display:flex; align-items:center; justify-content:center; min-height:200px; transition:.4s; }
.preview-wrap.mob { aspect-ratio:9/19; max-width:260px; margin:0 auto; }
.preview-bg { position:absolute; inset:0; background-size:cover; background-position:center; transition:.4s; }
.preview-overlay { position:absolute; inset:0; display:flex; flex-direction:column; justify-content:flex-end; padding:24px; pointer-events:none; }
.preview-overlay.pos-center { justify-content:center; align-items:center; text-align:center; }
.preview-overlay.pos-right  { align-items:flex-end; text-align:right; }
.prev-subtitle { font-size:12px; font-weight:600; margin-bottom:5px; opacity:.9; }
.prev-title    { font-size:20px; font-weight:800; line-height:1.3; margin-bottom:8px; }
.prev-desc     { font-size:11px; line-height:1.6; opacity:.85; margin-bottom:12px; }
.prev-btn      { display:inline-block; background:var(--main-color); color:#fff; padding:6px 16px; border-radius:8px; font-size:12px; font-weight:700; }
.prev-empty    { color:#666; font-size:13px; text-align:center; line-height:1.7; }

/* 뷰 스위치 */
.view-sw { display:flex; background:var(--gray-100); border-radius:10px; padding:3px; gap:3px; width:fit-content; }
.view-sw button { padding:6px 14px; border-radius:8px; border:none; background:transparent; font-size:13px; font-weight:600; color:var(--gray-600); cursor:pointer; transition:.2s; }
.view-sw button.on { background:#fff; color:var(--main-color); box-shadow:0 2px 8px rgba(0,0,0,.1); }

/* 텍스트 탭 */
.txt-tab-bar { display:flex; border-bottom:2px solid var(--gray-200); margin-bottom:14px; }
.txt-tab { padding:8px 20px; border:none; background:transparent; font-weight:600; font-size:13px; color:var(--gray-500); cursor:pointer; border-bottom:2px solid transparent; margin-bottom:-2px; transition:.2s; }
.txt-tab.on { color:var(--main-color); border-bottom-color:var(--main-color); }
.txt-panel { display:none; }
.txt-panel.on { display:block; }
.txt-box { background:var(--bg-soft); border-radius:12px; padding:18px; border:2px dashed var(--gray-300); margin-top:16px; }

/* 파일 업로드 */
.upload-area { border:2px dashed var(--gray-300); border-radius:12px; padding:28px; text-align:center; cursor:pointer; transition:.2s; background:var(--bg-soft); }
.upload-area:hover, .upload-area.on { border-color:var(--main-color); background:#f0f7ff; }
.upload-area input[type="file"] { display:none; }

/* 폼 */
.form-label { display:block; font-weight:600; font-size:13px; color:var(--t-color); margin-bottom:6px; }
.u-input { width:100%; padding:10px 14px; border:1.5px solid var(--gray-200); border-radius:8px; font-size:14px; transition:.2s; box-sizing:border-box; font-family:inherit; }
.u-input:focus { outline:none; border-color:var(--main-color); box-shadow:0 0 0 3px rgba(0,123,255,.08); }
.form-group { margin-bottom:14px; }
.color-row   { display:flex; align-items:center; gap:10px; }
.color-swatch { width:44px; height:44px; border-radius:8px; border:2px solid var(--gray-200); cursor:pointer; padding:2px; }

/* 모달 */
.bm-modal { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:9999; align-items:center; justify-content:center; }
.bm-modal.on { display:flex; }
.bm-box { background:#fff; border-radius:20px; padding:36px; max-width:880px; width:94%; max-height:92vh; overflow-y:auto; }

/* 토스트 */
.toast-alert { position:fixed; top:20px; right:20px; background:#fff; padding:20px; border-radius:12px; box-shadow:0 8px 24px rgba(0,0,0,.2); z-index:10000; min-width:280px; animation:sIn .3s ease-out; }
@keyframes sIn  { from{transform:translateX(400px);opacity:0} to{transform:translateX(0);opacity:1} }
@keyframes sOut { from{transform:translateX(0);opacity:1} to{transform:translateX(400px);opacity:0} }
</style>
</head>
<body>
<div id="admin_wrapper">
<?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>
<main class="content_area u-p-40">

<?php if (!$edit_mode): ?>
<!-- ============ 그룹 목록 ============ -->
<section class="card_custom">
  <div class="g-cols-fit-12 justify-content-between align-center u-mb-24">
    <h3 class="t-fs-32 fw-800">배너 그룹 관리</h3>
    <button onclick="openM('createModal')" class="u-btn u-btn-main u-px-24 u-py-12 rounded-8 fw-700 u-press g-self-end">+ 새 배너 그룹 생성</button>
  </div>
  <div class="g-cols-fit-12 u-gap-20">
  <?php
  $cnt = 0;
  while ($row = sql_fetch_array($banners_result)):
      $cnt++;
      $ri      = json_decode($row['images'], true);
      if (!is_array($ri)) $ri = array();
      $is_main = (bool)$row['is_main'];
  ?>
    <div class="banner-card <?php echo $is_main ? 'main-banner' : ''; ?>">
      <?php if ($is_main): ?><div class="main-badge">★ 메인</div><?php endif; ?>
      <h4 class="t-fs-24 fw-700 u-mb-8"><?php echo htmlspecialchars($row['name']); ?></h4>
      <div class="u-mb-10"><span class="id-badge" onclick="cpId(<?php echo $row['id']; ?>)"># <?php echo $row['id']; ?></span></div>
      <div class="d-flex u-gap-4 u-mb-10" style="height:100px;overflow:hidden;border-radius:8px;">
        <?php
        $pv = array_slice(array_reverse($ri), 0, 3);
        if ($pv):
            foreach ($pv as $p):
        ?>
          <img src="<?php echo htmlspecialchars($p['src']); ?>" style="flex:1;width:0;height:100%;object-fit:cover;" onerror="this.src='<?php echo $no_img; ?>'">
        <?php endforeach;
            if (count($ri) > 3):
        ?>
          <div style="flex:.4;background:var(--gray-100);display:flex;align-items:center;justify-content:center;font-size:11px;color:var(--gray-600);">+<?php echo count($ri) - 3; ?></div>
        <?php endif; else: ?>
          <div style="width:100%;height:100%;background:#f5f5f5;display:flex;align-items:center;justify-content:center;color:#ccc;font-size:12px;">이미지 없음</div>
        <?php endif; ?>
      </div>
      <p class="c-fs-14 u-txt-muted u-mb-14">이미지 <?php echo count($ri); ?>개</p>
      <div class="g-cols-fit-12 u-gap-4">
        <?php if (!$is_main): ?>
        <button onclick="setMain(<?php echo $row['id']; ?>)" class="u-btn u-btn-main u-px-12 u-py-6 rounded-4 fw-600 w-100 t-fs-16">메인으로 설정</button>
        <?php endif; ?>
        <a href="?edit=<?php echo $row['id']; ?>" class="u-btn u-bg-sub u-px-12 u-py-6 rounded-4 fw-600 w-100 text-center u-txt-white t-fs-16">관리</a>
        <button onclick="if(confirm('삭제하시겠습니까?'))location.href='?delete_group=<?php echo $row['id']; ?>'" class="u-btn t-fs-16 u-btn-gray u-px-12 u-py-6 rounded-4 fw-600 w-100">삭제</button>
      </div>
    </div>
  <?php endwhile; ?>
  <?php if ($cnt === 0): ?><p class="u-txt-muted text-center u-py-40">배너 그룹이 없습니다.</p><?php endif; ?>
  </div>
</section>

<?php else: ?>
<!-- ============ 편집 모드 ============ -->
<div class="u-mb-20">
  <a href="./banner_manager.php" class="u-btn u-btn-gray u-px-16 u-py-10 rounded-8 fw-600">← 목록으로</a>
</div>

<!-- Swiper 설정 -->
<section class="card_custom">
  <h3 class="t-fs-24 fw-800 u-mb-24">⚙️ Swiper 설정 — <?php echo htmlspecialchars($edit_banner['name']); ?></h3>
  <form method="post" class="g-cols-fit-12 u-gap-20">
    <input type="hidden" name="action" value="update_settings">
    <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
    <div class="form-group">
      <label class="form-label">Autoplay Delay (ms)</label>
      <input type="number" name="autoplay_delay" class="u-input" value="<?php echo (int)$edit_settings['autoplay_delay']; ?>" required>
      <small class="u-txt-muted">자동 넘김 시간 (기본 3000)</small>
    </div>
    <div class="form-group">
      <label class="form-label">전환 속도 (ms)</label>
      <input type="number" name="speed" class="u-input" value="<?php echo (int)$edit_settings['speed']; ?>" required>
    </div>
    <div class="form-group">
      <label class="form-label">Effect</label>
      <select name="effect" class="u-input">
        <?php foreach (array('slide','fade','cube','coverflow','flip') as $ef): ?>
        <option value="<?php echo $ef; ?>" <?php echo $edit_settings['effect'] === $ef ? 'selected' : ''; ?>><?php echo ucfirst($ef); ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group d-flex flex-column">
      <label class="form-label">무한 반복</label>
      <label class="u-check-wrap u-mt-8">
        <input type="checkbox" name="loop" value="1" class="u-check" <?php echo $edit_settings['loop'] ? 'checked' : ''; ?>>
        <span>Loop 활성화</span>
      </label>
    </div>
    <div class="d-flex align-items-center">
      <button type="submit" class="u-btn u-btn-main u-px-32 u-py-12 rounded-8 fw-700 u-press">설정 저장</button>
    </div>
  </form>
</section>

<!-- ============ 이미지 추가 ============ -->
<section class="card_custom">
  <h3 class="t-fs-24 fw-800 u-mb-24">➕ 이미지 추가</h3>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="action" value="add_image">
    <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
    <div class="add-grid">

      <!-- 왼쪽: 입력 영역 -->
      <div>
        <div class="form-group">
          <label class="form-label">이미지 파일 *</label>
          <div class="upload-area" id="uploadArea" onclick="document.getElementById('fileIn').click()">
            <input type="file" id="fileIn" name="banner_image" accept="image/*" required onchange="onFile(this)">
            <div id="uploadPh">
              <div style="font-size:34px;margin-bottom:8px">🖼️</div>
              <div style="font-weight:700;font-size:15px;margin-bottom:4px">클릭하여 이미지 선택</div>
              <div style="font-size:12px;color:var(--gray-500)">JPG · PNG · GIF · WEBP</div>
            </div>
            <div id="uploadOk" style="display:none;font-weight:700;font-size:14px;color:var(--main-color)">
              ✅ <span id="uploadName"></span>
            </div>
          </div>
        </div>

        <!-- 모바일 이미지 업로드 -->
        <div class="form-group" style="margin-top:12px">
          <label class="form-label">📱 모바일 이미지 <small style="font-weight:400;color:#aaa">선택 안 하면 웹 이미지 그대로 사용 (992px 이하)</small></label>
          <div class="upload-area" id="uploadAreaMob" onclick="document.getElementById('fileInMob').click()">
            <input type="file" id="fileInMob" name="banner_image_mobile" accept="image/*" onchange="onFileMob(this)">
            <div id="uploadPhMob">
              <div style="font-size:24px;margin-bottom:6px">📱</div>
              <div style="font-weight:700;font-size:14px;margin-bottom:4px">모바일 이미지 선택 (선택)</div>
              <div style="font-size:12px;color:var(--gray-500)">JPG · PNG · GIF · WEBP</div>
            </div>
            <div id="uploadOkMob" style="display:none;font-weight:700;font-size:14px;color:#9b59b6">
              ✅ <span id="uploadNameMob"></span>
            </div>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div class="form-group" style="grid-column:1/-1">
            <label class="form-label">배너 링크 URL</label>
            <input type="url" name="link" class="u-input" placeholder="https://example.com">
            <label class="u-check-wrap u-mt-8"><input type="checkbox" name="link_target" value="1" class="u-check"><span>새 창에서 열기 (target="_blank")</span></label>
          </div>
          <div class="form-group">
            <label class="form-label">노출 상태</label>
            <label class="u-check-wrap u-mt-10"><input type="checkbox" name="visible" value="1" class="u-check" checked><span>노출</span></label>
          </div>
          <div class="form-group">
            <label class="form-label">노출 시작일</label>
            <input type="date" name="start_date" class="u-input">
          </div>
          <div class="form-group">
            <label class="form-label">노출 종료일</label>
            <input type="date" name="end_date" class="u-input">
          </div>
        </div>

        <div class="txt-box">
          <div style="font-weight:700;font-size:15px;margin-bottom:14px">📝 텍스트 설정</div>
          <div class="txt-tab-bar">
            <button type="button" class="txt-tab on" onclick="txTab(this,'add','web')">🖥️ 웹</button>
            <button type="button" class="txt-tab"    onclick="txTab(this,'add','mob')">📱 모바일</button>
          </div>
          <div class="txt-panel on" id="add-p-web"><?php echo txFields('web', 'add'); ?></div>
          <div class="txt-panel"    id="add-p-mob"><?php echo txFields('mob', 'add'); ?></div>
        </div>
      </div>

      <!-- 오른쪽: 미리보기 -->
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
          <div style="font-weight:700;font-size:15px">👁️ 미리보기</div>
          <div class="view-sw">
            <button type="button" class="on" onclick="vSw(this,'add','web')" id="add-sw-web">🖥️ 웹</button>
            <button type="button"             onclick="vSw(this,'add','mob')" id="add-sw-mob">📱 모바일</button>
          </div>
        </div>
        <div class="preview-wrap" id="add-pw">
          <div class="preview-bg" id="add-bg"></div>
          <div class="preview-overlay" id="add-ov">
            <div class="prev-empty" id="add-ph">이미지를 선택하면<br>미리보기가 표시됩니다</div>
            <div id="add-ct" style="display:none">
              <div class="prev-subtitle" id="add-sub"></div>
              <div class="prev-title"    id="add-ttl"></div>
              <div class="prev-desc"     id="add-dsc"></div>
              <div class="prev-btn"      id="add-btn" style="display:none"></div>
            </div>
          </div>
        </div>
        <p style="font-size:11px;color:var(--gray-400);text-align:center;margin-top:8px">※ 실제 화면과 다를 수 있습니다</p>
      </div>
    </div>

    <button type="submit" class="u-btn u-btn-main u-px-32 u-py-14 rounded-8 fw-700 u-press u-mt-24" style="width:100%;font-size:16px">➕ 이미지 추가</button>
  </form>
</section>

<!-- ============ 등록된 이미지 ============ -->
<section class="card_custom">
  <h3 class="t-fs-24 fw-800 u-mb-24">📸 등록된 이미지 (<?php echo count($edit_images); ?>개)</h3>
  <?php if (count($edit_images) > 0): ?>
  <div id="imageList">
  <?php foreach ($edit_images as $i => $img):
      $ts  = isset($img['text_settings']) ? $img['text_settings'] : array();
      $web = isset($ts['web'])    ? $ts['web']    : $ts;
      $mob = isset($ts['mobile']) ? $ts['mobile'] : array();
  ?>
    <div class="img-card" data-index="<?php echo $i; ?>">
      <span class="img-badge <?php echo $img['visible'] ? '' : 'off'; ?>"><?php echo $img['visible'] ? '노출' : '비노출'; ?></span>
      <img class="img-card-thumb" src="<?php echo htmlspecialchars($img['src']); ?>" onerror="this.src='<?php echo $no_img; ?>'" alt="">
      <?php if (!empty($img['src_mobile'])): ?>
      <span style="position:absolute;top:8px;left:8px;background:#9b59b6;color:#fff;border-radius:6px;padding:2px 8px;font-size:10px;font-weight:700">📱 모바일별도</span>
      <?php endif; ?>
      <div class="img-card-body">
        <?php if (!empty($web['title']) || !empty($web['subtitle'])): ?>
        <div style="padding:8px;background:var(--bg-soft);border-radius:8px;margin-bottom:8px;font-size:12px">
          <div style="color:var(--gray-400);margin-bottom:3px">🖥️ 웹</div>
          <?php if (!empty($web['subtitle'])): ?><div style="color:var(--gray-500)"><?php echo htmlspecialchars($web['subtitle']); ?></div><?php endif; ?>
          <?php if (!empty($web['title'])): ?><div style="font-weight:700"><?php echo htmlspecialchars(strip_tags(str_replace('<br>', "\n", $web['title']))); ?></div><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($mob['title'])): ?>
        <div style="padding:8px;background:#f3e8ff;border-radius:8px;margin-bottom:8px;font-size:12px">
          <div style="color:#9333ea;margin-bottom:3px">📱 모바일</div>
          <div style="font-weight:700"><?php echo htmlspecialchars(strip_tags(str_replace('<br>', "\n", $mob['title']))); ?></div>
        </div>
        <?php endif; ?>
        <div style="font-size:11px;color:var(--gray-400);margin-bottom:10px">
          순서 <strong><?php echo $img['order']; ?></strong> · 링크 <?php echo $img['link'] ? '✅' . ((!empty($img['link_target']) && $img['link_target'] === '_blank') ? ' 새창' : '') : '없음'; ?>
          <?php if ($img['start_date'] || $img['end_date']): ?>
          · <?php echo $img['start_date'] ?: '∞'; ?> ~ <?php echo $img['end_date'] ?: '∞'; ?>
          <?php endif; ?>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
          <button onclick='openEdit(<?php echo $i; ?>, <?php echo json_encode($img, JSON_HEX_APOS | JSON_HEX_QUOT); ?>)'
                  class="u-btn u-btn-main u-px-10 u-py-8 rounded-8 fw-600 w-100" style="font-size:12px">✏️ 수정</button>
          <button onclick="if(confirm('삭제하시겠습니까?'))location.href='?delete_image=<?php echo $i; ?>&banner_id=<?php echo $edit_id; ?>'"
                  class="u-btn u-btn-gray u-px-10 u-py-8 rounded-8 fw-600 w-100" style="font-size:12px">🗑️ 삭제</button>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  <?php else: ?>
  <p class="u-txt-muted text-center u-py-40">등록된 이미지가 없습니다.</p>
  <?php endif; ?>
</section>

<?php endif; ?>
</main>
</div>

<!-- 생성 모달 -->
<div id="createModal" class="bm-modal">
  <div class="bm-box" style="max-width:460px">
    <h2 class="t-fs-24 fw-800 u-mb-20">새 배너 그룹 생성</h2>
    <form method="post">
      <input type="hidden" name="action" value="create_group">
      <div class="form-group u-mb-16">
        <label class="form-label">배너 그룹 이름</label>
        <input type="text" name="banner_name" class="u-input" placeholder="예: 메인 배너" required>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        <button type="button" onclick="closeM('createModal')" class="u-btn u-btn-gray u-px-20 u-py-10 rounded-8 fw-600 w-100">취소</button>
        <button type="submit" class="u-btn u-btn-main u-px-20 u-py-10 rounded-8 fw-700 u-press w-100">생성</button>
      </div>
    </form>
  </div>
</div>

<!-- 수정 모달 -->
<div id="editModal" class="bm-modal">
  <div class="bm-box">
    <h2 class="t-fs-24 fw-800 u-mb-20">이미지 수정</h2>
    <form method="post">
      <input type="hidden" name="action" value="update_image">
      <input type="hidden" name="banner_id" value="<?php echo $edit_id; ?>">
      <input type="hidden" name="image_index" id="eIdx">
      <div class="add-grid">
        <!-- 입력 -->
        <div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
            <div class="form-group" style="grid-column:1/-1">
              <label class="form-label">배너 링크 URL</label>
              <input type="url" name="link" id="eLink" class="u-input">
              <label class="u-check-wrap u-mt-8"><input type="checkbox" name="link_target" id="eLinkTarget" value="1" class="u-check"><span>새 창에서 열기 (target="_blank")</span></label>
            </div>
            <div class="form-group">
              <label class="form-label">노출</label>
              <label class="u-check-wrap u-mt-10"><input type="checkbox" name="visible" value="1" id="eVis" class="u-check"><span>노출</span></label>
            </div>
            <div class="form-group">
              <label class="form-label">시작일</label>
              <input type="date" name="start_date" id="eSt" class="u-input">
            </div>
            <div class="form-group">
              <label class="form-label">종료일</label>
              <input type="date" name="end_date" id="eEd" class="u-input">
            </div>
          </div>

          <!-- 모바일 이미지 수정 -->
          <div class="form-group" style="margin-top:12px;padding:14px;background:var(--bg-soft);border-radius:10px;border:2px dashed #c084fc">
            <label class="form-label">📱 모바일 이미지 <small style="font-weight:400;color:#9b59b6">992px 이하에서 표시 (없으면 웹 이미지 사용)</small></label>
            <div id="edit-mob-none" style="font-size:12px;color:var(--gray-500);margin-bottom:8px">현재 모바일 이미지 없음</div>
            <div id="edit-mob-preview" style="display:none;width:100%;height:80px;background-size:cover;background-position:center;border-radius:8px;margin-bottom:8px;position:relative">
              <button type="button" onclick="delMobImg()" style="position:absolute;top:4px;right:4px;background:rgba(0,0,0,.6);color:#fff;border:none;border-radius:50%;width:22px;height:22px;cursor:pointer;font-size:12px;line-height:1">✕</button>
            </div>
            <input type="hidden" name="delete_mobile_img" id="eDelMob" value="0">
            <div class="upload-area" style="padding:16px" onclick="document.getElementById('eFileMob').click()">
              <input type="file" id="eFileMob" name="banner_image_mobile" accept="image/*" onchange="onEditFileMob(this)">
              <div style="font-size:13px;color:var(--gray-600)">클릭하여 모바일 이미지 교체</div>
            </div>
          </div>

          <div class="txt-box">
            <div style="font-weight:700;font-size:15px;margin-bottom:14px">📝 텍스트 설정</div>
            <div class="txt-tab-bar">
              <button type="button" class="txt-tab on" onclick="txTab(this,'edit','web')">🖥️ 웹</button>
              <button type="button" class="txt-tab"    onclick="txTab(this,'edit','mob')">📱 모바일</button>
            </div>
            <div class="txt-panel on" id="edit-p-web"><?php echo txFields('web', 'edit'); ?></div>
            <div class="txt-panel"    id="edit-p-mob"><?php echo txFields('mob', 'edit'); ?></div>
          </div>
        </div>
        <!-- 미리보기 -->
        <div>
          <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;flex-wrap:wrap;gap:8px">
            <div style="font-weight:700;font-size:15px">👁️ 미리보기</div>
            <div class="view-sw">
              <button type="button" class="on" onclick="vSw(this,'edit','web')" id="edit-sw-web">🖥️ 웹</button>
              <button type="button"             onclick="vSw(this,'edit','mob')" id="edit-sw-mob">📱 모바일</button>
            </div>
          </div>
          <div class="preview-wrap" id="edit-pw">
            <div class="preview-bg" id="edit-bg"></div>
            <div class="preview-overlay" id="edit-ov">
              <div id="edit-ct">
                <div class="prev-subtitle" id="edit-sub"></div>
                <div class="prev-title"    id="edit-ttl"></div>
                <div class="prev-desc"     id="edit-dsc"></div>
                <div class="prev-btn"      id="edit-btn" style="display:none"></div>
              </div>
            </div>
          </div>
          <p style="font-size:11px;color:var(--gray-400);text-align:center;margin-top:8px">※ 실제 화면과 다를 수 있습니다</p>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:20px">
        <button type="button" onclick="closeM('editModal')" class="u-btn u-btn-gray u-px-20 u-py-12 rounded-8 fw-600 w-100">취소</button>
        <button type="submit" class="u-btn u-btn-main u-px-20 u-py-12 rounded-8 fw-700 u-press w-100">저장</button>
      </div>
    </form>
  </div>
</div>

<script>
// 모달
function openM(id)  { document.getElementById(id).classList.add('on'); }
function closeM(id) { document.getElementById(id).classList.remove('on'); }
document.querySelectorAll('.bm-modal').forEach(function(m) {
    m.addEventListener('click', function(e) { if (e.target === m) closeM(m.id); });
});

// 뷰 스위치
function vSw(btn, scope, type) {
    btn.closest('.view-sw').querySelectorAll('button').forEach(function(b){ b.classList.remove('on'); });
    btn.classList.add('on');
    document.getElementById(scope + '-pw').classList.toggle('mob', type === 'mob');
    upPrev(scope);
}

// 텍스트 탭 전환
function txTab(btn, scope, type) {
    btn.closest('.txt-tab-bar').querySelectorAll('.txt-tab').forEach(function(b){ b.classList.remove('on'); });
    btn.classList.add('on');
    document.querySelectorAll('[id^="' + scope + '-p-"]').forEach(function(p){ p.classList.remove('on'); });
    document.getElementById(scope + '-p-' + type).classList.add('on');
    var sw = document.getElementById(scope + '-sw-' + type);
    if (sw) {
        sw.closest('.view-sw').querySelectorAll('button').forEach(function(b){ b.classList.remove('on'); });
        sw.classList.add('on');
    }
    document.getElementById(scope + '-pw').classList.toggle('mob', type === 'mob');
    upPrev(scope);
}

// 활성 타입
function activeType(scope) {
    var p = document.querySelector('[id^="' + scope + '-p-"].on');
    return p ? p.id.replace(scope + '-p-', '') : 'web';
}

// 실시간 미리보기
function upPrev(scope) {
    var t   = activeType(scope);
    var pfx = (scope === 'add') ? (t + '_') : ('edit_' + t + '_');
    var g   = function(id){ return document.getElementById(id); };

    var sub = (g(pfx + 'subtitle')      ? g(pfx + 'subtitle').value      : '') || '';
    var ttl = (g(pfx + 'title')         ? g(pfx + 'title').value         : '') || '';
    var dsc = (g(pfx + 'description')   ? g(pfx + 'description').value   : '') || '';
    var btn = (g(pfx + 'button_text')   ? g(pfx + 'button_text').value   : '') || '';
    var col = (g(pfx + 'text_color')    ? g(pfx + 'text_color').value    : '') || '#ffffff';
    var pos = (g(pfx + 'text_position') ? g(pfx + 'text_position').value : '') || 'left';

    var ov = g(scope + '-ov');
    if (!ov) return;

    ov.className = 'preview-overlay' + (pos === 'center' ? ' pos-center' : (pos === 'right' ? ' pos-right' : ''));

    // HTML 태그 그대로 렌더링
    var subEl = g(scope + '-sub'); if (subEl){ subEl.innerHTML = sub; subEl.style.color = col; subEl.style.display = sub ? '' : 'none'; }
    var ttlEl = g(scope + '-ttl'); if (ttlEl){ ttlEl.innerHTML = ttl; ttlEl.style.color = col; ttlEl.style.display = ttl ? '' : 'none'; }
    var dscEl = g(scope + '-dsc'); if (dscEl){ dscEl.innerHTML = dsc; dscEl.style.color = col; dscEl.style.display = dsc ? '' : 'none'; }
    var btnEl = g(scope + '-btn'); if (btnEl){ btnEl.textContent = btn; btnEl.style.display = btn ? '' : 'none'; }
    var ph = g(scope + '-ph'); if (ph) ph.style.display = 'none';
    var ct = g(scope + '-ct'); if (ct) ct.style.display = 'block';
}

// 파일 선택 (웹)
function onFile(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    document.getElementById('uploadPh').style.display  = 'none';
    document.getElementById('uploadOk').style.display  = 'block';
    document.getElementById('uploadName').textContent  = f.name;
    document.getElementById('uploadArea').classList.add('on');
    var r = new FileReader();
    r.onload = function(e) {
        document.getElementById('add-bg').style.backgroundImage = 'url(' + e.target.result + ')';
        var ph = document.getElementById('add-ph'); if (ph) ph.style.display = 'none';
        var ct = document.getElementById('add-ct'); if (ct) ct.style.display = 'block';
    };
    r.readAsDataURL(f);
}

// 파일 선택 (모바일 - 추가 폼)
function onFileMob(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    document.getElementById('uploadPhMob').style.display = 'none';
    document.getElementById('uploadOkMob').style.display = 'block';
    document.getElementById('uploadNameMob').textContent = f.name;
    document.getElementById('uploadAreaMob').classList.add('on');
}

// 파일 선택 (모바일 - 수정 모달)
function onEditFileMob(input) {
    if (!input.files || !input.files[0]) return;
    var f = input.files[0];
    var r = new FileReader();
    r.onload = function(e) {
        var p = document.getElementById('edit-mob-preview');
        var n = document.getElementById('edit-mob-none');
        if (p) { p.style.backgroundImage = 'url(' + e.target.result + ')'; p.style.display = 'block'; }
        if (n) n.style.display = 'none';
        document.getElementById('eDelMob').value = '0';
    };
    r.readAsDataURL(f);
}

// 모바일 이미지 삭제 (수정 모달)
function delMobImg() {
    document.getElementById('eDelMob').value = '1';
    var p = document.getElementById('edit-mob-preview');
    var n = document.getElementById('edit-mob-none');
    if (p) p.style.display = 'none';
    if (n) n.style.display = 'block';
    var fi = document.getElementById('eFileMob'); if (fi) fi.value = '';
}

// 입력 이벤트 바인딩
function bindInputs(scope) {
    ['web', 'mob'].forEach(function(t) {
        var pfx = (scope === 'add') ? (t + '_') : ('edit_' + t + '_');
        ['subtitle','title','description','button_text','text_color','text_position'].forEach(function(f) {
            var el = document.getElementById(pfx + f);
            if (el) el.addEventListener('input', function(){ upPrev(scope); });
        });
    });
}
bindInputs('add');

// 수정 모달 열기
function openEdit(idx, data) {
    var g  = function(id){ return document.getElementById(id); };
    var sv = function(id, v){ var el = g(id); if (el) el.value = v || ''; };

    g('eIdx').value         = idx;
    g('eLink').value        = data.link       || '';
    g('eLinkTarget').checked = data.link_target === '_blank';
    g('eSt').value          = data.start_date || '';
    g('eEd').value          = data.end_date   || '';
    g('eVis').checked       = data.visible == 1;

    var ts  = data.text_settings || {};
    var web = ts.web    || ts;
    var mob = ts.mobile || {};

    sv('edit_web_subtitle',      web.subtitle      || '');
    sv('edit_web_title',         web.title         || '');
    sv('edit_web_description',   web.description   || '');
    // HTML 태그가 포함된 값은 textarea에 그대로 표시
    sv('edit_web_button_text',   web.button_text   || '');
    sv('edit_web_button_link',   web.button_link   || '');
    sv('edit_web_text_color',    web.text_color    || '#ffffff');
    sv('edit_web_text_position', web.text_position || 'left');

    sv('edit_mob_subtitle',      mob.subtitle      || '');
    sv('edit_mob_title',         mob.title         || '');
    sv('edit_mob_description',   mob.description   || '');
    sv('edit_mob_button_text',   mob.button_text   || '');
    sv('edit_mob_button_link',   mob.button_link   || '');
    sv('edit_mob_text_color',    mob.text_color    || '#ffffff');
    sv('edit_mob_text_position', mob.text_position || 'left');

    ['web','mob'].forEach(function(t){
        var c = g('edit_' + t + '_text_color'); var h = g('edit_' + t + '_text_color_hex');
        if (c && h) h.value = c.value;
    });

    g('edit-bg').style.backgroundImage = 'url(' + data.src + ')';

    document.querySelectorAll('[id^="edit-p-"]').forEach(function(p){ p.classList.remove('on'); });
    g('edit-p-web').classList.add('on');
    document.querySelectorAll('#editModal .txt-tab').forEach(function(b, i){ b.classList.toggle('on', i === 0); });

    openM('editModal');
    bindInputs('edit');
    setTimeout(function(){ upPrev('edit'); }, 80);
}

// Sortable
var il = document.getElementById('imageList');
if (il) {
    new Sortable(il, {
        animation: 150,
        ghostClass: 'sortable-ghost',
        onEnd: function() {
            var items = document.querySelectorAll('.img-card');
            var ord   = Array.from(items).map(function(el){ return parseInt(el.dataset.index); });
            var fd    = new FormData();
            fd.append('action',    'reorder_images');
            fd.append('banner_id', '<?php echo $edit_id; ?>');
            fd.append('order',     JSON.stringify(ord));
            fetch('banner_manager.php', { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(d){ if (d.success) location.reload(); })
                .catch(console.error);
        }
    });
}

// 메인 설정
function setMain(id) {
    var t = document.createElement('div');
    t.className = 'toast-alert';
    t.innerHTML = '<div style="margin-bottom:12px"><h4 style="margin:0 0 5px;font-size:15px;font-weight:700">메인 배너 변경</h4><p style="margin:0;color:#666;font-size:13px">메인으로 설정하시겠습니까?</p></div><div style="display:flex;gap:8px"><button onclick="doSetMain(' + id + ',this)" class="u-btn u-btn-main u-px-14 u-py-7 rounded-8 fw-700" style="flex:1">확인</button><button onclick="rmToast(this)" class="u-btn u-btn-gray u-px-14 u-py-7 rounded-8 fw-600" style="flex:1">취소</button></div>';
    document.body.appendChild(t);
}
function doSetMain(id, btn) {
    btn.disabled = true; btn.textContent = '처리중...';
    var fd = new FormData();
    fd.append('set_main_banner', '1');
    fd.append('banner_id', id);
    fetch('banner_manager.php', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d){ if (d.success){ showToast(d.message, 'success'); setTimeout(function(){ location.reload(); }, 800); } });
}
function rmToast(btn) {
    var t = btn.closest('.toast-alert');
    t.style.animation = 'sOut .3s ease-out forwards';
    setTimeout(function(){ t.remove(); }, 300);
}

// ID 복사
function cpId(id) {
    navigator.clipboard.writeText(String(id)).then(function(){ showToast('ID 복사됨 (' + id + ')', 'success'); });
}

// 토스트
function showToast(msg, type) {
    type = type || 'success';
    var old = document.querySelector('.toast-message'); if (old) old.remove();
    var t = document.createElement('div');
    t.className = 'toast-message';
    var bg = type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#f59e0b';
    t.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:' + bg + ';color:#fff;padding:13px 26px;border-radius:12px;font-size:14px;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.15);z-index:10000;transition:opacity .3s';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.style.opacity = '0'; setTimeout(function(){ t.remove(); }, 300); }, 2500);
}
</script>
</body>
</html>