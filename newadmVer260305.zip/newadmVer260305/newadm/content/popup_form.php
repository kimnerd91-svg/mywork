<?php
// 1. 경로 수정: 현재 파일의 위치를 기준으로 _common.php를 찾습니다.
// 만약 이 파일이 /newadm/content/ 폴더 안에 있다면 ../_common.php 가 맞습니다.
// 파일 위치에 맞춰서 아래 경로를 조절하세요.
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');


// 만약 위 코드로 에러가 난다면 아래처럼 절대경로 방식을 시도하세요.
// include_once($_SERVER['DOCUMENT_ROOT'].'/newadm/_common.php');

$nw_id = (int)$_GET['nw_id'];
$mode = $nw_id ? 'u' : 'w';
$nw = $nw_id ? sql_fetch(" SELECT * FROM dm_popup WHERE nw_id = '$nw_id' ") : [];

if (!$nw_id) {
    $nw['nw_begin_time'] = date('Y-m-d H:i:s');
    $nw['nw_end_time'] = date('Y-m-d H:i:s', strtotime('+7 days'));
    $nw['nw_width'] = 500;
    $nw['nw_height'] = 500;
    $nw['nw_left'] = 0;
    $nw['nw_top'] = 0;
    $nw['nw_status'] = 1;
    $nw['nw_subject'] = '';
    $nw['nw_img'] = '';
    $nw['nw_link'] = '';
    $nw['nw_target'] = '_blank';
}
// aside.php를 위한 경로 정의 (G5_NEWADM_PATH가 정의 안되어 있을 경우 대비)
if (!defined('G5_NEWADM_PATH')) {
    define('G5_NEWADM_PATH', $_SERVER['DOCUMENT_ROOT'] . '/newadm');
}
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>팝업 설정 - 관리자</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">


    <style>
        /* aside가 출력될 공간 확보를 위해 wrapper 스타일 확인 */
        #admin_wrapper {
            display: flex;
            min-height: 100vh;
        }

        .content_area {
            flex: 1;
            padding: 40px;
            background: #f8f9fa;
        }
    </style>
</head>

<body>
    <div id="admin_wrapper">
        <?php
        // 2. include 경로 직접 지정 (가장 확실한 방법)
        include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php');
        ?>

        <main class="content_area">
            <div class="u-mb-40">
                <h2 class="fw-900 t-fs-32">🖼️ 팝업 상세 설정</h2>
                <p class="u-txt-muted u-mt-10">팝업의 노출 기간과 크기, 위치를 세부적으로 설정합니다.</p>
            </div>

            <form action="popup_update.php" method="post" enctype="multipart/form-data">
                <input type="hidden" name="nw_id" value="<?php echo $nw_id; ?>">
                <input type="hidden" name="mode" value="<?php echo $mode; ?>">
                <input type="hidden" name="nw_img_old" value="<?php echo $nw['nw_img']; ?>">

                <section class="card_custom">

                    <h3 class="t-fs-28 fw-800 u-mb-24 u-pb-10 u-border-bottom">📌 기본 관리 정보</h3>

                    <div class="g-cols-12 gap-20 u-align-center u-mb-24">
                        <div class="g-cols-fit-12 fw-700 t-fs-16 u-mb-16">팝업 제목</div>
                        <div class="grid-span-5 u-mb-24">
                            <input type="text" name="nw_subject" value="<?php echo $nw['nw_subject']; ?>" class="u-input u-px-16 u-py-4" placeholder="관리용 제목을 입력하세요" required>
                        </div>
                        <div class="grid-span-2 fw-700 t-fs-16 u-txt-center u-mb-16">노출 여부</div>
                        <div class="grid-span-2 u-mb-24">
                            <select name="nw_status" class="u-input u-select  u-px-16 u-py-4">
                                <option value="1" <?php echo $nw['nw_status'] == 1 ? 'selected' : ''; ?>>✅ 노출함</option>
                                <option value="0" <?php echo $nw['nw_status'] == 0 ? 'selected' : ''; ?>>❌ 중지</option>
                            </select>
                        </div>
                    </div>

                    <h3 class="t-fs-28 fw-800 u-mb-24 u-pb-10 u-border-bottom u-mt-40">🔗 링크 설정</h3>
                    <div class="g-cols-12 gap-20 u-align-center u-mb-24">
                        <div class="g-cols-fit-12 fw-700 t-fs-16 u-mb-16">클릭 시 이동 URL</div>
                        <div class="grid-span-6 u-mb-8">
                            <input type="text" name="nw_link" value="<?php echo isset($nw['nw_link']) ? $nw['nw_link'] : ''; ?>" class="u-input u-px-16 u-py-4" placeholder="https://example.com (선택사항)">
                            <p class="u-txt-muted t-fs-13 u-mt-8">※ 비워두면 클릭해도 이동하지 않습니다.</p>
                        </div>
                        <div class="g-cols-fit-12">
                            <select name="nw_target" class="u-input u-select u-px-16 u-py-4">
                                <option value="_blank" <?php echo (isset($nw['nw_target']) && $nw['nw_target'] == '_blank') ? 'selected' : ''; ?>>🔗 새창으로 열기</option>
                                <option value="_self" <?php echo (isset($nw['nw_target']) && $nw['nw_target'] == '_self') ? 'selected' : ''; ?>>📄 현재창에서 열기</option>
                            </select>
                        </div>
                    </div>

                    <h3 class="t-fs-28 fw-800 u-mb-24 u-pb-10 u-border-bottom u-mt-40">📅 노출 기간 설정</h3>
                    <div class="g-cols-12 gap-20 u-align-center u-mb-24">
                        <div class="g-cols-fit-12 fw-700 t-fs-16 u-mb-16">시작 일시</div>
                        <div class="g-cols-fit-12 u-mb-8">
                            <input type="text"
                                id="nw_begin_time"
                                name="nw_begin_time"
                                value="<?php echo $nw['nw_begin_time']; ?>"
                                class="u-input u-px-16 u-py-4"
                                placeholder="YYYY-MM-DD 00:00:00"
                                readonly>
                        </div>
                        <div class="g-cols-fit-12 fw-700 t-fs-16 u-txt-center u-mb-16">종료 일시</div>
                        <div class="g-cols-fit-12">
                            <input type="text"
                                id="nw_end_time"
                                name="nw_end_time"
                                value="<?php echo $nw['nw_end_time']; ?>"
                                class="u-input u-px-16 u-py-4"
                                placeholder="YYYY-MM-DD 00:00:00"
                                readonly>
                        </div>
                    </div>

                    <h3 class="t-fs-28 fw-800 u-mb-24 u-pb-10 u-border-bottom u-mt-40">📐 크기 및 위치 (Pixel)</h3>
                    <div class="g-cols-12 gap-20 u-align-center u-mb-24">
                        <div class="grid-span-2 fw-700 t-fs-16 u-mb-16">가로 크기</div>
                        <div class="grid-span-2 u-mb-8">
                            <input type="number" name="nw_width" value="<?php echo $nw['nw_width']; ?>" class="u-input  u-px-16 u-py-4">
                        </div>
                        <div class="grid-span-2 fw-700 t-fs-16 u-txt-center u-mb-16">세로 크기</div>
                        <div class="grid-span-2 u-mb-8">
                            <input type="number" name="nw_height" value="<?php echo $nw['nw_height']; ?>" class="u-input  u-px-16 u-py-4">
                        </div>
                        <div class="grid-span-2 fw-700 t-fs-16 u-txt-center u-mb-16">좌측 위치</div>
                        <div class="grid-span-2">
                            <input type="number" name="nw_left" value="<?php echo $nw['nw_left']; ?>" class="u-input  u-px-16 u-py-4">
                        </div>
                    </div>
                    <div class="g-cols-12 gap-20 u-align-center u-mb-24">
                        <div class="grid-span-2 fw-700 t-fs-16 u-mb-16">상단 위치</div>
                        <div class="grid-span-2">
                            <input type="number" name="nw_top" value="<?php echo $nw['nw_top']; ?>" class="u-input  u-px-16 u-py-4">
                        </div>
                    </div>

                    <h3 class="t-fs-28 fw-800 u-mb-24 u-pb-10 u-border-bottom u-mt-40">🖼️ 팝업 이미지</h3>
                    <div class="g-cols-12 gap-20 u-mb-24">
                        <div class="g-cols-fit-12 fw-700 t-fs-16 u-mb-16">이미지 첨부</div>
                        <div class="grid-span-9">
                            <input type="file" name="nw_img_file" class="u-input u-mb-20">
                            <?php if ($nw['nw_img']) { ?>
                                <div class="u-p-20 u-bg-soft rounded-12 u-border">
                                    <p class="u-mb-10 t-fs-14 fw-600">현재 등록된 이미지:</p>
                                    <img src="<?php echo G5_DATA_URL; ?>/popup/<?php echo $nw['nw_img']; ?>" class="shadow-sm" style="max-width:300px; border-radius:8px;">
                                </div>
                            <?php } ?>
                        </div>
                    </div>

                    <div class="u-flex u-justify-center u-gap-16 u-mt-60">
                        <button type="button" onclick="history.back();" class="u-px-24 u-py-12 rounded-8 fw-700 u-btn u-btn-sub u-bg-gray u-lift">취소</button>
                        <button type="submit" class="u-btn u-bg-main u-txt-white u-px-24 u-py-12 rounded-8 fw-900 shadow-main u-lift u-press">설정 저장하기</button>
                    </div>
                </section>
            </form>
        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/ko.js"></script>
<script>
// 시작 일시 달력
flatpickr("#nw_begin_time", {
    enableTime: true,
    dateFormat: "Y-m-d H:i:S",
    time_24hr: true,
    locale: "ko",
    onChange: function(selectedDates, dateStr, instance) {
        // 종료일이 시작일보다 이전이면 종료일을 시작일로 설정
        const endPicker = document.querySelector("#nw_end_time")._flatpickr;
        if (endPicker.selectedDates[0] && selectedDates[0] > endPicker.selectedDates[0]) {
            endPicker.setDate(selectedDates[0]);
        }
    }
});

// 종료 일시 달력
flatpickr("#nw_end_time", {
    enableTime: true,
    dateFormat: "Y-m-d H:i:S",
    time_24hr: true,
    locale: "ko"
});
</script>
</body>

</html>