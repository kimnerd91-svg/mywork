<?php
// content/multilang_manager.php

// 경로수정: 한 단계 위 newadm 폴더의 _common.php 호출
include_once('../_common.php');
include_once('../_auth_check.php');

// G5_DATA_PATH가 정의되어 있지 않을 경우를 대비한 안전장치
$json_dir = G5_DATA_PATH . '/content';
if(!is_dir($json_dir)) {
    @mkdir($json_dir, G5_DIR_PERMISSION);
    @chmod($json_dir, G5_DIR_PERMISSION);
}
$json_file = $json_dir . '/multilang.json';

// [1] 데이터 저장 로직
if (isset($_POST['mode']) && $_POST['mode'] == 'update') {
    $translations = json_decode(stripslashes($_POST['translations_json']), true);
    
    // 데이터 구조 검증 (배열이 아니면 빈 객체로 방어)
    if(!is_array($translations)) $translations = new stdClass();

    $save_data = [
        'auto_script' => $_POST['auto_script'],
        'translations' => $translations
    ];
    
    $json_content = json_encode($save_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
    if(file_put_contents($json_file, $json_content)) {
        alert('설정이 저장되었습니다.', './multilang_manager.php');
    } else {
        alert('파일 쓰기 권한이 없습니다. data 폴더 권한을 확인하세요.');
    }
}

// [2] 데이터 로드
$config_data = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : ['auto_script'=>'', 'translations'=>[]];
$initial_translations = !empty($config_data['translations']) ? $config_data['translations'] : new stdClass();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>다국어 관리 - NEW ADM</title>

    <style>
        #admin_wrapper { display: grid; grid-template-columns: 280px 1fr; min-height: 100vh; }
        .content_area { background-color: var(--bg-soft); padding: 40px; }
        .card_custom { background: white; border-radius: 24px; padding: 32px; margin-bottom: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
        .tab_menu { display: flex; gap: 8px; margin-bottom: 30px; border-bottom: 1px solid #eee; }
        .tab_btn { padding: 12px 24px; border: none; background: none; font-weight: 700; color: #999; cursor: pointer; border-bottom: 3px solid transparent; }
        .tab_btn.active { color: var(--main-color); border-bottom-color: var(--main-color); }
        .tab_content { display: none; }
        .tab_content.active { display: block; }
        .id-copy-badge { 
            display: flex; align-items: center; justify-content: space-between;
            background: #f0f7ff; color: #007bff; border: 1px solid #cce5ff;
            padding: 8px 12px; border-radius: 6px; font-family: 'Consolas', monospace;
            font-size: 13px; cursor: pointer; transition: 0.2s; font-weight: 600;
        }
        .id-copy-badge:hover { background: #e2efff; }
    </style>
</head>
<body>

<div id="admin_wrapper">
    <?php 
    // 경로수정: 한 단계 위 aside.php 호출
    include_once('../aside.php'); 
    ?>

    <main class="content_area">
        <h2 class="t-fs-32 fw-900 u-mb-40">🌐 다국어 설정 관리</h2>

        <div class="tab_menu">
            <button type="button" class="tab_btn active" onclick="showTab('auto')">자동 번역 (Script)</button>
            <button type="button" class="tab_btn" onclick="showTab('manual')">수동 번역 (리스트)</button>
        </div>

        <form method="post" id="langForm" onsubmit="return preSave()">
            <input type="hidden" name="mode" value="update">
            <input type="hidden" name="translations_json" id="translations_json">

            <div id="tab_auto" class="tab_content active">
                <section class="card_custom">
                    <h3 class="t-fs-20 fw-800 u-mb-16">헤더 스크립트</h3>
                    <textarea name="auto_script" class="u-input u-px-16 u-py-12" style="height:250px; font-family:monospace; line-height:1.6;"><?=htmlspecialchars($config_data['auto_script'])?></textarea>
                </section>
            </div>

            <div id="tab_manual" class="tab_content">
                <section class="card_custom table-responsive">
                    <div class="g-cols-fit-12 justify-content-between align-items-center u-mb-24">
                        <h3 class="t-fs-20 fw-800">번역 매핑 데이터</h3>
                        <div class="d-flex u-gap-10">
                            <select id="lang_select" class="u-input u-select u-px-16 u-py-4" style="width:150px;" onchange="renderTable()">
                                <option value="en">영어 (EN)</option>
                                <option value="ja">일본어 (JA)</option>
                            </select>
                            <button type="button" onclick="addRow()" class="u-btn w-fit u-bg-main u-txt-white rounded-8 shadow-sm u-px-16 u-py-4">+ 항목 추가</button>
                        </div>
                    </div>

                    <div class="table_container table-responsive" style="border: 1px solid #eee; border-radius: 12px;">
                        <table style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #f8f9fa;">
                                    <th style="padding: 15px; text-align: left; width:25%;">기준 단어 (한국어)</th>
                                    <th style="padding: 15px; text-align: left; width:40%;">번역 텍스트 (<span id="target_lang_label">EN</span>)</th>
                                    <th style="padding: 15px; text-align: left; width:25%;">고유 ID</th>
                                    <th style="padding: 15px; text-align: center; width:10%;">삭제</th>
                                </tr>
                            </thead>
                            <tbody id="translation_tbody"></tbody>
                        </table>
                    </div>
                </section>
            </div>

            <div class="u-mt-24 d-flex justify-content-end w-100">
                <button type="submit" class="u-bg-main u-txt-white u-btn u-px-40 u-py-12 rounded-8 fw-700 shadow-main">번역 설정 저장</button>
            </div>
        </form>
    </main>
</div>

<script>
let transData = <?=json_encode($initial_translations)?>;

function showTab(tab) {
    document.querySelectorAll('.tab_content, .tab_btn').forEach(el => el.classList.remove('active'));
    document.getElementById('tab_' + tab).classList.add('active');
    event.currentTarget.classList.add('active');
    if(tab === 'manual') renderTable();
}

function renderTable() {
    const lang = document.getElementById('lang_select').value;
    document.getElementById('target_lang_label').innerText = lang.toUpperCase();
    const tbody = document.getElementById('translation_tbody');
    tbody.innerHTML = '';

    const keys = Object.keys(transData);
    if(keys.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; padding:40px; color:#999;">저장된 번역 데이터가 없습니다.</td></tr>';
        return;
    }

    keys.forEach(key => {
        const tr = document.createElement('tr');
        tr.style.borderBottom = "1px solid #f5f5f5";
        tr.innerHTML = `
            <td style="padding:12px;"><input type="text" class="u-input u-px-12 u-py-8" style="width:100%" value="${transData[key].ko || ''}" onchange="updateObj('${key}', 'ko', this.value)"></td>
            <td style="padding:12px;"><input type="text" class="u-input u-px-12 u-py-8" style="width:100%" value="${transData[key][lang] || ''}" onchange="updateObj('${key}', '${lang}', this.value)"></td>
            <td style="padding:12px;"><div class="id-copy-badge" style="padding:8px; font-size:12px;" onclick="copyId('${key}')">${key} <span class="material-symbols-outlined" style="font-size:14px">content_copy</span></div></td>
            <td style="padding:12px; text-align:center;"><button type="button" onclick="deleteRow('${key}')" class="u-btn u-btn-sub u-py-8 u-px-12 rounded-4">삭제</button></td>
        `;
        tbody.appendChild(tr);
    });
}

function updateObj(key, field, val) { transData[key][field] = val; }

function addRow() {
    const newId = 'tr_' + Math.random().toString(36).substr(2, 9);
    transData[newId] = { ko: '', en: '', ja: '' };
    renderTable();
}

function deleteRow(key) {
    if(confirm('이 항목을 정말 삭제할까요?')) {
        delete transData[key];
        renderTable();
    }
}

function copyId(text) {
    navigator.clipboard.writeText(text).then(() => { alert('ID가 복사되었습니다.'); });
}

function preSave() {
    document.getElementById('translations_json').value = JSON.stringify(transData);
    return true;
}

window.onload = function() { renderTable(); };
</script>
</body>
</html>