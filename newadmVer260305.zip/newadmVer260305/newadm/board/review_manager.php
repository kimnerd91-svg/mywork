<?php
include_once('../_common.php');
include_once('../_auth_check.php');
include_once('/head_sub.php');

$review_table = 'dm_review';

// 테이블 자동 생성
$table_exists = sql_query("SHOW TABLES LIKE '{$review_table}'");
if (sql_num_rows($table_exists) == 0) {
    $create_sql = "
    CREATE TABLE `{$review_table}` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `category` varchar(50) DEFAULT NULL,
      `title` varchar(255) DEFAULT NULL,
      `content` text NOT NULL,
      `review_date` date DEFAULT NULL,
      `is_visible` tinyint(1) DEFAULT 1,
      `display_order` int(11) DEFAULT 0,
      `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      KEY `idx_visible_order` (`is_visible`, `display_order`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ";
    sql_query($create_sql, false);
    $table_created = true;
} else {
    // 기존 테이블에 title 컬럼 없으면 자동 추가
    $chk = sql_query("SHOW COLUMNS FROM `{$review_table}` LIKE 'title'");
    if (sql_num_rows($chk) == 0) {
        sql_query("ALTER TABLE `{$review_table}` ADD COLUMN `title` varchar(255) DEFAULT NULL AFTER `category`");
    }
}

// AJAX 처리
if (isset($_POST['action'])) {
    if ($_POST['action'] == 'delete') {
        $id = (int)$_POST['id'];
        sql_query("DELETE FROM {$review_table} WHERE id = {$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    if ($_POST['action'] == 'save' || $_POST['action'] == 'update') {
        $id       = isset($_POST['id']) ? (int)$_POST['id'] : 0;
        $category = sql_real_escape_string(trim($_POST['category']));
        $title    = sql_real_escape_string(trim($_POST['title'] ?? ''));

        $content = $_POST['content'];
        $content = str_replace('&quot;', '', $content);
        $content = str_replace('"', '', $content);
        $content = str_replace("\\", '', $content);
        $content = sql_real_escape_string($content);

        $review_date = sql_real_escape_string(trim($_POST['review_date']));
        $is_visible  = isset($_POST['is_visible']) ? 1 : 0;

        if ($id > 0) {
            $sql = "UPDATE {$review_table} SET category='{$category}', title='{$title}', content='{$content}', review_date='{$review_date}', is_visible={$is_visible} WHERE id={$id}";
        } else {
            $sql = "INSERT INTO {$review_table} (category, title, content, review_date, is_visible) VALUES ('{$category}', '{$title}', '{$content}', '{$review_date}', {$is_visible})";
        }
        sql_query($sql);
        echo json_encode(['success' => true]);
        exit;
    }

    if ($_POST['action'] == 'toggle_visible') {
        $id = (int)$_POST['id'];
        $is_visible = (int)$_POST['is_visible'];
        sql_query("UPDATE {$review_table} SET is_visible = {$is_visible} WHERE id = {$id}");
        echo json_encode(['success' => true]);
        exit;
    }
}

$sql = "SELECT * FROM {$review_table} ORDER BY display_order ASC, id DESC";
$result = sql_query($sql);
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>환자 리뷰 관리</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/newadmin.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.1/classic/ckeditor.js"></script>
    <style>
        .review-table {
            width: 100%;
            border-collapse: collapse;
        }

        .review-table thead {
            background: var(--gray-100);
        }

        .review-table th {
            padding: var(--sp-16);
            font-weight: 700;
            text-align: left;
            border-bottom: 2px solid var(--gray-300);
        }

        .review-table td {
            padding: var(--sp-20);
            border-bottom: 1px solid var(--bg-soft);
            vertical-align: middle;
        }

        .review-table tbody tr {
            cursor: pointer;
            transition: all 0.2s;
        }

        .review-table tbody tr:hover {
            background: var(--bg-soft);
        }

        .rating-stars {
            display: flex;
            gap: var(--sp-4);
            font-size: 18px;
            color: var(--accent-color);
        }

        .rating-stars .empty {
            color: var(--gray-300);
        }

        .review-preview {
            max-width: 400px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: var(--c-color);
        }

        .avatar-preview {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: var(--white);
            font-weight: 700;
            font-size: 16px;
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 24px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--gray-400);
            transition: .4s;
            border-radius: 24px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: var(--white);
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.slider {
            background-color: var(--main-color);
        }

        input:checked+.slider:before {
            transform: translateX(26px);
        }

        .modal {
            display: none;
            position: fixed;
            z-index: var(--z-modal);
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: var(--white);
            margin: 3% auto;
            padding: 0;
            border-radius: 20px;
            width: 94%;
            max-width: 900px;
            max-height: 92vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .modal-body {
            padding: 32px;
            overflow-y: auto;
            flex: 1;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 24px 32px;
            border-bottom: 1px solid var(--gray-200);
            flex-shrink: 0;
        }

        .close {
            color: var(--gray-500);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            color: var(--black);
        }

        .btn-delete {
            background: none;
            color: #dc3545;
            border: 1px solid #dc3545;
            padding: var(--sp-8) var(--sp-16);
            font-size: 13px;
            border-radius: var(--sp-4);
            cursor: pointer;
        }

        .alert-success {
            padding: var(--sp-16);
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: var(--sp-8);
            margin-bottom: var(--sp-20);
        }

        .star-input {
            display: flex;
            gap: var(--sp-8);
            font-size: 32px;
        }

        .star-input span {
            cursor: pointer;
            color: var(--gray-300);
            transition: color 0.2s;
        }

        .star-input span.active,
        .star-input span:hover {
            color: var(--accent-color);
        }

        .color-picker-wrapper {
            display: grid;
            grid-template-columns: repeat(6, 1fr);
            gap: var(--sp-8);
        }

        .color-option {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.2s;
        }

        .color-option:hover {
            transform: scale(1.1);
        }

        .color-option.selected {
            border-color: var(--main-color);
            box-shadow: 0 0 0 2px var(--white), 0 0 0 4px var(--main-color);
        }

        .g-cols-fit-12 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: var(--sp-16);
        }

        .text-center {
            text-align: center;
        }

        .align-center {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-footer {
            display: flex;
            gap: 10px;
            padding: 20px 32px;
            border-top: 1px solid var(--gray-200);
            flex-shrink: 0;
        }
        .modal-footer .u-btn {
            flex: 1;
        }
        .ck-editor__editable {
            min-height: 420px !important;
        }
    </style>
</head>

<body>
    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>
        <main class="content_area">
            <?php if (isset($table_created)): ?>
                <div class="alert-success"><strong>✔ 리뷰 테이블이 생성되었습니다!</strong></div>
            <?php endif; ?>
            <div class="align-center u-mb-32">
                <h2 class="admin-card-title">💬 환자 리뷰 관리</h2>
                <button onclick="openModal()" class="u-btn rounded-8 u-btn-main">+ 리뷰 추가</button>
            </div>
            <section class="card_custom">
                <table class="review-table">
                    <thead>
                        <tr>
                            <th style="width:70px">노출</th>
                            <th style="width:120px">카테고리</th>
                            <th style="width:200px">제목</th>
                            <th>리뷰 내용</th>
                            <th style="width:110px">작성일</th>
                            <th style="width:80px">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 0;
                        while ($review = sql_fetch_array($result)):
                            $i++;
                        ?>
                            <tr onclick="editReview(<?= $review['id'] ?>)">
                                <td onclick="event.stopPropagation();">
                                    <label class="switch"><input type="checkbox" <?= $review['is_visible'] ? 'checked' : '' ?> onchange="toggleVisible(<?= $review['id'] ?>, this.checked)"><span class="slider"></span></label>
                                </td>
                                <td><?php if ($review['category']): ?><span class="badge badge-blue"><?= htmlspecialchars($review['category']) ?></span><?php endif; ?></td>
                                <td><strong><?= htmlspecialchars($review['title'] ?? '') ?></strong></td>
                                <td>
                                    <div class="review-preview"><?= strip_tags($review['content']) ?></div>
                                </td>
                                <td><?= $review['review_date'] ?></td>
                                <td onclick="event.stopPropagation();"><button class="btn-delete" onclick="deleteReview(<?= $review['id'] ?>)">삭제</button></td>
                            </tr>
                        <?php endwhile; ?>
                        <?php if ($i == 0): ?><tr>
                                <td colspan="6" class="text-center u-py-40 u-txt-muted">등록된 리뷰가 없습니다.</td>
                            </tr><?php endif; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <div id="reviewModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle" class="t-fs-24 fw-700">리뷰 추가</h2>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <form id="reviewForm">
                <input type="hidden" id="reviewId" name="id">
                <div class="modal-body">

                    <!-- 노출 여부 (최상단) -->
                    <div class="u-input-group" style="display:flex; align-items:center; gap:12px; margin-bottom:20px; padding:14px 18px; background:var(--bg-soft); border-radius:10px;">
                        <label class="u-label" style="margin:0; font-size:14px; font-weight:700;">노출 여부</label>
                        <label class="switch" style="vertical-align:middle;">
                            <input type="checkbox" id="isVisible" name="is_visible" checked>
                            <span class="slider"></span>
                        </label>
                    </div>

                    <!-- 카테고리 + 작성일 -->
                    <div class="g-cols-fit-12" style="margin-bottom:20px;">
                        <div class="u-input-group" style="margin:0;">
                            <label class="u-label" for="category">시술 카테고리</label>
                            <select id="category" name="category" class="u-input u-select">
                                <option value="">선택</option>
                                <option value="임플란트">임플란트</option>
                                <option value="심미치료">심미치료</option>
                                <option value="자연치아 살리기">자연치아 살리기</option>
                                <option value="기타">기타</option>
                            </select>
                        </div>
                        <div class="u-input-group" style="margin:0;">
                            <label class="u-label" for="reviewDate">작성일</label>
                            <input type="date" id="reviewDate" name="review_date" class="u-input" value="<?= date('Y-m-d') ?>">
                        </div>
                    </div>

                    <!-- 제목 -->
                    <div class="u-input-group" style="margin-bottom:20px;">
                        <label class="u-label" for="title">제목 *</label>
                        <input type="text" id="title" name="title" class="u-input" placeholder="리뷰 제목을 입력해주세요" required>
                    </div>

                    <!-- 내용 -->
                    <div class="u-input-group" style="margin:0;">
                        <label class="u-label" for="content">리뷰 내용 *</label>
                        <textarea id="content" name="content" class="u-input"></textarea>
                    </div>

                </div>
                <div class="modal-footer g-cols-fit-12 u-gap-8">
                    <button type="button" class="u-btn rounded-8 u-btn-gray w-100" onclick="closeModal()">취소</button>
                    <button type="submit" class="u-btn rounded-8 u-btn-main w-100">저장</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let editor, editorReady = false;

        document.addEventListener('DOMContentLoaded', function() {
            ClassicEditor.create(document.querySelector('#content'), {
                language: 'ko',
                toolbar: ['bold', 'italic', '|', 'bulletedList', 'numberedList', '|', 'link', 'imageUpload', '|', 'undo', 'redo'],
                placeholder: '환자분의 솔직한 리뷰를 입력해주세요'
            })
            .then(newEditor => {
                editor = newEditor;
                editorReady = true;
                editor.plugins.get('FileRepository').createUploadAdapter = (loader) => {
                    return {
                        upload: () => {
                            return loader.file.then(file => {
                                return new Promise((resolve, reject) => {
                                    const formData = new FormData();
                                    formData.append('upload', file);
                                    fetch('/newadm/board/review_upload.php', { method: 'POST', body: formData })
                                        .then(response => response.text())
                                        .then(text => {
                                            const data = JSON.parse(text);
                                            if (data.url) {
                                                let url = data.url.replace(/^["']|["']$/g, '');
                                                resolve({ default: url });
                                            } else {
                                                reject(data.error.message);
                                            }
                                        })
                                        .catch(error => reject('업로드 실패: ' + error));
                                });
                            });
                        },
                        abort: () => {}
                    };
                };
            })
            .catch(error => console.error('CKEditor error:', error));
        });

        function openModal(id = null) {
            if (!editorReady) { alert('에디터 로딩 중...'); return; }
            const form = document.getElementById('reviewForm');
            form.reset();
            document.getElementById('reviewId').value = '';
            document.getElementById('isVisible').checked = true;
            document.getElementById('reviewDate').value = new Date().toISOString().split('T')[0];
            if (editor) editor.setData('');

            document.getElementById('modalTitle').textContent = id ? '리뷰 수정' : '리뷰 추가';
            if (id) loadReviewData(id);
            document.getElementById('reviewModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('reviewModal').style.display = 'none';
        }

        function editReview(id) { openModal(id); }

        function loadReviewData(id) {
            <?php
            sql_data_seek($result, 0);
            $reviews = [];
            while ($row = sql_fetch_array($result)) $reviews[$row['id']] = $row;
            echo "const reviews = " . json_encode($reviews) . ";";
            ?>
            const review = reviews[id];
            if (!review) return;
            document.getElementById('reviewId').value    = review.id;
            document.getElementById('category').value   = review.category || '';
            document.getElementById('title').value      = review.title || '';
            document.getElementById('reviewDate').value = review.review_date || '';
            document.getElementById('isVisible').checked = review.is_visible == 1;
            if (editor) editor.setData(review.content || '');
        }

        document.getElementById('reviewForm').addEventListener('submit', function(e) {
            e.preventDefault();
            if (!editorReady) { alert('에디터 준비 안됨'); return; }
            const editorContent = editor.getData();
            if (!editorContent.trim()) { alert('내용을 입력해주세요.'); return; }
            const formData = new FormData(this);
            formData.set('content', editorContent);
            formData.append('action', document.getElementById('reviewId').value ? 'update' : 'save');
            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => {
                    if (data.success) { closeModal(); location.reload(); }
                    else alert('저장 실패');
                })
                .catch(error => { alert('오류 발생'); console.error(error); });
        });

        function toggleVisible(id, isVisible) {
            const formData = new FormData();
            formData.append('action', 'toggle_visible');
            formData.append('id', id);
            formData.append('is_visible', isVisible ? 1 : 0);
            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => { if (!data.success) { alert('오류'); location.reload(); } });
        }

        function deleteReview(id) {
            if (!confirm('정말 삭제하시겠습니까?')) return;
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('id', id);
            fetch('', { method: 'POST', body: formData })
                .then(r => r.json())
                .then(data => { if (data.success) location.reload(); })
                .catch(error => console.error(error));
        }

        window.onclick = function(event) {
            if (event.target == document.getElementById('reviewModal')) closeModal();
        }
    </script>
</body>

</html>