<?php
// newadm/board/board_manager.php

include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once($_SERVER['DOCUMENT_ROOT'] . 'head_sub.php');

// 게시판 삭제 로직
if (isset($_GET['delete_bo'])) {
    $bo_table = sql_real_escape_string($_GET['delete_bo']);
    sql_query(" DROP TABLE IF EXISTS {$g5['write_prefix']}$bo_table ");
    sql_query(" DELETE FROM {$g5['board_table']} WHERE bo_table = '$bo_table' ");
    sql_query(" DELETE FROM {$g5['board_new_table']} WHERE bo_table = '$bo_table' ");
    alert_toast('게시판이 완전히 삭제되었습니다.', './board_manager.php');
}

// 생성된 게시판 목록 가져오기
$sql = " SELECT * FROM {$g5['board_table']} ORDER BY bo_table ASC ";
$result = sql_query($sql);
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>게시판 관리 - NEW ADM</title>

    
    <style>
        #admin_wrapper {
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        .content_area {
            background-color: var(--bg-soft);
            padding: var(--sp-40);
        }

        .card_custom {
            background: white;
            border-radius: var(--sp-24);
            padding: var(--sp-32);
            margin-bottom: var(--sp-24);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
        }

        .u-table {
            width: 100%;
            border-collapse: collapse;
        }

        .u-table th {
            text-align: left;
            padding: 15px;
            border-bottom: 2px solid var(--bg-soft);
            color: var(--gray-600);
        }

        .u-table td {
            padding: var(--sp-16);
            border-bottom: 1px solid var(--bg-soft);
        }
    </style>
</head>

<body>

    <div id="admin_wrapper">
        <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>
        <main class="content_area">
            <section class="card_custom g-cols-fit-1">
                <h3 class="t-fs-24 fw-800 u-mb-24">🆕 새 게시판 생성</h3>
                <form action="board_create_update.php" method="post" class="u-gap-16 align-items-end g-cols-fit-12">
                    <div style="flex:1">
                        <label class="c-fs-12 fw-700 u-txt-muted u-mb-8 d-block">테이블명 (영문/숫자만)</label>
                        <input type="text" name="bo_table" class="u-input" placeholder="예: notice, free" required>
                    </div>
                    <div style="flex:2">
                        <label class="c-fs-12 fw-700 u-txt-muted u-mb-8 d-block">게시판 제목 (한글 가능)</label>
                        <input type="text" name="bo_subject" class="u-input" placeholder="예: 공지사항, 자유게시판" required>
                    </div>
                    <button type="submit" class="u-bg-main u-txt-white u-btn u-px-32 u-py-10 rounded-8 fw-700 u-press shadow-main g-self-end">
                        생성하기
                    </button>
                </form>
            </section>

            <section class="card_custom g-cols-fit-1 table-responsive">
                <h3 class="t-fs-24 fw-800 u-mb-24">📋 관리중인 게시판</h3>
                <table class="u-table table-responsive" style="min-width: 300px">
                    <thead>
                        <tr>
                            <th>게시판 제목</th>
                            <th>테이블 ID</th>
                            <th style="text-align:center;">총 게시물</th>
                            <th style="text-align:right;">비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php for ($i = 0; $row = sql_fetch_array($result); $i++) {
                            $write_table = $g5['write_prefix'] . $row['bo_table'];

                            // 게시글 수 카운트 (수정)
                            $count_sql = "SELECT COUNT(*) as cnt FROM `$write_table` WHERE wr_is_comment = 0";
                            $count_result = sql_query($count_sql);

                            $total_count = 0;
                            if ($count_result && sql_num_rows($count_result) > 0) {
                                $count_row = sql_fetch_array($count_result);
                                $total_count = (int)$count_row['cnt'];
                            }
                        ?>
                            <tr>
                                <td class="fw-700 t-fs-18"><?= $row['bo_subject'] ?></td>
                                <td class="u-txt-muted"><code><?= $row['bo_table'] ?></code></td>
                                <td style="text-align:center;">
                                    <span class="u-txt-main px-8 py-4 rounded-8 fw-700 c-fs-12">
                                        <?= number_format($total_count) ?>
                                    </span>
                                </td>
                                <td style="text-align:right;">
                                    <div class="u-flex u-justify-end u-gap-8">
                                        <a href="./board_post_list.php?bo_table=<?= $row['bo_table'] ?>" class="u-btn u-btn-sm u-btn-main u-lift u-px-12 u-py-8 rounded-8">관리</a>
                                        <button onclick="if(confirm('이 게시판의 모든 데이터가 삭제됩니다...')) location.href='?delete_bo=<?= $row['bo_table'] ?>'" class="u-btn u-btn-sm u-btn-sub u-press u-px-12 u-py-8 rounded-8">삭제</button>
                                    </div>
                                </td>
                            </tr>
                        <?php }
                        if ($i == 0) echo "<tr><td colspan='4' class='text-center p-40 u-txt-muted'>생성된 게시판이 없습니다.</td></tr>"; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

</body>

</html>