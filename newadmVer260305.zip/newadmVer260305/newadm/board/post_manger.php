<?php
include_once('./_common.php');
include_once('./_auth_check.php'); 
// 썸네일 라이브러리 로드
if (file_exists(G5_LIB_PATH.'/thumbnail.lib.php')) {
    include_once(G5_LIB_PATH.'/thumbnail.lib.php');
}

// 1. 모든 게시판 목록을 가져와서 UNION 쿼리 생성
$sql_bo = " SELECT bo_table, bo_subject FROM {$g5['board_table']} ORDER BY bo_table ASC ";
$res_bo = sql_query($sql_bo);

$union_queries = array();
while($bo = sql_fetch_array($res_bo)) {
    $tmp_write_table = $g5['write_prefix'] . $bo['bo_table'];
    
    // 테이블 존재 여부 확인 후 쿼리 추가
    $check = sql_query(" SHOW TABLES LIKE '$tmp_write_table' ");
    if(sql_num_rows($check) > 0) {
        // 중요: bo_table을 고정값으로 선택하여 나중에 링크에서 사용
        $union_queries[] = " SELECT '{$bo['bo_table']}' as bo_table, '{$bo['bo_subject']}' as bo_subject, wr_id, wr_subject, wr_name, wr_datetime, wr_option FROM $tmp_write_table WHERE wr_is_comment = 0 ";
    }
}

$total_count = 0;
$result = null;

if(!empty($union_queries)) {
    $full_union_sql = implode(" UNION ALL ", $union_queries);
    
    // 전체 개수 파악
    $total_res = sql_fetch(" SELECT count(*) as cnt FROM ($full_union_sql) as t ");
    $total_count = (int)$total_res['cnt'];

    // 페이징 처리
    $rows = 12;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    if ($page < 1) $page = 1;
    $total_page  = ceil($total_count / $rows);
    $from_record = ($page - 1) * $rows;

    // 최신순 정렬 및 데이터 호출
    $sql = " SELECT * FROM ($full_union_sql) as t ORDER BY wr_datetime DESC LIMIT $from_record, $rows ";
    $result = sql_query($sql);
}
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>게시물 통합 관리 - NEW ADM</title>

    <style>
        #admin_wrapper { display: grid; grid-template-columns: 280px 1fr; min-height: 100vh; }
        .content_area { background-color: var(--bg-soft); padding: 40px; }
        .post_grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
        .post_card { background: #fff; border-radius: 20px; overflow: hidden; display: flex; flex-direction: column; height: 100%; box-shadow: 0 4px 15px rgba(0,0,0,0.05); transition: 0.2s; border:none; }
        .post_card:hover { transform: translateY(-5px); }
        .post_thumb_area { width: 100%; aspect-ratio: 16/9; overflow: hidden; background: #eee; }
        .post_thumb { width: 100%; height: 100%; object-fit: cover; border:none; }
        .post_body { padding: 24px; flex: 1; display: flex; flex-direction: column; }
        .dot-dot { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; height: 2.8em; line-height: 1.4; font-weight: 800; font-size: 18px; margin-bottom: 12px; color: #111; text-decoration: none; }
        .status_badge { padding: 4px 10px; background: var(--bg-soft); color: var(--main-color); border-radius: 8px; font-size: 12px; font-weight: 700; }
        .adm_paging { display: flex; justify-content: center; gap: 8px; margin-top: 40px; }
        .adm_paging a { padding: 8px 16px; border-radius: 10px; background: #fff; border: 1px solid #eee; text-decoration: none; color: #666; font-weight: 600; }
        .adm_paging a.active { background: var(--main-color); color: #fff; border-color: var(--main-color); }
    </style>
</head>
<body>

<div id="admin_wrapper">
    <?php include_once('./aside.php'); ?>

    <main class="content_area">
        <h2 class="t-fs-32 fw-900 u-mb-40">📝 게시물 통합 관리 <small class="t-fs-16 u-txt-muted fw-400">Total: <?=number_format($total_count)?></small></h2>

        <div class="post_grid">
            <?php
            if ($result) {
                for ($i=0; $row=sql_fetch_array($result); $i++) {
                    // 게시글 실제 이동 주소 생성
                    $post_url = G5_BBS_URL."/board.php?bo_table=".$row['bo_table']."&wr_id=".$row['wr_id'];
                    $edit_url = G5_BBS_URL."/write.php?w=u&bo_table=".$row['bo_table']."&wr_id=".$row['wr_id'];

                    // 썸네일 (에러 방지)
                    $img_src = 'https://via.placeholder.com/400x225/f8f9fa/adb5bd?text=No+Image';
                    if(function_exists('get_list_thumbnail')) {
                        $thumb = get_list_thumbnail($row['bo_table'], $row['wr_id'], 400, 225, false, true);
                        if(isset($thumb['src']) && $thumb['src']) $img_src = $thumb['src'];
                    }
            ?>
            <article class="post_card">
                <a href="<?=$post_url?>" target="_blank" class="post_thumb_area">
                    <img src="<?=$img_src?>" class="post_thumb">
                </a>
                <div class="post_body">
                    <div class="d-flex justify-content-between u-mb-10">
                        <span class="status_badge"><?=htmlspecialchars($row['bo_subject'])?></span>
                        <span class="c-fs-12 u-txt-muted"><?=substr($row['wr_datetime'], 2, 8)?></span>
                    </div>
                    
                    <a href="<?=$post_url?>" target="_blank" class="dot-dot">
                        <?=htmlspecialchars($row['wr_subject'])?>
                    </a>

                    <div class="d-flex g-v-center gap-8 u-mb-20">
                        <span class="material-symbols-outlined t-fs-16 u-txt-muted">person</span>
                        <span class="c-fs-14 fw-600"><?=htmlspecialchars($row['wr_name'])?></span>
                    </div>

                    <div class="d-flex gap-8 u-mt-auto">
                        <a href="<?=$post_url?>" target="_blank" class="bd-1 u-bc-gray-200 u-txt-title flex-grow-1 text-center py-10 rounded-12 c-fs-14 fw-700" style="text-decoration:none;">보기</a>
                        <a href="<?=$edit_url?>" class="bd-1 u-bc-gray-200 u-txt-title flex-grow-1 text-center py-10 rounded-12 c-fs-14 fw-700" style="text-decoration:none;">수정</a>
                        <button onclick="delete_post('<?=$row['bo_table']?>', '<?=$row['wr_id']?>')" class="u-bg-soft u-txt-accent px-12 py-10 rounded-12 border-none u-press">
                            <span class="material-symbols-outlined">delete</span>
                        </button>
                    </div>
                </div>
            </article>
            <?php 
                }
            } 
            ?>
        </div>

        <?php if($total_count == 0) { ?>
            <div class="u-bg-white p-80 text-center rounded-24 shadow-soft">
                <p class="u-txt-muted fw-700 t-fs-18">데이터가 없습니다.</p>
            </div>
        <?php } ?>

        <div class="adm_paging">
            <?php for($p=1; $p<=$total_page; $p++) { ?>
                <a href="?page=<?=$p?>" class="<?=($p==$page)?'active':''?>"><?=$p?></a>
            <?php } ?>
        </div>
    </main>
</div>

<script>
function delete_post(bo_table, wr_id) {
    if(confirm("정말 이 게시물을 삭제하시겠습니까?")) {
        // bbs/delete.php 대신 현재 파일(상단에 삭제 로직이 있는)로 전달
        location.href = "./board_list.php?bo_table=" + bo_table + "&delete_wr_id=" + wr_id;
    }
}
</script>

</body>
</html>