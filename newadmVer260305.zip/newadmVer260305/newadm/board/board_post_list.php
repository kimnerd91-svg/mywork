<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once(G5_LIB_PATH . '/thumbnail.lib.php');

// 카테고리 추가 처리
if (isset($_POST['add_category']) && $_POST['bo_table'] && $is_admin) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_POST['bo_table']);
    $category_name = trim($_POST['category_name']);
    
    if ($category_name) {
        $category_table = $g5['write_prefix'] . $bo_table . '_category';
        
        // 카테고리 테이블이 없으면 생성
        sql_query("
            CREATE TABLE IF NOT EXISTS `{$category_table}` (
                `ca_id` int(11) NOT NULL AUTO_INCREMENT,
                `ca_name` varchar(255) NOT NULL,
                `ca_order` int(11) DEFAULT 0,
                `ca_datetime` datetime NOT NULL,
                PRIMARY KEY (`ca_id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ", false);
        
        sql_query("INSERT INTO {$category_table} (ca_name, ca_order, ca_datetime) VALUES ('$category_name', 0, NOW())");
        alert_toast('카테고리가 추가되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

// 카테고리 삭제 처리
if (isset($_GET['delete_category']) && $_GET['bo_table'] && $is_admin) {
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
    $ca_id = (int)$_GET['delete_category'];
    $category_table = $g5['write_prefix'] . $bo_table . '_category';
    
    sql_query("DELETE FROM {$category_table} WHERE ca_id = '$ca_id'");
    alert_toast('카테고리가 삭제되었습니다.', "./board_post_list.php?bo_table=$bo_table");
    exit;
}

// 게시글 삭제 처리
if (isset($_GET['delete_wr_id']) && $_GET['bo_table']) {
    $delete_wr_id = (int)$_GET['delete_wr_id'];
    $bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);

    if ($is_admin) {
        $write_table = $g5['write_prefix'] . $bo_table;
        sql_query(" DELETE FROM $write_table WHERE wr_id = '$delete_wr_id' ");
        sql_query(" DELETE FROM {$g5['board_new_table']} WHERE bo_table = '$bo_table' AND wr_id = '$delete_wr_id' ");
        sql_query(" DELETE FROM {$g5['board_file_table']} WHERE bo_table = '$bo_table' AND wr_id = '$delete_wr_id' ");
        alert_toast('삭제가 완료되었습니다.', "./board_post_list.php?bo_table=$bo_table");
        exit;
    }
}

$bo_table = preg_replace('/[^a-z0-9_]/i', '', $_GET['bo_table']);
$board = sql_fetch(" SELECT * FROM {$g5['board_table']} WHERE bo_table = '$bo_table' ");
if (!$board['bo_table']) alert_toast('게시판이 없습니다.');

// 카테고리 테이블 존재 여부 및 목록 가져오기
$category_table = $g5['write_prefix'] . $bo_table . '_category';
$categories = [];
$has_category_table = false;

// 테이블 존재 확인
$table_check = sql_query("SHOW TABLES LIKE '{$category_table}'", false);
if ($table_check && sql_num_rows($table_check) > 0) {
    $has_category_table = true;
    $category_result = sql_query("SELECT * FROM {$category_table} ORDER BY ca_order ASC, ca_id ASC", false);
    if ($category_result) {
        while ($cat = sql_fetch_array($category_result)) {
            $categories[] = $cat;
        }
    }
}

// 선택된 카테고리
$selected_category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// 게시글 목록 가져오기
$write_table = $g5['write_prefix'] . $bo_table;
$where = " WHERE wr_is_comment = 0 ";
if ($selected_category > 0) {
    $where .= " AND wr_10 = '$selected_category' ";
}
$result = sql_query(" SELECT * FROM $write_table $where ORDER BY wr_id DESC LIMIT 0, 12 ");
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">

    <style>
        .category_tab { padding: 10px 20px; background: #f1f3f5; border: 2px solid transparent; color: #495057; transition: all 0.2s; }
        .category_tab:hover { background: #e9ecef; border-color: #dee2e6; }
        .category_tab.active { background: #228be6; color: white; border-color: #228be6; }
        .category_tab .del_cat_btn { width: 18px; height: 18px; background: rgba(255,255,255,0.3); transition: all 0.2s; }
        .category_tab .del_cat_btn:hover { background: rgba(255,0,0,0.8); transform: scale(1.1); }
        .add_category_form input:focus { outline: none; border-color: #228be6; }
        .add_category_form button:hover { background: #1c7ed6; transform: translateY(-1px); }
        .thumb_box { aspect-ratio: 16/9; background: #eee; }
        .del_btn { position: absolute; top: 10px; right: 10px; width: 32px; height: 32px; background: rgba(255,0,0,0.8); z-index: 10; transition: all 0.2s; }
        .del_btn:hover { background: rgba(200,0,0,1); transform: scale(1.1); }
    </style>
</head>

<body>

    <div id="admin_wrapper">
        <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

        <main class="content_area">
            <div class="d-flex justify-content-between align-items-start">
                <h2 class="u-mb-40 fw-900 t-fs-32">📂 <?= $board['bo_subject'] ?> 목록</h2>
                <a href="<?= G5_URL ?>/newadm/board/write_direct.php?mode=write&bo_table=<?= $bo_table ?>"
                    target="_blank"
                    class="u-py-8 u-btn-main bd-1 text-center py-10 rounded-8 decoration-none u-txt-title fw-700 col-xl-1 col-sm-2">
                    새 글쓰기
                </a>
            </div>

            <!-- 카테고리 섹션 -->
            <div class="u-bg-white u-p-24 rounded-12 u-mb-32 shadow-soft">
                <h3 class="c-fs-18 fw-700 u-mb-16 u-txt-title">📑 카테고리 관리</h3>
                
                <div class="d-flex u-gap-8" style="flex-wrap: wrap; margin-bottom: 16px;">
                    <a href="?bo_table=<?= $bo_table ?>" class="category_tab rounded-8 decoration-none fw-600 d-flex align-items-center u-gap-8 <?= $selected_category == 0 ? 'active' : '' ?>">
                        전체보기
                    </a>
                    <?php foreach ($categories as $cat): ?>
                        <a href="?bo_table=<?= $bo_table ?>&category=<?= $cat['ca_id'] ?>" 
                           class="category_tab rounded-8 decoration-none fw-600 d-flex align-items-center u-gap-8 <?= $selected_category == $cat['ca_id'] ? 'active' : '' ?>">
                            <?= htmlspecialchars($cat['ca_name']) ?>
                            <span class="del_cat_btn rounded-full d-flex align-items-center justify-content-center cursor-pointer" onclick="event.preventDefault(); delete_category(<?= $cat['ca_id'] ?>);">
                                <span class="material-symbols-outlined" style="font-size:14px">close</span>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>

                <form method="post" class="add_category_form d-flex u-gap-8 u-pt-16 u-bd-t-1 u-bc-gray-200">
                    <input type="hidden" name="bo_table" value="<?= $bo_table ?>">
                    <input type="text" name="category_name" placeholder="새 카테고리 이름을 입력하세요" required class="flex-grow-1 u-px-16 u-py-10 u-bd-2 u-bc-gray-300 rounded-8 c-fs-14">
                    <button type="submit" name="add_category" class="u-px-24 u-py-10 u-bg-main u-txt-white u-bd-n rounded-8 fw-700 cursor-pointer">+ 카테고리 추가</button>
                </form>
            </div>

            <div class="post_grid d-grid g-cols-fill-4 u-gap-8">
                <?php
                while ($row = sql_fetch_array($result)) {
                    $img = "";
                    $content = stripslashes($row['wr_content']);
                    preg_match("/<img[^>]*src=[\"']?([^>\"' ]+)[\"']?[^>]*>/i", $content, $m);
                    $tmp_img = $m[1] ?? "";

                    if ($tmp_img) {
                        if (preg_match("/^(http|https):/i", $tmp_img)) {
                            $img = $tmp_img;
                        } else if (substr($tmp_img, 0, 1) == '/') {
                            $img = G5_URL . $tmp_img;
                        } else {
                            $img = G5_URL . '/' . $tmp_img;
                        }
                    }

                    if (!$img) {
                        $file = sql_fetch(" select bf_file from {$g5['board_file_table']} where bo_table = '$bo_table' and wr_id = '{$row['wr_id']}' and bf_type between 1 and 3 order by bf_no asc limit 1 ");
                        if (isset($file['bf_file']) && $file['bf_file']) {
                            $img = G5_DATA_URL . '/file/' . $bo_table . '/' . $file['bf_file'];
                        } else {
                            $img = 'https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg';
                        }
                    }

                    if (!$img) $img = "https://via.placeholder.com/400x225/eee/999?text=No+Image";
                ?>
                    <div class="post_card u-mb-16 rounded-8 shadow-soft u-bd-1 u-bc-gray-200">
                        <div class="thumb_box u-overflow-hidden position-relative">
                            <a href="javascript:void(0);" onclick="delete_post('<?= $row['wr_id'] ?>')" class="del_btn rounded-4 d-flex align-items-center justify-content-center cursor-pointer u-txt-white decoration-none" title="삭제">
                                <span class="material-symbols-outlined" style="font-size:20px">delete</span>
                            </a>
                            <img src="<?= $img ?>" alt="thumbnail" class="w-100 h-100 obj-cover">
                        </div>

                        <div class="u-p-20">
                            <?php
                            if ($has_category_table && !empty($row['wr_10'])) {
                                $cat = sql_fetch("SELECT ca_name FROM {$category_table} WHERE ca_id = '{$row['wr_10']}'", false);
                                if ($cat) {
                                    echo '<span class="u-display-inline-block u-px-12 u-py-4 u-bg-main op-1 rounded-full c-fs-12 fw-600 u-mb-8" style="background:#e7f5ff!important;color:#1971c2!important">' . htmlspecialchars($cat['ca_name']) . '</span>';
                                }
                            }
                            ?>
                            <h4 class="u-mb-10 fw-800 c-fs-18 u-lh-1 u-txt-title">
                                <?= cut_str(strip_tags($row['wr_subject']), 40) ?>
                            </h4>
                            <p class="u-txt-muted c-fs-14 u-mb-20"><?= $row['wr_name'] ?> · <?= substr($row['wr_datetime'], 0, 10) ?></p>
                            <div class="d-flex u-gap-8">
                                <a href="<?= G5_URL ?>/view_direct.php?bo_table=<?= $bo_table ?>&wr_id=<?= $row['wr_id'] ?>" target="_blank" class="u-btn u-btn-main flex-grow-1 text-center rounded-4 decoration-none fw-700">보기</a>
                                <a href="<?= G5_URL ?>/newadm/board/write_direct.php?mode=modify&bo_table=<?= $bo_table ?>&wr_id=<?= $row['wr_id'] ?>" target="_blank" class="u-btn u-btn-gray flex-grow-1 text-center rounded-4 decoration-none fw-700">수정</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </main>
    </div>
    
    <script>
        function delete_post(wr_id) {
            if (confirm('정말 이 게시글을 삭제하시겠습니까?\n삭제된 데이터는 복구할 수 없습니다.')) {
                location.href = "?bo_table=<?= $bo_table ?>&delete_wr_id=" + wr_id;
            }
        }

        function delete_category(ca_id) {
            if (confirm('이 카테고리를 삭제하시겠습니까?\n카테고리만 삭제되며 게시글은 유지됩니다.')) {
                location.href = "?bo_table=<?= $bo_table ?>&delete_category=" + ca_id;
            }
        }
    </script>
</body>

</html>