<?php
// inquiry_manager.php 
// 상단 PHP 로직은 그대로 유지하세요.
include_once('../_common.php');
include_once('../_auth_check.php');

$bo_table = "qa"; 
$write_table = $g5['write_prefix'] . $bo_table;

// 삭제 로직 동일...
if (isset($_GET['del_id'])) {
    $wr_id = (int)$_GET['del_id'];
    sql_query(" DELETE FROM {$write_table} WHERE wr_id = '$wr_id' ");
    alert_toast('상담 내역이 삭제되었습니다.', './qa_manager.php');
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = " WHERE 1=1 ";
if ($search) {
    $s = sql_real_escape_string($search);
    $where .= " AND (wr_name LIKE '%$s%' OR wr_content LIKE '%$s%' OR wr_1 LIKE '%$s%') ";
}

$sql = " SELECT * FROM {$write_table} $where ORDER BY wr_datetime DESC LIMIT 0, 50 ";
$result = sql_query($sql);
$total_count = sql_num_rows($result);
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>상담 문의 관리 - NEW ADM</title>

    <style>
        #admin_wrapper { display: grid; grid-template-columns: 280px 1fr; min-height: 100vh; }
        .content_area { background-color: var(--bg-soft); padding: var(--sp-40); }
        .card_custom { background: white; border-radius: 24px; padding: var(--sp-32); box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03); }
        .cate-badge { background: var(--bg-soft); color: var(--main-color); padding: 4px 10px; border-radius: 6px; font-weight: 700; font-size: 12px; }
        .content-preview { color: var(--gray-600); font-size: 14px; max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        /* 수신동의 배지 스타일 */
        .agree-text { font-size: 11px; color: #666; background: #eee; padding: 2px 6px; border-radius: 4px; margin-top: 4px; display: inline-block; }
        .agree-text.on { color: #007bff; background: #e7f1ff; }
        
        /* 토스트 메시지 스타일 */
        .toast-message {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: #333;
            color: white;
            padding: 12px 24px;
            border-radius: 8px;
            z-index: 9999;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .toast-message.show {
            opacity: 1;
        }
    </style>
</head>
<body>

    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>

        <main class="content_area">
            <div class="g-cols-fit-12 justify-content-between align-items-center u-mb-32 ">
                <h2 class="t-fs-32 fw-900">📩 상담 문의 관리</h2>
                <form method="get" class="d-flex u-gap-12">
                    <input type="text" name="search" class="u-input u-p-4 rounded-8 w-fit" placeholder="이름, 연락처, 내용 검색..." style="width:300px;" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="u-btn u-bg-main u-txt-white u-px-24 rounded-4 fw-700 w-fit">검색</button>
                </form>
            </div>

            <section class="card_custom table-responsive">
                <div class="u-mb-20 d-flex justify-content-between align-items-center">
                    <div class="fw-700">전체 <span class="u-txt-main"><?= $total_count ?></span>건</div>
                </div>

                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fafafa; border-bottom: 1px solid #eee;">
                            <th class="u-px-20 u-py-12 c-fs-16 fw-600">분류</th>
                            <th class="u-px-20 u-py-12 c-fs-16 fw-600">문의자/연락처/수신동의</th>
                            <th class="u-px-20 u-py-12 c-fs-16 fw-600">문의 내용 (요약)</th>
                            <th class="u-px-20 u-py-12 c-fs-16 fw-600 text-center">문의일시</th>
                            <th class="u-px-20 u-py-12 c-fs-16 fw-600 text-center">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        for ($i = 0; $row = sql_fetch_array($result); $i++) {
                            $content_summary = mb_strimwidth(strip_tags($row['wr_content']), 0, 40, "...", "utf-8");
                            // [중요] 데이터를 안전하게 JSON으로 변환
                            $safe_data = htmlspecialchars(json_encode($row, JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8');
                        ?>
                            <tr style="border-bottom: 1px solid var(--bg-soft);">
                                <td class="u-px-20 u-py-20">
                                    <span class="cate-badge"><?= $row['ca_name'] ?></span>
                                </td>
                                <td class="u-px-20 u-py-20">
                                    <div class="fw-700"><?= $row['wr_name'] ?></div>
                                    <div class="u-txt-muted c-fs-13"><?= $row['wr_1'] ?></div>
                                    <span class="agree-text <?= $row['wr_2']?'on':'' ?>"><?= $row['wr_2'] ? $row['wr_2'] : '미동의' ?></span>
                                </td>
                                <td class="u-px-20 u-py-20">
                                    <div class="content-preview"><?= $content_summary ?></div>
                                </td>
                                <td class="u-px-20 u-py-20 text-center u-txt-muted c-fs-14">
                                    <?= substr($row['wr_datetime'], 0, 16) ?>
                                </td>
                                <td class="u-px-20 u-py-20 text-center">
                                    <div class="d-flex u-gap-8 justify-content-center">
                                        <button type="button" onclick='viewInquiry(<?= $safe_data ?>)' class="u-btn-main u-txt-white u-btn u-px-16 u-py-8 rounded-4 c-fs-14 fw-600">상세보기</button>
                                        <a href="?del_id=<?= $row['wr_id'] ?>" onclick="return confirm('정말 삭제하시겠습니까?');" class="u-btn-gray u-txt-accent u-btn u-px-16 u-py-8 rounded-4 c-fs-14 fw-700">삭제</a>
                                    </div>
                                </td>
                            </tr>
                        <?php }
                        if ($i == 0) echo "<tr><td colspan='5' class='u-py-40 text-center u-txt-muted'>문의 내역이 없습니다.</td></tr>"; ?>
                    </tbody>
                </table>
            </section>
        </main>
    </div>

    <div class="modal fade" id="viewModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 rounded-24 shadow-lg">
                <div class="modal-header u-p-32 border-0">
                    <h5 class="fw-800 t-fs-24">📋 문의 상세 내용</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body u-px-32 u-pb-40">
                    <div class="u-mb-20">
                        <label class="u-txt-muted c-fs-13 d-block u-mb-4">문의 분야 / 이름</label>
                        <div class="t-fs-18 fw-700"><span id="v_cate" class="u-txt-main"></span> <span id="v_name"></span>님</div>
                    </div>
                    <div class="u-mb-20">
                        <label class="u-txt-muted c-fs-13 d-block u-mb-4">연락처 및 수신동의</label>
                        <div class="t-fs-18 fw-700 u-txt-title" id="v_tel"></div>
                        <div id="v_agree" class="c-fs-12 u-mt-4 u-txt-muted fw-700"></div>
                    </div>
                    <div class="u-mb-24">
                        <label class="u-txt-muted c-fs-13 d-block u-mb-4">문의 내용</label>
                        <div class="u-bg-soft u-p-20 rounded-16 u-lh-160" id="v_content" style="white-space:pre-wrap; font-size:15px; min-height:100px;"></div>
                    </div>

                    <div class="d-flex flex-column u-gap-12">
                        <!-- 전화 버튼 (주석처리 - PC에서는 URL scheme 미지원) -->
                        <!-- 
                        <a href="" id="v_call" class="u-btn u-bg-main u-txt-white u-py-14 rounded-4 fw-700 shadow-main text-center text-decoration-none u-gap-4 w-100-md">
                            <span class="material-symbols-outlined u-mr-8" style="vertical-align: middle;">call</span> 전화 연결하기
                        </a>
                        -->

                        <div class="d-grid g-cols-2 u-gap-12">
                            <!-- SMS 버튼 - 클릭 시 전화번호 복사 (무료) -->
                            <button type="button" onclick="handleSmsClick()" id="v_sms_btn" class="u-btn u-bg-soft u-txt-title u-py-12 rounded-4 fw-700 u-bd-1 u-bc-gray-200 text-center u-gap-4 w-100-md">
                                <span class="material-symbols-outlined u-mr-8" style="vertical-align: middle;">sms</span> 문자메시지
                            </button>
                            
                            <!-- 카카오톡 버튼 - 클릭 시 전화번호 복사 (무료) -->
                            <button type="button" onclick="handleKakaoClick()" id="v_kakao_btn" class="u-btn u-py-12 rounded-4 fw-700 text-center u-gap-4 w-100-md" style="background-color:#FEE500; color:#3A1D1D;">
                                <span class="material-symbols-outlined u-mr-8" style="vertical-align: middle;">chat</span> 카톡 상담
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // ==========================================
        // 현재 문의 데이터를 저장할 전역 변수
        // ==========================================
        let currentInquiryData = null;

        // ==========================================
        // 토스트 메시지 표시 함수
        // ==========================================
        function showToast(message) {
            const toast = document.createElement('div');
            toast.className = 'toast-message';
            toast.textContent = message;
            document.body.appendChild(toast);
            
            // 애니메이션 효과
            setTimeout(() => toast.classList.add('show'), 10);
            
            // 2초 후 사라짐
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, 2000);
        }

        // ==========================================
        // SMS 버튼 클릭 핸들러 (무료 버전 - 전화번호 복사)
        // ==========================================
        function handleSmsClick() {
            if (!currentInquiryData) return;
            
            const phoneNumber = currentInquiryData.wr_1.replace(/[^0-9]/g, '');
            
            // 클립보드에 전화번호 복사
            navigator.clipboard.writeText(phoneNumber).then(() => {
                showToast('전화번호가 복사되었습니다.\n휴대폰으로 문자를 보내주세요.');
            }).catch(err => {
                alert_toast('복사 실패: ' + err);
            });
        }

        // ==========================================
        // 카카오톡 버튼 클릭 핸들러 (무료 버전 - 전화번호 복사)
        // ==========================================
        function handleKakaoClick() {
            if (!currentInquiryData) return;
            
            const phoneNumber = currentInquiryData.wr_1.replace(/[^0-9]/g, '');
            
            // 클립보드에 전화번호 복사
            navigator.clipboard.writeText(phoneNumber).then(() => {
                showToast('전화번호가 복사되었습니다.\n카카오톡에서 연락처를 검색해주세요.');
            }).catch(err => {
                alert_toast('복사 실패: ' + err);
            });
        }

        // ==========================================
        // SMS API 연동 함수 (유료 - 추후 사용 시 주석 해제)
        // 국내 SMS 서비스 예시: 네이버 클라우드, 알리고, 문자나라 등
        // 건당 약 8-20원 비용 발생
        // ==========================================
        /*
        async function handleSmsClickWithAPI() {
            if (!currentInquiryData) return;
            
            const phoneNumber = currentInquiryData.wr_1.replace(/[^0-9]/g, '');
            const name = currentInquiryData.wr_name;
            const category = currentInquiryData.ca_name;
            
            // 문자 내용 입력받기
            const message = prompt(`${name}님께 보낼 문자 내용을 입력하세요:`, 
                `[${category}] 안녕하세요. 문의하신 내용 확인하여 연락드렸습니다.`);
            
            if (!message) return;
            
            try {
                // SMS API 호출 (예시 - 실제 API 엔드포인트로 변경 필요)
                const response = await fetch('/api/send-sms.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        to: phoneNumber,
                        message: message,
                        from: '발신번호' // 사전에 등록된 발신번호
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('문자가 발송되었습니다.');
                } else {
                    alert('문자 발송 실패: ' + result.error);
                }
            } catch (error) {
                alert('문자 발송 중 오류가 발생했습니다: ' + error);
            }
        }
        */

        // ==========================================
        // 카카오톡 API 연동 함수 (유료 - 추후 사용 시 주석 해제)
        // 친구톡 API 사용: 건당 약 15-20원 비용 발생
        // 알림톡은 템플릿 사전 등록 필요 (건당 5-10원)
        // ==========================================
        /*
        async function handleKakaoClickWithAPI() {
            if (!currentInquiryData) return;
            
            const phoneNumber = currentInquiryData.wr_1.replace(/[^0-9]/g, '');
            const name = currentInquiryData.wr_name;
            const category = currentInquiryData.ca_name;
            
            // 카톡 내용 입력받기
            const message = prompt(`${name}님께 보낼 카카오톡 내용을 입력하세요:`, 
                `[${category}] 안녕하세요. 문의하신 내용 확인하여 연락드렸습니다.`);
            
            if (!message) return;
            
            try {
                // 카카오톡 친구톡 API 호출 (예시 - 실제 API 엔드포인트로 변경 필요)
                const response = await fetch('/api/send-kakao.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        to: phoneNumber,
                        message: message,
                        plusFriendId: '@카카오채널ID' // 사전에 등록된 카카오채널 ID
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    showToast('카카오톡이 발송되었습니다.');
                } else {
                    alert('카카오톡 발송 실패: ' + result.error);
                }
            } catch (error) {
                alert('카카오톡 발송 중 오류가 발생했습니다: ' + error);
            }
        }
        */

        // ==========================================
        // 상세보기 모달 표시 함수
        // ==========================================
        window.viewInquiry = function(data) {
            // 현재 데이터 저장
            currentInquiryData = data;
            
            // 1. 기본 텍스트 채우기
            document.getElementById('v_cate').innerText = "[" + (data.ca_name || '문의') + "]";
            document.getElementById('v_name').innerText = data.wr_name;
            document.getElementById('v_tel').innerText = data.wr_1;
            document.getElementById('v_content').innerText = data.wr_content;
            document.getElementById('v_agree').innerText = "수신동의 여부: " + (data.wr_2 ? data.wr_2 : "기록없음");

            // 2. 모달 띄우기
            const modalEl = document.getElementById('viewModal');
            const myModal = new bootstrap.Modal(modalEl);
            myModal.show();
        };
    </script>
</body>
</html>