<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include_once('../_common.php');

header('Content-Type: application/json');

$upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/data/review_images/';
$upload_url = '/data/review_images/';

if (!is_dir($upload_dir)) {
    @mkdir($upload_dir, 0755, true);
}

if (isset($_FILES['upload'])) {
    $file = $_FILES['upload'];
    
    $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp');
    $file_ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_ext, $allowed_ext)) {
        echo json_encode(['error' => ['message' => '허용되지 않은 파일 형식입니다.']]);
        exit;
    }
    
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['error' => ['message' => '파일 크기는 5MB 이하여야 합니다.']]);
        exit;
    }
    
    $file_name = date('YmdHis') . '_' . uniqid() . '.' . $file_ext;
    $file_path = $upload_dir . $file_name;
    
    if (move_uploaded_file($file['tmp_name'], $file_path)) {
        // 따옴표 없이 순수 URL만 반환
        $clean_url = $upload_url . $file_name;
        echo json_encode(['url' => $clean_url], JSON_UNESCAPED_SLASHES);
    } else {
        echo json_encode(['error' => ['message' => '파일 업로드에 실패했습니다.']]);
    }
} else {
    echo json_encode(['error' => ['message' => '파일이 전송되지 않았습니다.']]);
}
?>