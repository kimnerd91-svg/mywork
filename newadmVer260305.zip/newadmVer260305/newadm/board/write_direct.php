<?php
// 1. 공통 파일 로드
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_common.php');

// -------------------------------------------------------------------------
// [1] CKEditor 이미지 업로드 처리 (Ajax 요청 처리 후 종료)
// -------------------------------------------------------------------------
if (isset($_FILES['upload']['name'])) {
    while (ob_get_level()) ob_end_clean(); 
    
    $upload_dir = G5_DATA_PATH . '/editor/' . date('Ym');
    $upload_url = G5_DATA_URL . '/editor/' . date('Ym');

    if (!is_dir($upload_dir)) {
        @mkdir($upload_dir, G5_DIR_PERMISSION, true);
        @chmod($upload_dir, G5_DIR_PERMISSION);
    }

    $filename = $_FILES['upload']['name'];
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])) {
        die(json_encode(["uploaded" => 0, "error" => ["message" => "이미지만 업로드 가능합니다."]]));
    }

    $new_name = time() . '_' . md5($filename) . '.' . $ext;
    $dest_path = $upload_dir . '/' . $new_name;

    if (move_uploaded_file($_FILES['upload']['tmp_name'], $dest_path)) {
        header('Content-Type: application/json');
        echo json_encode([
            "uploaded" => 1,
            "fileName" => $new_name,
            "url" => $upload_url . '/' . $new_name
        ]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(["uploaded" => 0, "error" => ["message" => "파일 업로드 실패."]]);
    }
    exit;
}

// -------------------------------------------------------------------------
// [2] DB 저장 및 수정 처리 (Form Submit 처리)
// -------------------------------------------------------------------------
if (isset($_POST['wr_subject']) && !empty($_POST['wr_subject'])) {
    $bo_table = $_POST['bo_table'];
    $write_table = $g5['write_prefix'] . $bo_table;
    
    $wr_subject = sql_real_escape_string($_POST['wr_subject']);
    $wr_content = sql_real_escape_string($_POST['wr_content']);
    $category_id = isset($_POST['category_id']) ? (int)$_POST['category_id'] : 0;
    $wr_id      = (int)$_POST['wr_id'];
    $mode       = $_POST['mode'];

    if ($mode == 'modify' && $wr_id) {
        // 수정 모드
        $sql = " UPDATE $write_table 
                    SET wr_subject = '$wr_subject', 
                        wr_content = '$wr_content', 
                        wr_10      = '$category_id'
                  WHERE wr_id      = '$wr_id' ";
        sql_query($sql);
        
        // FAQ인 경우 faq_manager로 돌아가기
        if ($bo_table == 'faq') {
            alert_toast("성공적으로 수정되었습니다.", "/newadm/board/faq_manager.php", "success");
        } else {
            alert_toast("성공적으로 수정되었습니다.", "/newadm/board/board_post_list.php?bo_table=".$bo_table, "success");
        }
    } else {
        // 새 글 작성 모드
        $sql = " INSERT INTO $write_table 
                    SET wr_subject  = '$wr_subject', 
                        wr_content  = '$wr_content', 
                        wr_10       = '$category_id',
                        wr_datetime = '".G5_TIME_YMDHIS."', 
                        wr_option   = 'html1', 
                        wr_num      = '-1' ";
        sql_query($sql);
        
        // FAQ인 경우 faq_manager로 돌아가기
        if ($bo_table == 'faq') {
            alert_toast("저장되었습니다.", "/newadm/board/faq_manager.php", "success");
        } else {
            alert_toast("저장되었습니다.", "/newadm/board/board_post_list.php?bo_table=".$bo_table, "success");
        }
    }
    exit;
}

// -------------------------------------------------------------------------
// [3] 초기 설정 및 데이터 로드 (화면 출력 준비)
// -------------------------------------------------------------------------
include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/_auth_check.php');
include_once('./direct_config.php'); 

$mode = $_REQUEST['mode'] ?? 'write';
$wr_id = $_REQUEST['wr_id'] ?? '';
$bo_table = $_REQUEST['bo_table'] ?? '';

// 수정 모드일 때 기존 데이터 불러오기
if ($mode == 'modify' && $wr_id && $bo_table) {
    $write = sql_fetch(" select * from {$g5['write_prefix']}{$bo_table} where wr_id = '$wr_id' ");
}

// 게시판별 카테고리 목록 불러오기 (JavaScript에서 사용)
$board_categories = [];
foreach ($dm_boards as $table => $data) {
    $category_table = $g5['write_prefix'] . $table . '_category';
    
    // 테이블 존재 확인
    $table_check = sql_query("SHOW TABLES LIKE '{$category_table}'", false);
    if ($table_check && sql_num_rows($table_check) > 0) {
        $cat_result = sql_query("SELECT ca_id, ca_name FROM {$category_table} ORDER BY ca_order ASC, ca_id ASC", false);
        
        if ($cat_result) {
            $board_categories[$table] = [];
            while ($cat = sql_fetch_array($cat_result)) {
                $board_categories[$table][] = [
                    'id' => $cat['ca_id'],
                    'name' => $cat['ca_name']
                ];
            }
        }
    }
}

// 타이틀 설정
$title_prefix = '콘텐츠';
if ($bo_table == 'faq') {
    $title_prefix = 'FAQ';
}
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>콘텐츠 관리</title>

    <script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>


    <style>
        .ck-editor__editable { min-height: 500px !important; border-radius: 0 0 16px 16px !important; }
        .category_row { display: none !important; }
        .category_row.active { display: block !important; }
    </style>
</head>
<body>
<div class="admin_wrapper d-flex">
    <?php include_once($_SERVER['DOCUMENT_ROOT'] . '/newadm/aside.php'); ?>

    <div id="direct_write_wrap" class="u-py-40 u-bg-soft content_area">
        <div class="u-mx-auto u-p-40 u-bg-white rounded-16 shadow-soft" style="max-width: 1000px;">

            <div class="u-txt-center u-mb-40">
                <h2 class="t-fs-32 u-txt-title fw-800 u-mb-8">
                    <?php echo ($mode == 'modify') ? $title_prefix . ' 수정' : '새 ' . $title_prefix . ' 작성'; ?>
                </h2>
                <p class="c-fs-16 u-txt-muted">설정된 디자인 시스템 가이드라인에 맞춰 작성해 주세요.</p>
            </div>

            <form name="fwrite" id="fwrite" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" onsubmit="return submitForm();">
                <input type="hidden" name="mode" value="<?php echo $mode; ?>">
                <input type="hidden" name="wr_id" value="<?php echo $wr_id; ?>">

                <div class="g-cols-fit-3 u-gap-24 u-mb-24">
                    <div class="g-cols-fit-3 ">
                        <label class="c-fs-16 fw-700 u-txt-title u-mb-8 u-display-block">게시판 분류 <span class="u-txt-accent">*</span></label>
                        <select name="bo_table" id="bo_table" class="w-100 u-input u-select u-px-16 u-py-4 rounded-4 u-bc-gray-500 c-fs-14" required onchange="toggleCategory()" <?php echo ($mode == 'modify') ? 'disabled' : ''; ?>>
                            <option value="">게시판을 선택하세요</option>
                            <?php foreach ($dm_boards as $table => $data) { ?>
                                <option value="<?php echo $table; ?>" <?php echo ($bo_table == $table) ? 'selected' : ''; ?>>
                                    <?php echo $data['subject']; ?>
                                </option>
                            <?php } ?>
                        </select>
                        <?php if($mode == 'modify') { ?>
                            <input type="hidden" name="bo_table" value="<?php echo $bo_table; ?>">
                        <?php } ?>
                    </div>

                    <div class="g-cols-fit-3 category_row" id="category_row">
                        <label class="c-fs-16 fw-700 u-mb-8 u-display-block">카테고리</label>
                        <select name="category_id" id="category_id" class="w-100 u-input u-select u-px-16 u-py-4 rounded-4 u-bc-gray-500 c-fs-14">
                            <option value="">선택하세요</option>
                        </select>
                    </div>
                </div>

                <div class="u-mb-24 g-cols-fit-3 ">
                    <label class="c-fs-16 fw-700 u-txt-title u-mb-8 u-display-block">제목 <span class="u-txt-accent">*</span></label>
                    <input type="text" name="wr_subject" id="wr_subject" class="w-100 u-input u-px-16 u-py-4 rounded-4 u-bc-gray-500 c-fs-14" placeholder="제목을 입력하세요" required value="<?php echo htmlspecialchars($write['wr_subject'] ?? ''); ?>">
                </div>

                <div class="u-mb-16 g-cols-fit-3 ">
                    <label class="c-fs-16 fw-700 u-txt-title u-mb-8 u-display-block">상세 내용 <span class="u-txt-accent">*</span></label>
                    <div class="rounded-16 u-overflow-hidden bd-gray-200">
                        <div id="editor"><?php echo stripslashes($write['wr_content'] ?? ''); ?></div>
                    </div>
                    <textarea name="wr_content" id="wr_content" style="display:none;"></textarea>
                </div>

                <div class="d-flex justify-content-center u-gap-16">
                    <button type="button" onclick="goBack();" class="u-btn u-btn-gray flex-grow-1 u-px-16 u-py-4 rounded-4 u-press fw-700">취소</button>
                    <button type="submit" class="u-btn u-btn-main u-bc-main u-px-16 u-py-4 flex-grow-1 rounded-4 u-lift u-press fw-700">
                        <?php echo ($mode == 'modify') ? '수정 완료' : '작성 완료'; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    let editorInstance;
    const boardCategories = <?php echo json_encode($board_categories); ?>;
    const savedCategoryId = "<?php echo $write['wr_10'] ?? ''; ?>";
    const currentBoTable = "<?php echo $bo_table; ?>";

    ClassicEditor.create(document.querySelector('#editor'), {
        language: 'ko',
        ckfinder: {
            uploadUrl: '<?php echo $_SERVER['PHP_SELF']; ?>'
        },
        toolbar: ['heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'imageUpload', 'undo', 'redo']
    }).then(editor => {
        editorInstance = editor;
    });

    function toggleCategory() {
        const boTable = document.getElementById('bo_table').value;
        const categoryRow = document.getElementById('category_row');
        const categorySelect = document.getElementById('category_id');

        categorySelect.innerHTML = '<option value="">선택하세요</option>';
        categoryRow.classList.remove('active');

        // 해당 게시판에 카테고리가 존재하면 셀렉트 박스 표시
        if (boTable && boardCategories[boTable] && boardCategories[boTable].length > 0) {
            categoryRow.classList.add('active');
            
            boardCategories[boTable].forEach(cat => {
                let opt = document.createElement('option');
                opt.value = cat.id;
                opt.text = cat.name;
                if (opt.value == savedCategoryId) {
                    opt.selected = true;
                }
                categorySelect.appendChild(opt);
            });
        }
    }

    function submitForm() {
        if (!document.getElementById('bo_table').value) {
            alert_toast("게시판을 선택해 주세요.");
            return false;
        }
        
        document.getElementById('wr_content').value = editorInstance.getData();
        return true;
    }
    
    function goBack() {
        // FAQ에서 온 경우 faq_manager로, 아니면 history.back()
        if (currentBoTable === 'faq') {
            location.href = '/newadm/board/faq_manager.php';
        } else {
            history.back();
        }
    }
    
    window.onload = toggleCategory;
</script>
</body>
</html>