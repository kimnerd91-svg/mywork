<?php
include_once('../_common.php');
include_once('../_auth_check.php');

// ============================================================
// 테이블 자동 생성
// ============================================================
$chk = sql_query("SHOW TABLES LIKE 'dm_faq_group'");
if (sql_num_rows($chk) == 0) {
    sql_query("CREATE TABLE `dm_faq_group` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(255) NOT NULL,
        `description` varchar(500) NOT NULL DEFAULT '',
        `created_at` datetime NOT NULL DEFAULT NOW(),
        PRIMARY KEY (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}
$chk2 = sql_query("SHOW TABLES LIKE 'dm_faq_item'");
if (sql_num_rows($chk2) == 0) {
    sql_query("CREATE TABLE `dm_faq_item` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `group_id` int(11) NOT NULL,
        `question` varchar(500) NOT NULL,
        `answer` text NOT NULL,
        PRIMARY KEY (`id`),
        KEY `group_id` (`group_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4", false);
}

// ============================================================
// AJAX 처리
// ============================================================
if (isset($_POST['ajax_action'])) {
    header('Content-Type: application/json');
    $action = $_POST['ajax_action'];

    if ($action === 'save_group') {
        $id   = (int)($_POST['id'] ?? 0);
        $name = sql_real_escape_string(trim($_POST['name'] ?? ''));
        $desc = sql_real_escape_string(trim($_POST['description'] ?? ''));
        if (!$name) { echo json_encode(['success' => false, 'msg' => '그룹명을 입력하세요.']); exit; }
        if ($id) {
            sql_query("UPDATE dm_faq_group SET name='{$name}', description='{$desc}' WHERE id={$id}");
        } else {
            sql_query("INSERT INTO dm_faq_group (name, description) VALUES ('{$name}', '{$desc}')");
            $id = sql_insert_id();
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    if ($action === 'delete_group') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_faq_item WHERE group_id={$id}");
        sql_query("DELETE FROM dm_faq_group WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'save_item') {
        $id       = (int)($_POST['id'] ?? 0);
        $group_id = (int)($_POST['group_id'] ?? 0);
        $question = sql_real_escape_string(trim($_POST['question'] ?? ''));
        $answer   = sql_real_escape_string(trim($_POST['answer'] ?? ''));
        if (!$question) { echo json_encode(['success' => false, 'msg' => '질문을 입력하세요.']); exit; }
        if ($id) {
            sql_query("UPDATE dm_faq_item SET question='{$question}', answer='{$answer}' WHERE id={$id}");
        } else {
            sql_query("INSERT INTO dm_faq_item (group_id, question, answer) VALUES ({$group_id}, '{$question}', '{$answer}')");
            $id = sql_insert_id();
        }
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    if ($action === 'delete_item') {
        $id = (int)($_POST['id'] ?? 0);
        sql_query("DELETE FROM dm_faq_item WHERE id={$id}");
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'get_items') {
        $group_id = (int)($_POST['group_id'] ?? 0);
        $result   = sql_query("SELECT * FROM dm_faq_item WHERE group_id={$group_id} ORDER BY id ASC");
        $items = [];
        while ($row = sql_fetch_array($result)) $items[] = $row;
        echo json_encode(['success' => true, 'items' => $items]);
        exit;
    }

    echo json_encode(['success' => false, 'msg' => 'unknown action']);
    exit;
}

// ============================================================
// 그룹 목록
// ============================================================
$groups = [];
$result = sql_query("SELECT g.*, (SELECT COUNT(*) FROM dm_faq_item WHERE group_id = g.id) as item_count FROM dm_faq_group g ORDER BY g.id ASC");
while ($row = sql_fetch_array($result)) $groups[] = $row;
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<title>FAQ 관리</title>
<style>
    .faq-group-row { border: 1px solid var(--gray-200); border-radius: 12px; background: #fff; margin-bottom: 16px; overflow: hidden; }
    .faq-group-header { display: flex; align-items: center; gap: 16px; padding: 20px 24px; cursor: pointer; user-select: none; }
    .faq-group-header:hover { background: var(--bg-soft); }
    .group-id-badge { background: var(--main-color); color: #fff; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .group-count-badge { background: var(--bg-soft); color: var(--main-color); padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .faq-items-area { border-top: 1px solid var(--gray-200); display: none; }
    .faq-item-row { display: flex; align-items: flex-start; gap: 12px; padding: 16px 24px; border-bottom: 1px solid var(--bg-soft); }
    .faq-item-row:last-child { border-bottom: none; }
    .faq-item-row .q-text { font-weight: 600; color: var(--txt-dark); }
    .faq-item-row .a-text { color: var(--txt-gray-600); font-size: 14px; margin-top: 4px; white-space: pre-wrap; }
    .add-item-row { padding: 16px 24px; background: var(--bg-soft); }
    .chevron { transition: transform 0.2s; font-size: 20px; pointer-events: none; }
    .chevron.open { transform: rotate(180deg); }
    .copy-id-btn { font-size: 11px; padding: 2px 8px; background: rgba(255,255,255,0.3); border: none; border-radius: 4px; cursor: pointer; color: #fff; margin-left: 4px; }
    .copy-id-btn:hover { background: rgba(255,255,255,0.5); }
    textarea.u-input { resize: vertical; min-height: 80px; }
    .header-actions { display: flex; gap: 8px; position: relative; z-index: 2; }
</style>
</head>
<body>
<div id="admin_wrapper">
    <?php include_once('../aside.php'); ?>

    <main class="content_area u-pb-60">
        <div class="g-cols-fit-12 justify-content-between align-items-center u-mb-32">
            <h2 class="t-fs-32 fw-900">❓ FAQ 관리</h2>
            <button type="button" class="u-btn u-bg-main u-txt-white u-px-24 u-py-12 rounded-4 fw-700 g-self-end"
                onclick="openGroupModal()">+ FAQ 그룹 추가</button>
        </div>

        <div class="card_custom u-mb-24" style="background: #f0f7ff; border: 1px solid #cce0ff;">
            <p class="c-fs-14 u-txt-muted u-mb-4">📌 <strong>프론트에서 호출하는 방법</strong> — 아래 그룹 ID를 사용하세요</p>
            <code class="c-fs-13" style="color: var(--main-color);">
                $faq_result = sql_query("SELECT * FROM dm_faq_item WHERE group_id = <strong>그룹ID</strong> ORDER BY id ASC");
            </code>
        </div>

        <?php if (empty($groups)): ?>
        <div class="card_custom text-center u-py-60 u-txt-muted c-fs-18">등록된 FAQ 그룹이 없습니다.</div>
        <?php else: ?>
        <?php foreach ($groups as $g): ?>
        <div class="faq-group-row" id="group-row-<?= $g['id'] ?>">
            <div class="faq-group-header" onclick="toggleGroup(<?= $g['id'] ?>, event)">
                <span class="group-id-badge">
                    ID: <?= $g['id'] ?>
                    <button class="copy-id-btn" onclick="event.stopPropagation(); copyId(<?= $g['id'] ?>)">복사</button>
                </span>
                <div class="flex-fill">
                    <div class="fw-700 t-fs-18"><?= htmlspecialchars($g['name']) ?></div>
                    <?php if ($g['description']): ?>
                    <div class="c-fs-14 u-txt-muted u-mt-4"><?= htmlspecialchars($g['description']) ?></div>
                    <?php endif; ?>
                </div>
                <span class="group-count-badge">Q&A <?= $g['item_count'] ?>개</span>
                <div class="header-actions" onclick="event.stopPropagation()">
                    <button type="button" class="u-btn u-bg-soft u-txt-title u-px-16 u-py-8 rounded-4 c-fs-14 fw-600"
                        onclick="openGroupModal(<?= htmlspecialchars(json_encode($g), ENT_QUOTES) ?>)">수정</button>
                    <button type="button" class="u-btn u-txt-accent u-px-16 u-py-8 rounded-4 c-fs-14 fw-700"
                        style="background:#fff5f5; border: 1px solid #fcc;"
                        onclick="deleteGroup(<?= $g['id'] ?>, '<?= htmlspecialchars($g['name'], ENT_QUOTES) ?>')">삭제</button>
                </div>
                <span class="material-symbols-outlined chevron" id="chevron-<?= $g['id'] ?>">expand_more</span>
            </div>

            <div class="faq-items-area" id="items-area-<?= $g['id'] ?>">
                <div id="items-list-<?= $g['id'] ?>"></div>
                <div class="add-item-row">
                    <button type="button" class="u-btn u-bg-main u-txt-white u-px-20 u-py-10 rounded-4 fw-700 c-fs-14"
                        onclick="openItemModal(<?= $g['id'] ?>)">+ 질문 추가</button>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </main>
</div>

<!-- 그룹 모달 -->
<div class="modal fade" id="groupModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24">
                <h5 class="modal-title fw-700 t-fs-20" id="groupModalTitle">FAQ 그룹 추가</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-32">
                <input type="hidden" id="groupId" value="0">
                <div class="u-mb-20">
                    <label class="fw-700 d-block u-mb-8">그룹명 <span class="u-txt-accent">*</span></label>
                    <input type="text" id="groupName" class="u-input u-px-12 u-py-10 w-100" placeholder="예: 임플란트 FAQ">
                </div>
                <div>
                    <label class="fw-700 d-block u-mb-8">설명</label>
                    <input type="text" id="groupDesc" class="u-input u-px-12 u-py-10 w-100" placeholder="간단한 설명 (선택)">
                </div>
            </div>
            <div class="modal-footer u-p-24 border-0">
                <button type="button" class="u-btn u-bg-soft u-txt-title u-px-24 u-py-12 rounded-8 fw-700" data-bs-dismiss="modal">취소</button>
                <button type="button" class="u-btn u-bg-main u-txt-white u-px-24 u-py-12 rounded-8 fw-700" onclick="saveGroup()">저장</button>
            </div>
        </div>
    </div>
</div>

<!-- 아이템 모달 -->
<div class="modal fade" id="itemModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24">
                <h5 class="modal-title fw-700 t-fs-20" id="itemModalTitle">질문 추가</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-32">
                <input type="hidden" id="itemId" value="0">
                <input type="hidden" id="itemGroupId" value="0">
                <div class="u-mb-20">
                    <label class="fw-700 d-block u-mb-8">질문 <span class="u-txt-accent">*</span></label>
                    <input type="text" id="itemQuestion" class="u-input u-px-12 u-py-10 w-100" placeholder="질문을 입력하세요">
                </div>
                <div>
                    <label class="fw-700 d-block u-mb-8">답변 <span class="u-txt-accent">*</span></label>
                    <textarea id="itemAnswer" class="u-input u-px-12 u-py-10 w-100" rows="5" placeholder="답변을 입력하세요"></textarea>
                </div>
            </div>
            <div class="modal-footer u-p-24 border-0">
                <button type="button" class="u-btn u-bg-soft u-txt-title u-px-24 u-py-12 rounded-8 fw-700" data-bs-dismiss="modal">취소</button>
                <button type="button" class="u-btn u-bg-main u-txt-white u-px-24 u-py-12 rounded-8 fw-700" onclick="saveItem()">저장</button>
            </div>
        </div>
    </div>
</div>

<script>
const AJAX_URL   = './faq_manager.php';
const openGroups = {};

// ── 그룹 토글 ──
async function toggleGroup(groupId, event) {
    if (event.target.closest('.header-actions') || event.target.closest('.copy-id-btn')) return;

    const area    = document.getElementById('items-area-' + groupId);
    const chevron = document.getElementById('chevron-' + groupId);

    if (openGroups[groupId]) {
        area.style.display = 'none';
        chevron.classList.remove('open');
        openGroups[groupId] = false;
        return;
    }

    await loadItems(groupId);
    area.style.display = 'block';
    chevron.classList.add('open');
    openGroups[groupId] = true;
}

// ── 아이템 목록 렌더 (이벤트 위임으로 버튼 동작) ──
async function loadItems(groupId) {
    const res  = await ajax({ ajax_action: 'get_items', group_id: groupId });
    const list = document.getElementById('items-list-' + groupId);

    if (!res.items || res.items.length === 0) {
        list.innerHTML = '<div class="u-p-24 u-txt-muted c-fs-14 text-center">등록된 질문이 없습니다.</div>';
        return;
    }

    list.innerHTML = res.items.map(item => `
        <div class="faq-item-row" id="item-row-${item.id}">
            <div class="flex-fill">
                <div class="q-text">Q. ${esc(item.question)}</div>
                <div class="a-text">${esc(item.answer)}</div>
            </div>
            <div class="d-flex u-gap-8 flex-shrink-0">
                <button type="button"
                    class="u-btn u-bg-soft u-txt-title u-px-12 u-py-6 rounded-4 c-fs-13 fw-600"
                    data-action="edit"
                    data-id="${item.id}"
                    data-group="${groupId}"
                    data-question="${esc(item.question)}"
                    data-answer="${esc(item.answer)}">수정</button>
                <button type="button"
                    class="u-btn u-txt-accent u-px-12 u-py-6 rounded-4 c-fs-13 fw-700"
                    style="background:#fff5f5; border:1px solid #fcc;"
                    data-action="delete"
                    data-id="${item.id}"
                    data-group="${groupId}">삭제</button>
            </div>
        </div>
    `).join('');

    // 이벤트 위임
    list.addEventListener('click', function (e) {
        const btn = e.target.closest('[data-action]');
        if (!btn) return;
        const { action, id, group, question, answer } = btn.dataset;
        if (action === 'edit') {
            openItemModal(group, { id, question, answer });
        } else if (action === 'delete') {
            deleteItem(id, group);
        }
    }, { once: false });
}

// ── 그룹 모달 ──
function openGroupModal(group) {
    document.getElementById('groupId').value   = group ? group.id : 0;
    document.getElementById('groupName').value = group ? group.name : '';
    document.getElementById('groupDesc').value = group ? group.description : '';
    document.getElementById('groupModalTitle').textContent = group ? 'FAQ 그룹 수정' : 'FAQ 그룹 추가';
    new bootstrap.Modal(document.getElementById('groupModal')).show();
}

async function saveGroup() {
    const id   = document.getElementById('groupId').value;
    const name = document.getElementById('groupName').value.trim();
    if (!name) { alert('그룹명을 입력하세요.'); return; }
    const res = await ajax({
        ajax_action: 'save_group', id, name,
        description: document.getElementById('groupDesc').value,
    });
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('groupModal')).hide();
        location.reload();
    } else {
        alert(res.msg || '저장 실패');
    }
}

async function deleteGroup(id, name) {
    if (!confirm(`"${name}" 그룹을 삭제하면 하위 질문도 모두 삭제됩니다.\n정말 삭제하시겠습니까?`)) return;
    const res = await ajax({ ajax_action: 'delete_group', id });
    if (res.success) document.getElementById('group-row-' + id).remove();
}

// ── 아이템 모달 ──
function openItemModal(groupId, item) {
    document.getElementById('itemId').value       = item ? item.id : 0;
    document.getElementById('itemGroupId').value  = groupId;
    document.getElementById('itemQuestion').value = item ? item.question : '';
    document.getElementById('itemAnswer').value   = item ? item.answer : '';
    document.getElementById('itemModalTitle').textContent = (item && item.id) ? '질문 수정' : '질문 추가';
    new bootstrap.Modal(document.getElementById('itemModal')).show();
}

async function saveItem() {
    const groupId  = document.getElementById('itemGroupId').value;
    const question = document.getElementById('itemQuestion').value.trim();
    if (!question) { alert('질문을 입력하세요.'); return; }
    const res = await ajax({
        ajax_action: 'save_item',
        id:       document.getElementById('itemId').value,
        group_id: groupId,
        question,
        answer: document.getElementById('itemAnswer').value,
    });
    if (res.success) {
        bootstrap.Modal.getInstance(document.getElementById('itemModal')).hide();
        await loadItems(groupId);
    } else {
        alert(res.msg || '저장 실패');
    }
}

async function deleteItem(id, groupId) {
    if (!confirm('질문을 삭제하시겠습니까?')) return;
    const res = await ajax({ ajax_action: 'delete_item', id });
    if (res.success) await loadItems(groupId);
}

// ── 공통 AJAX ──
async function ajax(data) {
    const body = new URLSearchParams(data);
    const res  = await fetch(AJAX_URL, { method: 'POST', body });
    return res.json();
}

// ── ID 복사 ──
function copyId(id) {
    navigator.clipboard.writeText(String(id)).then(() => {
        showToast('ID ' + id + ' 복사됨!', 'success');
    });
}

function esc(str) {
    return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>

<?php include_once(G5_PATH . '/tail.php'); ?>