<?php
// content/non_covered_manager.php

// 경로수정: 한 단계 위 newadm 폴더의 _common.php 호출
include_once('../_common.php');
include_once('../_auth_check.php');

// G5_DATA_PATH 내에 content 폴더가 없으면 생성 (쓰기 권한 에러 방지)
$json_dir = G5_DATA_PATH . '/content';
if(!is_dir($json_dir)) {
    @mkdir($json_dir, G5_DIR_PERMISSION);
    @chmod($json_dir, G5_DIR_PERMISSION);
}
$json_file = $json_dir . '/non_covered.json';

// [1] 데이터 저장 로직
if (isset($_POST['mode']) && $_POST['mode'] == 'update') {
    $data = json_decode(stripslashes($_POST['items_json']), true);
    
    // 데이터가 배열이 아니면 빈 배열로 초기화
    if(!is_array($data)) $data = [];

    $json_content = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
    if(file_put_contents($json_file, $json_content)) {
        alert_toast('비급여 수가표가 저장되었습니다.', './non_covered_manager.php', 'success');
    } else {
        alert_toast('파일 저장에 실패했습니다. data 폴더의 쓰기 권한을 확인하세요.', 'error');
    }
}

// [2] 데이터 로드
$items_data = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];
if(!is_array($items_data)) $items_data = [];
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <title>비급여 수가표 관리 - NEW ADM</title>

    <style>
        #admin_wrapper { display: grid!important; grid-template-columns: 280px 1fr; min-height: 100vh; }
        .btn_delete:hover { background: #dc3545 !important; color: #fff !important; }
        input.u-input:focus { border-color: var(--main-color) !important; outline: none; box-shadow: 0 0 0 2px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div id="admin_wrapper">
    <?php 
    // 경로수정: 한 단계 위 aside.php 호출
    include_once('../aside.php'); 
    ?>

    <main class="u-bg-soft u-p-40 w-100">
        <h2 class="t-fs-32 fw-900 u-mb-40">💰 비급여 수가표 관리</h2>

        <form method="post" id="priceForm" onsubmit="return preSave()">
            <input type="hidden" name="mode" value="update">
            <input type="hidden" name="items_json" id="items_json">

            <section class="u-bg-white rounded-24 u-p-32 u-mb-24 shadow-soft">
                <div class="d-flex justify-content-between align-items-center u-mb-24">
                    <h3 class="t-fs-20 fw-800">수가표 항목 관리</h3>
                    <button type="button" onclick="addRow()" class="u-btn u-bg-main u-txt-white rounded-8 shadow-sm u-px-20 u-py-8 fw-700">
                        <span class="material-symbols-outlined" style="font-size:18px; vertical-align:middle; margin-right:4px;">add</span>
                        항목 추가
                    </button>
                </div>

                <div class="u-bd-1 u-bc-gray-200 rounded-12 u-mt-20 table-responsive" >
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr class="u-bg-gray-100">
                                <th class="u-py-16 u-px-16 u-bd-b-2 u-bc-gray-300 fw-700 c-fs-16 u-txt-body" style="width:35%; text-align:center;">항목명</th>
                                <th class="u-py-16 u-px-16 u-bd-b-2 u-bc-gray-300 fw-700 c-fs-16 u-txt-body" style="width:20%; text-align:center;">가격 (원)</th>
                                <th class="u-py-16 u-px-16 u-bd-b-2 u-bc-gray-300 fw-700 c-fs-16 u-txt-body" style="width:35%; text-align:center;">비고</th>
                                <th class="u-py-16 u-px-16 u-bd-b-2 u-bc-gray-300 fw-700 c-fs-16 u-txt-body" style="width:10%; text-align:center;">삭제</th>
                            </tr>
                        </thead>
                        <tbody id="price_tbody"></tbody>
                    </table>
                </div>
            </section>

            <div class="u-mt-24 d-flex justify-content-end w-100">
                <button type="submit" class="u-bg-main u-txt-white u-btn u-px-40 u-py-12 rounded-8 fw-700 shadow-main t-fs-16">
                    💾 비급여 수가표 저장
                </button>
            </div>
        </form>
    </main>
</div>

<script>
let itemsData = <?=json_encode($items_data)?>;

function renderTable() {
    const tbody = document.getElementById('price_tbody');
    tbody.innerHTML = '';

    if(itemsData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" class="u-py-40 u-px-20 u-txt-muted c-fs-16" style="text-align:center;">등록된 비급여 항목이 없습니다.<br>우측 상단 "항목 추가" 버튼을 눌러 항목을 추가해주세요.</td></tr>';
        return;
    }

    itemsData.forEach((item, index) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="u-py-12 u-px-12 u-bd-b-1 u-bc-gray-200">
                <input type="text" class="u-input u-px-12 u-py-10 rounded-8 c-fs-14" value="${item.name || ''}" onchange="updateItem(${index}, 'name', this.value)" placeholder="예: 임플란트" style="width: 100%;">
            </td>
            <td class="u-py-12 u-px-12 u-bd-b-1 u-bc-gray-200">
                <input type="text" class="u-input u-px-12 u-py-10 rounded-8 c-fs-14" value="${item.price || ''}" onchange="updateItem(${index}, 'price', this.value)" placeholder="예: 1,500,000" style="width: 100%;">
            </td>
            <td class="u-py-12 u-px-12 u-bd-b-1 u-bc-gray-200">
                <input type="text" class="u-input u-px-12 u-py-10 rounded-8 c-fs-14" value="${item.note || ''}" onchange="updateItem(${index}, 'note', this.value)" placeholder="예: 상부보철 포함" style="width: 100%;">
            </td>
            <td class="u-py-12 u-px-12 u-bd-b-1 u-bc-gray-200" style="text-align:center;">
                <button type="button" onclick="deleteRow(${index})" class="btn_delete u-bg-white u-bd-1 u-px-16 u-py-8 rounded-8 c-fs-14 fw-600 cursor-pointer" style="border-color: #dc3545; color: #dc3545;">삭제</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function updateItem(index, field, value) { itemsData[index][field] = value; }
function addRow() { itemsData.push({ name: '', price: '', note: '' }); renderTable(); }
function deleteRow(index) { if(confirm('이 항목을 삭제하시겠습니까?')) { itemsData.splice(index, 1); renderTable(); } }

function preSave() {
    const filteredData = itemsData.filter(item => item.name.trim() !== '' || item.price.trim() !== '');
    document.getElementById('items_json').value = JSON.stringify(filteredData);
    return true;
}

window.onload = function() { renderTable(); };
</script>
</body>
</html>