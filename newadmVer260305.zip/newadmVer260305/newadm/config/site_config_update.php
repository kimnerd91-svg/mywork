<?php
include_once('../../common.php');
include_once('./_common.php');
include_once('./_auth_check.php');

// 디버그 모드
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>저장 디버그</h2>";

// POST 데이터 확인
echo "<h3>받은 데이터:</h3>";
echo "<pre>";
echo "cf_add_script 길이: " . strlen($_POST['cf_add_script'] ?? '') . " bytes\n";
echo "cf_add_body_script 길이: " . strlen($_POST['cf_add_body_script'] ?? '') . " bytes\n";
echo "</pre>";

// 1. DB 컬럼 자동 점검 및 생성
$check_cols = [
    'cf_add_script' => "TEXT DEFAULT ''",
    'cf_add_body_script' => "TEXT DEFAULT ''",
    'cf_site_name' => "varchar(255) DEFAULT ''",
    'cf_ga_id' => "varchar(255) DEFAULT ''",
    'cf_langs' => "varchar(255) DEFAULT ''",
    'cf_kakao_rest_key' => "varchar(255) DEFAULT ''",
    'cf_kakao_client_secret' => "varchar(255) DEFAULT ''",
    'cf_naver_client_id' => "varchar(255) DEFAULT ''",
    'cf_naver_secret' => "varchar(255) DEFAULT ''",
    'cf_google_client_id' => "varchar(255) DEFAULT ''",
    'cf_social_login_use' => "tinyint(4) DEFAULT '0'"
];

foreach($check_cols as $col => $type) {
    $c = sql_query("SHOW COLUMNS FROM `dm_config` LIKE '$col'");
    if(sql_num_rows($c) == 0) {
        sql_query("ALTER TABLE `dm_config` ADD `$col` $type");
        echo "<p style='color:blue;'>컬럼 추가: $col</p>";
    }
}

// 2. 다국어 설정 처리
$cf_langs = isset($_POST['cf_langs']) ? implode(',', $_POST['cf_langs']) : 'ko';

// 3. 파일 업로드 처리 전 기존 데이터 불러오기
$config = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
$upload_path = G5_DATA_PATH.'/common';

function handle_file_upload($file_key, $existing_filename) {
    global $upload_path;
    if(isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] == 0) {
        $ext = pathinfo($_FILES[$file_key]['name'], PATHINFO_EXTENSION);
        $filename = $file_key . '_' . time() . '.' . $ext;
        move_uploaded_file($_FILES[$file_key]['tmp_name'], $upload_path.'/'.$filename);
        return $filename;
    }
    return $existing_filename;
}

$cf_favicon = handle_file_upload('favicon_file', $config['cf_favicon']);
$cf_og_image = handle_file_upload('og_file', $config['cf_og_image']);

// 4. 통합 SQL 업데이트 필드 구성
$sql_fields = [];

// 스크립트 필드는 별도 처리 (mysql_real_escape_string 사용)
$script_fields = ['cf_add_script', 'cf_add_body_script'];
foreach($script_fields as $f) {
    if(isset($_POST[$f])) {
        // mysqli_real_escape_string 사용
        global $connect_db;
        $val = mysqli_real_escape_string($connect_db, $_POST[$f]);
        $sql_fields[] = " $f = '$val' ";
        echo "<p style='color:green;'>스크립트 저장 준비: $f</p>";
    }
}

// 일반 필드
$fields = [
    'cf_site_name', 'cf_title', 'cf_description', 'cf_ga_id',
    'cf_company_name', 'cf_ceo_name', 'cf_business_number', 'cf_tel', 
    'cf_address', 'cf_lat', 'cf_lng', 'cf_privacy_policy', 'cf_terms',
    'cf_naver_booking', 'cf_naver_talk', 'cf_kakao', 'cf_blog', 'cf_instagram',
    'cf_kakao_rest_key', 'cf_naver_client_id', 'cf_naver_secret', 'cf_google_client_id',
    'cf_kakao_client_secret',
];

foreach($fields as $f) {
    if(isset($_POST[$f])) {
        $val = sql_escape_string($_POST[$f]);
        $sql_fields[] = " $f = '$val' ";
    }
}

// 체크박스는 전송되지 않을 경우 0으로 처리
$cf_social_login_use = isset($_POST['cf_social_login_use']) ? 1 : 0;
$sql_fields[] = " cf_social_login_use = '$cf_social_login_use' ";

// 로고 파일 개별 처리
if (isset($_FILES['logo_file']['name']) && $_FILES['logo_file']['name']) {
    $dest_path = G5_DATA_PATH.'/common/';
    @mkdir($dest_path, G5_DIR_PERMISSION);
    $filename = 'logo_'.time().'_'.$_FILES['logo_file']['name'];
    move_uploaded_file($_FILES['logo_file']['tmp_name'], $dest_path.$filename);
    sql_query(" UPDATE dm_config SET cf_logo = '$filename' WHERE cf_id = 1 ");
}

$sql_fields[] = " cf_langs = '$cf_langs' ";
$sql_fields[] = " cf_favicon = '$cf_favicon' ";
$sql_fields[] = " cf_og_image = '$cf_og_image' ";

$sql = " UPDATE dm_config SET " . implode(',', $sql_fields) . " WHERE cf_id = 1 ";

echo "<h3>실행할 SQL:</h3>";
echo "<pre>" . htmlspecialchars($sql) . "</pre>";

$result = sql_query($sql);

// if ($result) {
//     echo "<p style='color:green; font-weight:bold; font-size:20px;'>✅ 저장 성공!</p>";
    
//     // 저장된 값 확인
//     $check = sql_fetch("SELECT cf_add_script, cf_add_body_script FROM dm_config WHERE cf_id = 1");
//     echo "<h3>저장된 값:</h3>";
//     echo "<pre>";
//     echo "cf_add_script 길이: " . strlen($check['cf_add_script']) . " bytes\n";
//     echo "cf_add_body_script 길이: " . strlen($check['cf_add_body_script']) . " bytes\n";
//     echo "</pre>";
    
//     echo "<hr>";
//     echo "<p><a href='../config/site_config.php'>← 설정 페이지로 돌아가기</a></p>";
// } else {
//     echo "<p style='color:red; font-weight:bold;'>❌ 저장 실패!</p>";
//     echo "<p>에러: " . sql_error() . "</p>";
// }
// ?>