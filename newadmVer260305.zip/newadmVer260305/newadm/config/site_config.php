<?php
include_once('../_common.php');
include_once('./_auth_check.php');

// ============================================================
// AJAX 저장 처리
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {

    // 파일 업로드 함수
    function upload_config_file($file_key, $allowed = ['jpg','jpeg','png','gif','webp','ico','svg']) {
        if (!isset($_FILES[$file_key]) || $_FILES[$file_key]['error'] != 0) return null;
        $dir = $_SERVER['DOCUMENT_ROOT'] . G5_DATA_PATH . '/common/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $name = $_FILES[$file_key]['name'];
        $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowed)) return null;
        $fn = 'config_' . $file_key . '_' . time() . '.' . $ext;
        if (move_uploaded_file($_FILES[$file_key]['tmp_name'], $dir . $fn)) return $fn;
        return null;
    }

    $sets = [];

    // 텍스트 필드
    $text_fields = [
        'cf_site_name','cf_title','cf_description','cf_ga_id',
        'cf_add_script','cf_add_body_script',
        'cf_company_name','cf_ceo_name','cf_business_number','cf_tel',
        'cf_address','cf_lat','cf_lng',
        'cf_naver_booking','cf_naver_talk','cf_kakao','cf_blog','cf_instagram',
        'cf_kakao_rest_key','cf_kakao_client_secret',
        'cf_naver_client_id','cf_naver_secret',
        'cf_google_client_id',
        'cf_privacy_policy','cf_terms',
    ];
    foreach ($text_fields as $f) {
        $val = isset($_POST[$f]) ? $_POST[$f] : '';
        $sets[] = "`{$f}` = '" . sql_real_escape_string($val) . "'";
    }

    // 체크박스
    $sets[] = "`cf_social_login_use` = " . (isset($_POST['cf_social_login_use']) ? 1 : 0);

    // 파일 업로드
    $logo_new = upload_config_file('logo_file');
    if ($logo_new) $sets[] = "`cf_logo` = '" . sql_real_escape_string($logo_new) . "'";

    $favicon_new = upload_config_file('favicon_file');
    if ($favicon_new) $sets[] = "`cf_favicon` = '" . sql_real_escape_string($favicon_new) . "'";

    $og_new = upload_config_file('og_file');
    if ($og_new) $sets[] = "`cf_og_image` = '" . sql_real_escape_string($og_new) . "'";

    // 행이 없으면 INSERT, 있으면 UPDATE
    $exist = sql_fetch("SELECT cf_id FROM dm_config WHERE cf_id = 1");
    if ($exist) {
        sql_query("UPDATE dm_config SET " . implode(', ', $sets) . " WHERE cf_id = 1");
    } else {
        sql_query("INSERT INTO dm_config (cf_id, " . implode(', ', array_map(function($s){ return explode(' =', $s)[0]; }, $sets)) . ") VALUES (1, " . implode(', ', array_map(function($s){ $p = explode("= ", $s, 2); return $p[1]; }, $sets)) . ")");
    }

    echo json_encode(['success' => true]);
    exit;
}

// 테이블 컬럼 추가 (없으면 자동 생성)
$columns = [
    'cf_og_image' => "varchar(255) DEFAULT ''",
    'cf_favicon' => "varchar(255) DEFAULT ''",
    'cf_logo' => "varchar(255) DEFAULT ''", // 로고 컬럼 추가
    'cf_site_name' => "varchar(255) DEFAULT ''",
    'cf_company_name' => "varchar(255) DEFAULT ''",
    'cf_ceo_name' => "varchar(100) DEFAULT ''",
    'cf_business_number' => "varchar(50) DEFAULT ''",
    'cf_tel' => "varchar(50) DEFAULT ''",
    'cf_address' => "varchar(500) DEFAULT ''",
    'cf_lat' => "varchar(50) DEFAULT ''",
    'cf_lng' => "varchar(50) DEFAULT ''",
    'cf_privacy_policy' => "longtext",
    'cf_terms' => "longtext",
    'cf_naver_booking' => "varchar(500) DEFAULT ''",
    'cf_naver_talk' => "varchar(500) DEFAULT ''",
    'cf_kakao' => "varchar(500) DEFAULT ''",
    'cf_blog' => "varchar(500) DEFAULT ''",
    'cf_instagram' => "varchar(500) DEFAULT ''",
    'cf_kakao_rest_key' => "varchar(255) DEFAULT ''",
    'cf_kakao_client_secret' => "varchar(255) DEFAULT ''",
    'cf_naver_client_id' => "varchar(255) DEFAULT ''",
    'cf_naver_secret' => "varchar(255) DEFAULT ''",
    'cf_google_client_id' => "varchar(255) DEFAULT ''",
    'cf_social_login_use' => "tinyint(4) DEFAULT '0'",
    'cf_ga_id' => "varchar(50) DEFAULT ''",
    'cf_add_script' => "text",
    'cf_add_body_script' => "text"
    // 'cf_footer_tel' => "varchar(50) DEFAULT ''"
];

foreach ($columns as $col => $type) {
    $check = sql_query("SHOW COLUMNS FROM `dm_config` LIKE '$col'");
    if (sql_num_rows($check) == 0) {
        sql_query("ALTER TABLE `dm_config` ADD `$col` $type");
    }
}

$dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>기본정보 관리 - NEW ADM</title>
    <!-- 카카오 맵 API -->
    <script src="//t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
    <script src="//dapi.kakao.com/v2/maps/sdk.js?appkey=YOUR_KAKAO_API_KEY&libraries=services"></script>
    <style>
        .section-divider {
            margin: 60px 0 40px;
            padding-top: 40px;
            border-top: 2px solid var(--gray-200);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 32px;
        }

        .section-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: var(--bg-soft);
            color: var(--main-color);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .address-search-btn {
            padding: 12px 20px;
            background: var(--main-color);
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            white-space: nowrap;
        }

        .address-search-btn:hover {
            background: #0056b3;
        }
    </style>
</head>

<body>

    <div id="admin_wrapper">
        <?php include_once('../aside.php'); ?>

        <main class="content_area u-pb-40">
            <h2 class="t-fs-32 fw-900 u-mb-32">⚙️ 사이트 기본정보 관리</h2>

            <form id="siteConfigForm" enctype="multipart/form-data">

                <!-- 1. SEO 및 기본 설정 -->
                <section class="card_custom">
                    <div class="section-header">
                        <div class="section-icon">
                            <span class="material-symbols-outlined">search</span>
                        </div>
                        <div>
                            <h3 class="t-fs-24 fw-800 m-0">SEO 및 검색 최적화</h3>
                            <p class="c-fs-14 u-txt-muted m-0">네이버, 구글 검색 노출을 위한 메타 정보</p>
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">사이트 공식 명칭</label>
                            <input type="text" name="cf_site_name" value="<?= $dm_conf['cf_site_name'] ?>" class="u-input u-px-12 u-py-4" placeholder="예: 금천 연세세브란스치과">
                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">브라우저 타이틀 (Title Tag)</label>
                            <input type="text" name="cf_title" value="<?= $dm_conf['cf_title'] ?>" class="u-input u-px-12 u-py-4" placeholder="검색 결과에 표시될 제목">
                        </div>
                    </div>

                    <div class="u-mb-24">
                        <label class="fw-700 u-txt-title d-block u-mb-8 ">사이트 설명 (Meta Description)</label>
                        <textarea name="cf_description" class="u-input u-px-12 u-py-8 rounded-4" rows="10" placeholder="네이버/구글 검색 결과 아래에 표시되는 설명글"><?= $dm_conf['cf_description'] ?></textarea>
                    </div>
                    <div class="u-mb-20">
                        <label class="fw-700 u-txt-title d-block u-mb-8">사이트 로고 (Logo)</label>
                        <input type="file" name="logo_file" class="u-input u-px-12 u-mb-4 rounded-4" accept=".png,.jpg,.jpeg">
                        <?php if ($dm_conf['cf_logo']) { ?>
                            <div class="u-mt-8 p-2 border rounded-4 bg-light d-inline-block">
                                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" style="max-height:60px; max-width:100%;" alt="현재 로고">
                            </div>
                        <?php } ?>
                        <p class="c-fs-10 u-mb-8 u-txt-gray-600">권장 사이즈: 가로 200px 이상의 PNG 또는 JPG 파일을 권장합니다.</p>


                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">파비콘 (Favicon)</label>
                            <input type="file" name="favicon_file" class="u-input u-px-12 u-mb-4 rounded-4" accept=".ico,.png">
                            <?php if ($dm_conf['cf_favicon']) { ?>
                                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_favicon'] ?>" style="height:32px;" class="u-my-8">
                            <?php } ?>
                            <p class="c-fs-10 u-mb-8 u-txt-gray-600">32*32 사이즈를 권장합니다.</p>


                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">SNS 공유 이미지 (Open Graph)</label>
                            <input type="file" name="og_file" class="u-input u-px-12 u-mb-4 rounded-4" accept="image/*">
                            <?php if ($dm_conf['cf_og_image']) { ?>
                                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_og_image'] ?>" style="height:50px; border-radius:8px;" class="u-my-8">
                            <?php } ?>
                            <p class="c-fs-10 u-txt-gray-600 u-mb-8">1200*630 사이즈를 권장합니다.</p>


                        </div>
                    </div>
                    <div class="u-mb-24">
                        <label class="fw-700 u-txt-title d-block u-mb-8">구글 애널리틱스 측정 ID (GA4)</label>
                        <input type="text" name="cf_ga_id" value="<?= $dm_conf['cf_ga_id'] ?>" class="u-input u-px-12 u-py-4" placeholder="G-XXXXXXXXXX">
                        <small class="u-txt-muted c-fs-12 d-block u-mt-4">측정 ID만 입력 (예: G-XXXXXXXXXX)</small>
                    </div>

                    <div class="u-mb-24">
                        <label class="fw-700 u-txt-title d-block u-mb-8">HEAD 추가 스크립트</label>
                        <textarea name="cf_add_script" rows="8" class="u-input u-px-12 u-py-4" style="font-family: monospace; font-size: 13px;" placeholder="<script>...</script>"><?= htmlspecialchars($dm_conf['cf_add_script']) ?></textarea>
                        <small class="u-txt-muted c-fs-12 d-block u-mt-4">GTM HEAD 코드, 네이버 애널리틱스 등을 여기에 붙여넣으세요</small>
                    </div>

                    <div>
                        <label class="fw-700 u-txt-title d-block u-mb-8">BODY 시작 부분 스크립트</label>
                        <textarea name="cf_add_body_script" rows="8" class="u-input u-px-12 u-py-4" style="font-family: monospace; font-size: 13px;" placeholder="<noscript>...</noscript>"><?= htmlspecialchars($dm_conf['cf_add_body_script']) ?></textarea>
                        <small class="u-txt-muted c-fs-12 d-block u-mt-4">GTM BODY 코드 (noscript)를 여기에 붙여넣으세요</small>
                    </div>
                </section>


                <!-- 2. 간편로그인을 위한 REST ID 등 기타 -->

                <section class="card_custom section-divider">
                    <div class="section-header">
                        <div class="section-icon">
                            <span class="material-symbols-outlined">login</span>
                        </div>
                        <div>
                            <h3 class="t-fs-24 fw-800 m-0">소셜 로그인 API 설정</h3>
                            <p class="c-fs-14 u-txt-muted m-0">간편로그인 연동을 위한 API 키 관리 (개발자 센터 발급)</p>
                        </div>
                    </div>

                    <div class="u-mb-24">
                        <label class="fw-700 u-txt-title d-flex a-center u-mb-12 u-gap-4">
                            <input type="checkbox" name="cf_social_login_use" value="1" <?= $dm_conf['cf_social_login_use'] ? 'checked' : '' ?> class="u-mr-8">
                            <p class="mb-0">소셜 로그인 기능 활성화</p>
                        </label>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div class="p-3 border rounded-8">
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQnOACrRJyk-4693gXNbbpXfQ4OVXSWm3sl5g&s" alt="카카오" style="height:18px; margin-right:8px;">
                                카카오 REST API 키
                            </label>
                            <input type="text" name="cf_kakao_rest_key" value="<?= $dm_conf['cf_kakao_rest_key'] ?>" class="u-input u-px-12 u-py-4" placeholder="카카오 개발자 센터 발급 키">
                            <input type="text" name="cf_kakao_client_secret" value="<?= $dm_conf['cf_kakao_client_secret'] ?>" class="u-input u-px-12 u-py-4" placeholder="카카오 클라이언트 시크릿 키">
                        </div>

                        <div class="p-3 border rounded-8">
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="https://cdn-1.webcatalog.io/catalog/group-naver/group-naver-icon-unplated.png?v=1714774575036" alt="네이버" style="height:18px; margin-right:8px;">
                                네이버 Client ID
                            </label>
                            <input type="text" name="cf_naver_client_id" value="<?= $dm_conf['cf_naver_client_id'] ?>" class="u-input u-px-12 u-py-4 u-mb-8" placeholder="네이버 Client ID">
                            <input type="text" name="cf_naver_secret" value="<?= $dm_conf['cf_naver_secret'] ?>" class="u-input u-px-12 u-py-4" placeholder="네이버 Client Secret">
                        </div>
                    </div>

                    <div class="u-bg-soft u-p-16 rounded-8">
                        <p class="c-fs-13 u-txt-gray-700 m-0">
                            <strong>💡 설정 안내:</strong> 각 개발자 센터에서 <strong>Redirect URI</strong>를 아래 주소로 등록해야 작동합니다.<br>
                            <code class="u-txt-main">http://<?= $_SERVER['HTTP_HOST'] ?>/plugin/social_login/callback.php</code><br>
                            <strong>💡카카오 방법 안내:</strong> <br> 1. 카카오 디벨롭퍼에서 앱 생성 2. 앱 선택 후 대시보드의 설정 항목에서 카카오 로그인 설정 클릭 3. 전부 설정으로 변경 4. 메뉴 [앱] - 플랫폼 키 항목의 Rest Api 클릭 <br>
                            5. 상단의 코드를 카카오 리다이렉트 URL에 입력 + 카카오 클라이언트 시크릿 활성화 6. 상단의 발급키 항목에 각각 복사 후 붙여넣기 7. 만약 안될 경우, www/plugin/social_login/callback.php 의 상단에 각 키를 직접 입력.<br>
                            <strong>💡카카오 로그아웃 추가: [내 애플리케이션] > [제품 설정] > [카카오 로그인] > [고급] 에서 로그아웃 URL을 사이트의 메인페이지의 주소로 입력.</strong>
                        </p>
                    </div>
                </section>
                <!-- 2. 회사 정보 (푸터용) -->
                <section class="card_custom section-divider">
                    <div class="section-header">
                        <div class="section-icon">
                            <span class="material-symbols-outlined">business</span>
                        </div>
                        <div>
                            <h3 class="t-fs-24 fw-800 m-0">회사 정보</h3>
                            <p class="c-fs-14 u-txt-muted m-0">푸터 영역에 표시될 사업자 정보</p>
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">회사명 / 상호</label>
                            <input type="text" name="cf_company_name" value="<?= $dm_conf['cf_company_name'] ?>" class="u-input u-px-12 u-py-4" placeholder="예: (주)연세세브란스">
                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">대표자명</label>
                            <input type="text" name="cf_ceo_name" value="<?= $dm_conf['cf_ceo_name'] ?>" class="u-input u-px-12 u-py-4" placeholder="홍길동">
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">사업자등록번호</label>
                            <input type="text" name="cf_business_number" value="<?= $dm_conf['cf_business_number'] ?>" class="u-input u-px-12 u-py-4" placeholder="123-45-67890">
                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">대표전화</label>
                            <input type="text" name="cf_tel" id="cf_tel" value="<?= $dm_conf['cf_tel'] ?>" class="u-input u-px-12 u-py-4" placeholder="02-1234-5678" maxlength="13">
                        </div>
                    </div>
                    <div>
                        <label class="fw-700 u-txt-title d-block u-mb-8">주소</label>
                        <div class="g-cols-fit-12 u-gap-12 u-mb-12">
                            <input type="text" name="cf_address_base" id="address" value="" class="u-input u-px-12 u-py-4" placeholder="주소를 검색하세요" readonly>
                            <button type="button" onclick="searchAddress()" class="address-search-btn c-fs-16 u-btn">
                                <span class="material-symbols-outlined" style="vertical-align: middle; font-size: 18px;">search</span>
                                주소 검색
                            </button>
                        </div>

                        <!-- ✅ 상세주소 입력 필드 -->
                        <input type="text" name="cf_address_detail" id="address_detail" value="" class="u-input u-px-12 u-py-4 u-mb-12" placeholder="상세주소를 입력하세요 (예: 3층, 101호)">

                        <!-- ✅ 최종 주소 hidden (기본주소 + 공백 + 상세주소) -->
                        <input type="hidden" name="cf_address" id="cf_address_full" value="<?= $dm_conf['cf_address'] ?>">

                        <input type="hidden" name="cf_lat" id="cf_lat" value="<?= $dm_conf['cf_lat'] ?>">
                        <input type="hidden" name="cf_lng" id="cf_lng" value="<?= $dm_conf['cf_lng'] ?>">
                        <p class="c-fs-12 u-txt-muted">※ 주소 검색 시 지도 좌표(위도/경도)가 자동으로 저장됩니다.</p>
                    </div>
                </section>

                <!-- 3. SNS 링크 관리 -->
                <section class="card_custom section-divider">
                    <div class="section-header">
                        <div class="section-icon">
                            <span class="material-symbols-outlined">share</span>
                        </div>
                        <div>
                            <h3 class="t-fs-24 fw-800 m-0">SNS 링크 관리</h3>
                            <p class="c-fs-14 u-txt-muted m-0">푸터 및 퀵메뉴에 표시될 SNS 링크</p>
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="/images/common/sns1.png" alt="네이버 예약" style="height:20px; vertical-align:middle; margin-right:8px;">
                                네이버 예약
                            </label>
                            <input type="text" name="cf_naver_booking" value="<?= $dm_conf['cf_naver_booking'] ?>" class="u-input u-px-12 u-py-4" placeholder="https://naver.me/xxxxx">
                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="/images/common/sns7.png" alt="네이버톡톡" style="height:20px; vertical-align:middle; margin-right:8px;">
                                네이버 톡톡
                            </label>
                            <input type="text" name="cf_naver_talk" value="<?= $dm_conf['cf_naver_talk'] ?>" class="u-input u-px-12 u-py-4" placeholder="https://talk.naver.com/xxxxx">
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24 u-mb-24">
                        <div>
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="/images/common/sns2.png" alt="카카오톡" style="height:20px; vertical-align:middle; margin-right:8px;">
                                카카오톡 채널
                            </label>
                            <input type="text" name="cf_kakao" value="<?= $dm_conf['cf_kakao'] ?>" class="u-input u-px-12 u-py-4" placeholder="https://pf.kakao.com/_xxxxx">
                        </div>
                        <div>
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="/images/common/sns5.png" alt="블로그" style="height:20px; vertical-align:middle; margin-right:8px;">
                                네이버 블로그
                            </label>
                            <input type="text" name="cf_blog" value="<?= $dm_conf['cf_blog'] ?>" class="u-input u-px-12 u-py-4" placeholder="https://blog.naver.com/xxxxx">
                        </div>
                    </div>

                    <div class="g-cols-fit-12 u-gap-24">
                        <div>
                            <label class="fw-700 u-txt-title d-flex align-items-center u-mb-8">
                                <img src="/images/common/sns4.png" alt="인스타그램" style="height:20px; vertical-align:middle; margin-right:8px;">
                                인스타그램
                            </label>
                            <input type="text" name="cf_instagram" value="<?= $dm_conf['cf_instagram'] ?>" class="u-input u-px-12 u-py-4" placeholder="https://www.instagram.com/xxxxx">
                        </div>
                        <!-- <div>
                            <label class="fw-700 u-txt-title d-block u-mb-8">
                                <span class="material-symbols-outlined" style="vertical-align:middle; margin-right:8px;">call</span>
                                대표 전화번호 (푸터용)
                            </label>
                            <input type="text" name="cf_footer_tel" value="<?= $dm_conf['cf_footer_tel'] ?>" class="u-input u-px-12 u-py-4" placeholder="02-6293-2875">
                        </div> -->
                    </div>
                </section>

                <!-- 4. 법적 고지 -->
                <section class="card_custom section-divider">
                    <div class="section-header">
                        <div class="section-icon">
                            <span class="material-symbols-outlined">gavel</span>
                        </div>
                        <div>
                            <h3 class="t-fs-24 fw-800 m-0">법적 고지</h3>
                            <p class="c-fs-14 u-txt-muted m-0">개인정보처리방침, 이용약관 등</p>
                        </div>
                    </div>

                    <div class="u-mb-32">
                        <label class="fw-700 u-txt-title d-block u-mb-8">개인정보처리방침</label>
                        <textarea name="cf_privacy_policy" class="u-input u-px-12 u-py-4" rows="10" placeholder="개인정보처리방침 내용을 입력하세요"><?= htmlspecialchars($dm_conf['cf_privacy_policy']) ?></textarea>
                        <p class="c-fs-12 u-txt-muted u-mt-8">※ HTML 태그 사용 가능합니다.</p>
                    </div>

                    <div>
                        <label class="fw-700 u-txt-title d-block u-mb-8">이용약관</label>
                        <textarea name="cf_terms" class="u-input u-px-12 u-py-4" rows="10" placeholder="이용약관 내용을 입력하세요"><?= htmlspecialchars($dm_conf['cf_terms']) ?></textarea>
                        <p class="c-fs-12 u-txt-muted u-mt-8">※ HTML 태그 사용 가능합니다.</p>
                    </div>
                </section>

                <div class="text-center u-mt-40 position-fixed" style="bottom: 50px; left: 50%; transform: translateX(-50%);">
                    <button type="button" id="saveBtn" onclick="saveConfig()" class="u-bg-main u-btn u-gap-8 u-txt-white u-px-32 u-py-16 c-fs-20 rounded-8 fw-900 u-press shadow-main">
                        <span class="material-symbols-outlined" style="vertical-align: middle;">save</span>
                        전체 설정 저장하기
                    </button>
                </div>
            </form>
        </main>
    </div>
    <script>
        // ✅ 페이지 로드 시 기존 주소 분리해서 표시
        window.addEventListener('DOMContentLoaded', function() {
            const fullAddr = '<?= $dm_conf['cf_address'] ?>';
            if (fullAddr) {
                const parts = fullAddr.match(/^(.+?)(\s+\d+동.+|\s+\d+층.+|\s+\d+호.+)$/);
                if (parts) {
                    document.getElementById('address').value = parts[1].trim();
                    document.getElementById('address_detail').value = parts[2].trim();
                } else {
                    document.getElementById('address').value = fullAddr;
                }
            }
        });

        // ✅ 카카오 주소 검색
        function searchAddress() {
            new daum.Postcode({
                oncomplete: function(data) {
                    // 기본 주소 입력
                    document.getElementById('address').value = data.address;

                    // 상세주소에 포커스
                    document.getElementById('address_detail').focus();

                    // 전체 주소 업데이트
                    updateFullAddress();

                    // 주소로 좌표 검색
                    var geocoder = new kakao.maps.services.Geocoder();
                    geocoder.addressSearch(data.address, function(result, status) {
                        if (status === kakao.maps.services.Status.OK) {
                            document.getElementById('cf_lat').value = result[0].y;
                            document.getElementById('cf_lng').value = result[0].x;
                        }
                    });
                },
                // ✅ 주소 선택 후 자동으로 창 닫기
                autoClose: true
            }).open();
        }

        // ✅ 전체 주소 업데이트 (공백으로 합침)
        function updateFullAddress() {
            const baseAddr = document.getElementById('address').value;
            const detailAddr = document.getElementById('address_detail').value;
            const fullAddr = detailAddr ? `${baseAddr} ${detailAddr}` : baseAddr;
            document.getElementById('cf_address_full').value = fullAddr;
        }

        // 상세주소 입력 시 전체 주소 업데이트
        document.getElementById('address_detail').addEventListener('input', updateFullAddress);

        // ✅ 전화번호 자동 하이픈
        document.getElementById('cf_tel').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^0-9]/g, '');
            let formatted = '';

            if (value.length <= 10) {
                if (value.startsWith('02')) {
                    if (value.length > 2) formatted = value.slice(0, 2) + '-';
                    if (value.length > 6) {
                        formatted += value.slice(2, 6) + '-' + value.slice(6, 10);
                    } else if (value.length > 2) {
                        formatted += value.slice(2);
                    }
                } else {
                    if (value.length > 3) formatted = value.slice(0, 3) + '-';
                    if (value.length > 6) {
                        formatted += value.slice(3, 6) + '-' + value.slice(6, 10);
                    } else if (value.length > 3) {
                        formatted += value.slice(3);
                    }
                }
            } else if (value.length === 11) {
                formatted = value.slice(0, 3) + '-' + value.slice(3, 7) + '-' + value.slice(7, 11);
            } else {
                formatted = value;
            }

            e.target.value = formatted || value;
        });
    </script>

<style>
.toast-cfg { position:fixed; bottom:32px; left:50%; transform:translateX(-50%); padding:14px 32px; border-radius:50px; font-size:15px; font-weight:700; color:#fff; z-index:99999; opacity:0; transition:opacity .3s, transform .3s; pointer-events:none; }
.toast-cfg.show { opacity:1; }
.toast-cfg.success { background:#10b981; }
.toast-cfg.error   { background:#ef4444; }
</style>
<script>
function showToastCfg(msg, type) {
    var old = document.querySelector('.toast-cfg'); if (old) old.remove();
    var t = document.createElement('div');
    t.className = 'toast-cfg ' + (type || 'success');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(function(){ t.classList.add('show'); }, 10);
    setTimeout(function(){ t.classList.remove('show'); setTimeout(function(){ t.remove(); }, 300); }, 2500);
}

function saveConfig() {
    var btn = document.getElementById('saveBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="material-symbols-outlined" style="vertical-align:middle;">hourglass_top</span> 저장 중...';

    var fd = new FormData(document.getElementById('siteConfigForm'));
    fd.append('action', 'save');

    fetch('', { method: 'POST', body: fd })
        .then(function(r){ return r.json(); })
        .then(function(d) {
            if (d.success) {
                showToastCfg('저장되었습니다! ✅', 'success');
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                showToastCfg('저장 실패', 'error');
            }
        })
        .catch(function(e){
            showToastCfg('오류: ' + e.message, 'error');
        })
        .finally(function(){
            btn.disabled = false;
            btn.innerHTML = '<span class="material-symbols-outlined" style="vertical-align:middle;">save</span> 전체 설정 저장하기';
        });
}
</script>
</body>

</html>