<?php
// 1. 경로: 한 단계 위가 아닌 두 단계 위로 이동하여 common.php 호출
include_once('../../common.php'); 
include_once('../_common.php'); 
include_once('../_auth_check.php'); // 권한 체크 파일 포함 (기존 로직 유지)

if ($is_admin != 'super') alert('최고관리자만 접근 가능합니다.');

// 1. 설정 데이터 불러오기
$dm = sql_fetch("select * from dm_config where cf_id = 1");
if (!$dm) {
    sql_query("insert into dm_config (cf_id, cf_langs) values (1, 'ko')");
    $dm = sql_fetch("select * from dm_config where cf_id = 1");
}

$g5['title'] = '디렉트 통합 관리자';
include_once(G5_ADMIN_PATH.'/admin.head.php'); 
?>


<form name="fadmin" method="post" action="./site_config_update.php" enctype="multipart/form-data">
    <div id="dm_admin_wrap">
        
        <section class="admin-card">
            <h3 class="fw-900 u-mb-20">🌐 다국어 설정</h3>
            <div class="d-flex gap-20">
                <label><input type="checkbox" name="cf_langs[]" value="ko" checked disabled> 한국어 (기본)</label>
                <label><input type="checkbox" name="cf_langs[]" value="en" <?php echo strpos($dm['cf_langs'], 'en') !== false ? 'checked' : ''; ?>> 영어</label>
                <label><input type="checkbox" name="cf_langs[]" value="ja" <?php echo strpos($dm['cf_langs'], 'ja') !== false ? 'checked' : ''; ?>> 일본어</label>
                <label><input type="checkbox" name="cf_langs[]" value="zh" <?php echo strpos($dm['cf_langs'], 'zh') !== false ? 'checked' : ''; ?>> 중국어</label>
            </div>
            <p class="u-txt-muted t-fs-13 u-mt-10">* 선택 시 홈페이지 상단에 언어 선택 박스가 자동 노출됩니다.</p>
        </section>

        <section class="admin-card">
            <h3 class="fw-900 u-mb-20">🔍 검색엔진 최적화 (SEO)</h3>
            <div class="form-group">
                <label>사이트 타이틀</label>
                <input type="text" name="cf_title" value="<?php echo $dm['cf_title']; ?>" class="form-control-custom" placeholder="네이버 검색 시 제목으로 노출">
            </div>
            <div class="form-group">
                <label>사이트 설명 (Description)</label>
                <textarea name="cf_description" class="form-control-custom" rows="3"><?php echo $dm['cf_description']; ?></textarea>
            </div>
        </section>

        <section class="admin-card">
            <div class="d-flex justify-content-between align-items-center u-mb-20">
                <h3 class="fw-900">📋 게시판 및 게시물 관리</h3>
                <a href="<?php echo G5_ADMIN_URL; ?>/board_form.php" class="btn btn-sm u-bg-main u-txt-white rounded-8">새 게시판 생성</a>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>테이블명</th>
                        <th>게시판 이름</th>
                        <th>글 개수</th>
                        <th>노출상태</th>
                        <th>관리</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "select bo_table, bo_subject, bo_count_write from {$g5['board_table']} order by bo_table asc";
                    $result = sql_query($sql);
                    for ($i=0; $row=sql_fetch_array($result); $i++) {
                    ?>
                    <tr>
                        <td><?php echo $row['bo_table']; ?></td>
                        <td><strong><?php echo $row['bo_subject']; ?></strong></td>
                        <td><?php echo number_format($row['bo_count_write']); ?></td>
                        <td><span class="badge u-bg-soft u-txt-main">노출중</span></td>
                        <td>
                            <a href="<?php echo G5_ADMIN_URL; ?>/board_form.php?w=u&bo_table=<?php echo $row['bo_table']; ?>" class="btn btn-xs border">설정</a>
                            <a href="<?php echo G5_BBS_URL; ?>/board.php?bo_table=<?php echo $row['bo_table']; ?>" target="_blank" class="btn btn-xs border">게시물보기</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>

        <div class="text-center u-mt-40">
            <button type="submit" class="btn u-bg-main u-txt-white px-50 py-16 rounded-12 fw-900 shadow-main u-press">설정값 일괄 저장하기</button>
        </div>
    </div>
</form>

<?php include_once(G5_ADMIN_PATH.'/admin.tail.php'); ?>