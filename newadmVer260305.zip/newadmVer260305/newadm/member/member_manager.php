<?php
// member/member_manager.php

// 경로수정: 한 단계 위 newadm 폴더의 _common.php 호출
include_once('../_common.php');
include_once('../_auth_check.php');

// 회원 삭제/차단 로직
if (isset($_GET['leave_id'])) {
    $mb_id = sql_real_escape_string($_GET['leave_id']);
    sql_query(" UPDATE {$g5['member_table']} SET mb_leave_date = '" . date('Ymd') . "' WHERE mb_id = '$mb_id' ");
    alert_toast('해당 회원을 탈퇴 처리하였습니다.', './member_manager.php');
}

// 회원 목록 쿼리
$sql_common = " FROM {$g5['member_table']} ";
$sql_order = " ORDER BY mb_datetime DESC ";

$sql = " SELECT * $sql_common $sql_order LIMIT 0, 30 ";
$result = sql_query($sql);

// 새 회원 등록 로직
if (isset($_POST['action']) && $_POST['action'] == 'add_member') {
    $mb_id = trim($_POST['mb_id']);
    $mb_password = $_POST['mb_password'];
    $mb_name = trim($_POST['mb_name']);
    $mb_email = trim($_POST['mb_email']);
    $mb_level = (int)$_POST['mb_level'];

    $row = sql_fetch(" SELECT count(*) as cnt FROM {$g5['member_table']} WHERE mb_id = '$mb_id' ");
    if ($row['cnt']) {
        alert_toast('이미 존재하는 아이디입니다.', 'error');
    }

    $mb_password = get_encrypt_string($mb_password);

    $sql = " INSERT INTO {$g5['member_table']}
                SET mb_id = '$mb_id',
                    mb_password = '$mb_password',
                    mb_name = '$mb_name',
                    mb_email = '$mb_email',
                    mb_level = '$mb_level',
                    mb_datetime = '" . G5_TIME_YMDHIS . "',
                    mb_email_certify = '" . G5_TIME_YMDHIS . "',
                    mb_hp = '',
                    mb_certify = '',
                    mb_login_ip = '{$_SERVER['REMOTE_ADDR']}' ";

    sql_query($sql);
    alert_toast('새 회원이 등록되었습니다.', './member_manager.php', 'success');
}


// 회원 정보 수정 로직
if (isset($_POST['action']) && $_POST['action'] == 'update_member') {
    $mb_id = sql_real_escape_string($_POST['mb_id']);
    $mb_name = sql_real_escape_string($_POST['mb_name']);
    $mb_email = sql_real_escape_string($_POST['mb_email']);
    $mb_level = (int)$_POST['mb_level'];

    $sql_password = "";
    if (trim($_POST['mb_password'])) {
        $mb_password = get_encrypt_string($_POST['mb_password']);
        $sql_password = " , mb_password = '$mb_password' ";
    }

    $sql = " UPDATE {$g5['member_table']}
                SET mb_name = '$mb_name',
                    mb_email = '$mb_email',
                    mb_level = '$mb_level'
                    $sql_password
                WHERE mb_id = '$mb_id' ";

    sql_query($sql);
    alert_toast('회원 정보가 수정되었습니다.', './member_manager.php');
}



// 검색어 받기
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// 기본 쿼리
$sql = "SELECT * FROM g5_member WHERE 1=1";

// 검색어가 있을 경우 WHERE 조건 추가
if ($search) {
    $search_escaped = sql_real_escape_string($search);
    $sql .= " AND (mb_id LIKE '%{$search_escaped}%' OR mb_name LIKE '%{$search_escaped}%')";
}

$sql .= " ORDER BY mb_datetime DESC";
$result = sql_query($sql);
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>회원 관리 - NEW ADM</title>

    <style>
        #admin_wrapper {
            display: grid;
            grid-template-columns: 280px 1fr;
            min-height: 100vh;
        }

        .content_area {
            background-color: var(--bg-soft);
            padding: var(--sp-40);
        }

        .card_custom {
            background: white;
            border-radius: 24px;
            padding: var(--sp-32);
            margin-bottom: 24px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.03);
        }

        .mb-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--bg-soft);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            color: var(--main-color);
        }

        /* 부트스트랩 충돌 방지 */
        a {
            text-decoration: none;
        }
    </style>
</head>

<body>

    <div id="admin_wrapper">
          <?php include_once('../aside.php'); ?>

        <main class="content_area">
            <div class="d-flex justify-content-between align-items-center u-mb-32">
                <h2 class="t-fs-32 fw-900">👥 회원 관리</h2>
                <form method="get" class="d-flex u-gap-12">
                    <input type="text" name="search" class="u-input u-p-4 rounded-8" placeholder="아이디, 이름 검색..." style="width:300px;" value="<?= htmlspecialchars($search) ?>">
                    <button type="submit" class="u-bg-main u-txt-white u-px-24 u-py-8 rounded-4 fw-700 u-press u-bc-main u-btn">검색</button>
                    <?php if ($search) { ?>
                        <button type="button" onclick="location.href='<?= strtok($_SERVER['REQUEST_URI'], '?') ?>'" class="u-px-24 u-py-8 u-btn-gray u-txt-muted fw-700 rounded-4">초기화</button>
                    <?php } ?>
                </form>
            </div>

            <section class="card_custom table-responsive">
                <?php if ($search) { ?>
                    <div class="u-px-20 u-py-12 u-bg-soft rounded-4 u-mb-16">
                        <span class="fw-700">검색결과:</span> "<?= htmlspecialchars($search) ?>" -
                        <span class="u-txt-main fw-700"><?= sql_num_rows($result) ?>건</span>
                    </div>
                <?php } ?>

                <table style="width:100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fafafa; border-bottom: 1px solid #eee;">
                            <th class="u-px-20 u-py-10 c-fs-16 fw-600 text-left" width="150">회원정보</th>
                            <th class="u-px-20 u-py-10 c-fs-16 fw-600 text-left">아이디</th>
                            <th class="u-px-20 u-py-10 c-fs-16 fw-600 text-center" width="120">권한</th>
                            <th class="u-px-20 u-py-10 c-fs-16 fw-600 text-center" width="200">가입일</th>
                            <th class="u-px-20 u-py-10 c-fs-16 fw-600 text-center" width="200">관리</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (sql_num_rows($result) > 0) {
                            for ($i = 0; $row = sql_fetch_array($result); $i++) {
                        ?>
                                <tr style="border-bottom: 1px solid var(--bg-soft);">
                                    <td class="u-px-20 u-py-16">
                                        <div class="d-flex align-items-center u-gap-12">
                                            <div class="mb-avatar"><?= mb_substr($row['mb_name'], 0, 1) ?></div>
                                            <div>
                                                <div class="fw-700 t-fs-16"><?= $row['mb_name'] ?></div>
                                                <div class="c-fs-12 u-txt-muted"><?= $row['mb_email'] ?></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="u-px-20 u-py-16"><code><?= $row['mb_id'] ?></code></td>
                                    <td class="u-px-20 u-py-16 text-center">
                                        <span class="u-bg-soft u-txt-main u-px-8 u-py-4 rounded-8 fw-700 c-fs-12">Lv.<?= $row['mb_level'] ?></span>
                                    </td>
                                    <td class="u-px-20 u-py-16 text-center u-txt-muted c-fs-14"><?= substr($row['mb_datetime'], 0, 10) ?></td>
                                    <td class="u-px-20 u-py-16 text-center">
                                        <div class="d-flex u-gap-8 justify-content-center">
                                            <button type="button" onclick='openEditModal(<?= json_encode($row) ?>)' class="u-btn-main u-txt-white fw-600 c-fs-14 u-press u-btn u-px-16 u-py-8 rounded-4">수정</button>
                                            <button onclick="if(confirm('탈퇴 처리하시겠습니까?')) location.href='?leave_id=<?= $row['mb_id'] ?><?= $search ? '&search=' . urlencode($search) : '' ?>'" class="u-btn u-px-16 u-py-8 u-btn-gray u-bc-gray-100 u-txt-accent fw-700 c-fs-14 u-press rounded-4">탈퇴</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td colspan="5" class="u-px-20 u-py-32 text-center u-txt-muted">
                                    <?= $search ? '검색 결과가 없습니다.' : '등록된 회원이 없습니다.' ?>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </section>

            <div class="w-100 d-flex justify-content-end u-mb-16">
                <button onclick="openAddModal()" class="u-bg-main u-txt-white u-px-24 u-py-12 rounded-4 fw-700 u-press u-btn">+ 회원 추가</button>
            </div>
        </main>
    </div>

    <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0" style="border-radius: 24px; overflow: hidden;">
                <div class="modal-header u-px-32 u-pt-32 border-0">
                    <h5 class="modal-title t-fs-24 fw-800" id="addMemberModalLabel">👤 새 회원 등록</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post">
                    <input type="hidden" name="action" value="add_member">
                    <div class="modal-body u-px-32">
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">아이디</label>
                            <input type="text" name="mb_id" class="u-input w-full rounded-8 u-px-8 u-py-4" placeholder="아이디 입력" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">비밀번호</label>
                            <input type="password" name="mb_password" class="u-input w-full rounded-8 u-px-8 u-py-4" placeholder="비밀번호 입력" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">이름</label>
                            <input type="text" name="mb_name" class="u-input w-full rounded-8 u-px-8 u-py-4" placeholder="실명 입력" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">이메일</label>
                            <input type="email" name="mb_email" class="u-input w-full rounded-8 u-px-8 u-py-4" placeholder="email@example.com" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">권한 레벨</label>
                            <select name="mb_level" class="u-input w-full rounded-8">
                                <?php for ($i = 2; $i <= 10; $i++): ?>
                                    <option value="<?= $i ?>" <?= $i == 2 ? 'selected' : '' ?>>Level <?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer u-px-32 u-pb-32 border-0 d-flex u-gap-12">
                        <button type="button" class="u-btn u-btn-gray flex-grow-1 u-py-12 rounded-8 fw-600 u-bd-1 u-bc-gray-500" data-bs-dismiss="modal">취소</button>
                        <button type="submit" class="u-btn flex-grow-1 u-bd-1 u-bc-main u-py-12 rounded-8 fw-700" style="background-color: var(--main-color); color: white;">등록하기</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editMemberModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0" style="border-radius: 24px; overflow: hidden;">
                <div class="modal-header u-px-32 u-pt-32 border-0">
                    <h5 class="modal-title t-fs-24 fw-800">📝 회원 정보 수정</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post">
                    <input type="hidden" name="action" value="update_member">
                    <input type="hidden" name="mb_id" id="edit_mb_id">
                    <div class="modal-body u-px-32">
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">아이디</label>
                            <input type="text" id="display_mb_id" class="u-input w-full rounded-8 u-px-8 u-py-4" disabled style="background:#f0f0f0;">
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">이름</label>
                            <input type="text" name="mb_name" id="edit_mb_name" class="u-input w-full rounded-8 u-px-8 u-py-4" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">이메일</label>
                            <input type="email" name="mb_email" id="edit_mb_email" class="u-input w-full rounded-8 u-px-8 u-py-4" required>
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">비밀번호 (변경 시에만 입력)</label>
                            <input type="password" name="mb_password" class="u-input w-full rounded-8 u-px-8 u-py-4" placeholder="미입력 시 기존 비밀번호 유지">
                        </div>
                        <div class="u-mb-16">
                            <label class="fw-700 c-fs-14 d-block u-mb-8">권한 레벨</label>
                            <select name="mb_level" id="edit_mb_level" class="u-input w-full rounded-8">
                                <?php for ($i = 2; $i <= 10; $i++): ?>
                                    <option value="<?= $i ?>">Level <?= $i ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer u-px-32 u-pb-32 border-0 d-flex u-gap-12">
                        <button type="button" class="u-btn u-btn-gray flex-grow-1 u-py-12 rounded-8" data-bs-dismiss="modal">취소</button>
                        <button type="submit" class="u-btn flex-grow-1 u-py-12 rounded-8 fw-700" style="background-color: var(--main-color); color: white;">수정완료</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function openAddModal() {
            const addModal = new bootstrap.Modal(document.getElementById('addMemberModal'));
            addModal.show();
        }

        function openEditModal(data) {
            // 폼 필드에 데이터 채우기
            document.getElementById('edit_mb_id').value = data.mb_id;
            document.getElementById('display_mb_id').value = data.mb_id; // 화면 표시용(비활성)
            document.getElementById('edit_mb_name').value = data.mb_name;
            document.getElementById('edit_mb_email').value = data.mb_email;
            document.getElementById('edit_mb_level').value = data.mb_level;

            // 모달 띄우기
            const editModal = new bootstrap.Modal(document.getElementById('editMemberModal'));
            editModal.show();
        }
    </script>
</body>

</html>