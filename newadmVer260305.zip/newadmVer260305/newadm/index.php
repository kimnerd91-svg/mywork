<?php
// include_once('../common.php');
include_once('./_common.php');
include_once('../head_sub.php');
// include_once('./_auth_check.php');

// GA 측정 ID 가져오기
$dm_conf = sql_fetch("SELECT cf_ga_id FROM dm_config WHERE cf_id = 1");
$ga_id = $dm_conf['cf_ga_id'] ?? '';

// Property ID 추출 (G-XXXXXXXXXX에서 숫자 부분)
// 실제로는 GA4 Admin API로 가져와야 하지만, 일단 링크만 제공
$property_id = '';

// 세션 시작 (없으면)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 관리자 정보 로드
if (isset($_SESSION['admin_id'])) {
    $admin = sql_fetch("SELECT mb_name, mb_level FROM g5_member WHERE mb_id = '{$_SESSION['admin_id']}'");
}

// 세션이 없으면 기본값
if (!$admin) {
    $admin = array(
        'mb_name' => '관리자',
        'mb_level' => 10
    );
}

// --- 1. 기본 통계 (방문자 수 및 증감) ---
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime("-1 days"));

// 오늘 방문자
$visit_today = sql_fetch(" SELECT vi_count as cnt FROM {$g5['visit_sum_table']} WHERE vi_date = '{$today}' ");
$count_visit_today = (int)$visit_today['cnt'];

// 어제 방문자
$visit_yesterday = sql_fetch(" SELECT vi_count as cnt FROM {$g5['visit_sum_table']} WHERE vi_date = '{$yesterday}' ");
$count_visit_yesterday = (int)$visit_yesterday['cnt'];

// 전체 누적
$visit_total = sql_fetch(" SELECT SUM(vi_count) as cnt FROM {$g5['visit_sum_table']} ");
$count_visit_total = (int)$visit_total['cnt'];

// 어제 대비 증감 계산
$diff = $count_visit_today - $count_visit_yesterday;
$diff_text = ($diff >= 0) ? "+" . number_format($diff) : number_format($diff);
$diff_color = ($diff >= 0) ? "u-txt-main" : "u-txt-red";

// --- 2. 환경 및 경로 정밀 분석 ---
$sql_visit = " SELECT vi_agent, vi_referer FROM {$g5['visit_table']} WHERE vi_date = '{$today}' ";
$res_visit = sql_query($sql_visit);

$stats = [
    'path'    => ['Organic' => 0, 'Referral' => 0, 'Direct' => 0],
    'PC'      => ['Chrome' => 0, 'Whale' => 0, 'Edge' => 0, 'Safari' => 0, 'Etc' => 0],
    'Mobile'  => ['Chrome' => 0, 'Whale' => 0, 'Safari' => 0, 'Samsung' => 0, 'Etc' => 0]
];

while ($row = sql_fetch_array($res_visit)) {
    $agent = $row['vi_agent'];
    $ref = trim($row['vi_referer']);

    // 기기 판별
    $device = preg_match('/(iPhone|Android|BlackBerry|Phone)/i', $agent) ? 'Mobile' : 'PC';

    // 기기별 브라우저 판별
    if (stripos($agent, 'Whale') !== false) $stats[$device]['Whale']++;
    else if (stripos($agent, 'Edg') !== false) $stats[$device]['Edge']++;
    else if (stripos($agent, 'SamsungBrowser') !== false) $stats[$device]['Samsung']++;
    else if (stripos($agent, 'Chrome') !== false) $stats[$device]['Chrome']++;
    else if (stripos($agent, 'Safari') !== false) $stats[$device]['Safari']++;
    else $stats[$device]['Etc']++;

    // 유입 채널 정밀 분류
    if (!$ref) {
        $stats['path']['Direct']++;
    } else if (preg_match('/(naver\.com|google\.|daum\.net|bing\.com|zum\.com)/i', $ref)) {
        $stats['path']['Organic']++;
    } else {
        $stats['path']['Referral']++;
    }
}

// 통계 데이터 가져오기
$count_board = sql_fetch(" SELECT count(*) as cnt FROM {$g5['board_table']} ");
$count_member = sql_fetch(" SELECT count(*) as cnt FROM {$g5['member_table']} ");
$count_write = ['cnt' => 0];

$board_list = sql_query(" SELECT bo_table FROM {$g5['board_table']} ");
$write_count = 0;

while ($board = sql_fetch_array($board_list)) {
    $write_table = $g5['write_prefix'] . $board['bo_table'];
    $check_table = sql_query("SHOW TABLES LIKE '{$write_table}'");
    if (sql_num_rows($check_table) > 0) {
        $temp = sql_fetch("SELECT COUNT(*) as cnt FROM {$write_table} WHERE wr_is_comment = 0");
        $write_count += (int)($temp['cnt'] ?? 0);
    }
}

$count_write['cnt'] = $write_count;
$count_popup = sql_fetch(" SELECT count(*) as cnt FROM dm_popup WHERE nw_status = 1 ");
?>
<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <title>NEW ADM - 대시보드</title>
    <link rel="stylesheet" href="/css/setting.css">
    <link rel="stylesheet" href="/css/base_core.css">
    <!-- <link rel="stylesheet" href="../css/newadmin.css"> -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>

<body>

    <div id="admin_wrapper">
        <?php include_once('./aside.php'); ?>

        <main class="content_area">
            <div class="g-cols-fit-12 u-mb-32">
                <h2 class="t-fs-28 fw-900 g-v-center u-mb-0">👋 환영합니다, <?= $admin['mb_name'] ?>님!</h2>
                <a target="_blank" href="./howtouse.pdf" class="u-btn rounded-8 u-btn-main g-self-end u-gap-8"><span class="material-symbols-outlined">menu_book</span>사용설명서</a>
            </div>


            <div class="g-cols-fit-10 u-gap-24 u-mb-40">
                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main">
                        <span class="material-symbols-outlined">group</span>
                    </div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">전체 회원</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_member['cnt']) ?></h4>
                    </div>
                </div>

                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main">
                        <span class="material-symbols-outlined">article</span>
                    </div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">전체 게시물</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_write['cnt']) ?></h4>
                    </div>
                </div>

                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main">
                        <span class="material-symbols-outlined">dashboard_customize</span>
                    </div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">생성된 게시판</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_board['cnt']) ?></h4>
                    </div>
                </div>

                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main">
                        <span class="material-symbols-outlined">campaign</span>
                    </div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">진행중인 팝업</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_popup['cnt']) ?></h4>
                    </div>
                </div>
            </div>

            <section class="card_custom">
                <h3 class="t-fs-24 fw-800 u-mb-24">🚀 빠른 바로가기</h3>
                <div class="g-cols-fit-10 u-gap-20">
                    <a href="/newadm/config/site_config.php" class="quick-link">
                        <span class="material-symbols-outlined">settings</span>
                        <span>기본정보 관리</span>
                    </a>
                    <a href="/newadm/content/popup_manager.php" class="quick-link">
                        <span class="material-symbols-outlined">campaign</span>
                        <span>팝업 관리</span>
                    </a>
                    <a href="/newadm/member/member_manager.php" class="quick-link">
                        <span class="material-symbols-outlined">group</span>
                        <span>회원 관리</span>
                    </a>
                    <a href="/newadm/board/board_manager.php" class="quick-link">
                        <span class="material-symbols-outlined">article</span>
                        <span>게시물 관리</span>
                    </a>
                </div>
            </section>

            <div class="g-cols-fit-10 u-gap-24 u-mb-40">
                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main"><span class="material-symbols-outlined">trending_up</span></div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">오늘 방문 <span class="<?= $diff_color ?> fw-700" style="font-size:11px;">(<?= $diff_text ?>)</span></p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_visit_today) ?></h4>
                    </div>
                </div>
                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-gray-500"><span class="material-symbols-outlined">history</span></div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">어제 방문</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_visit_yesterday) ?></h4>
                    </div>
                </div>
                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white u-txt-main"><span class="material-symbols-outlined">analytics</span></div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">누적 방문</p>
                        <h4 class="t-fs-24 fw-900 m-0"><?= number_format($count_visit_total) ?></h4>
                    </div>
                </div>
                <div class="stat-card shadow-soft">
                    <div class="stat-icon u-bg-white <?= ($diff >= 0) ? 'u-txt-main' : 'u-txt-red' ?>">
                        <span class="material-symbols-outlined"><?= ($diff >= 0) ? 'trending_up' : 'trending_down' ?></span>
                    </div>
                    <div>
                        <p class="u-txt-dark c-fs-14 m-0">어제 대비 증감</p>
                        <h4 class="t-fs-24 fw-900 m-0 <?= $diff_color ?>"><?= $diff_text ?> 명</h4>
                    </div>
                </div>
            </div>

            <section class="card_custom u-mt-40 ">
                <h3 class="t-fs-24 fw-800 u-mb-32">📊 유입 경로 및 디바이스 상세 분석</h3>
                <div class="g-cols-fit-10">
                    <div class="g-cols-fit-10 u-gap-32">
                        <div class="analysis-box">
                            <p class="fw-700 u-mb-20 u-txt-main">🌐 유입 경로 (Today)</p>
                            <?php
                            $current_path_total = array_sum($stats['path']);
                            foreach ($stats['path'] as $name => $val):
                                $per = ($current_path_total > 0) ? round(($val / $current_path_total) * 100) : 0;
                            ?>
                                <div class="u-mb-16">
                                    <div class="d-flex justify-content-between c-fs-13 u-mb-6">
                                        <span><?= $name ?></span>
                                        <span><?= $val ?>명 (<?= $per ?>%)</span>
                                    </div>
                                    <div class="bar-bg">
                                        <div class="bar-fill" style="width:<?= $per ?>%; background:#333;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="analysis-box">
                            <p class="fw-700 u-mb-20">💻 PC 브라우저</p>
                            <?php
                            $pc_total = array_sum($stats['PC']);
                            foreach ($stats['PC'] as $name => $val):
                                $per = ($pc_total > 0) ? round(($val / $pc_total) * 100) : 0; ?>
                                <div class="u-mb-12">
                                    <div class="d-flex justify-content-between c-fs-12 u-mb-4"><span><?= $name ?></span><span><?= $val ?>건</span></div>
                                    <div class="bar-bg" style="height:4px;">
                                        <div class="bar-fill u-bg-main" style="width:<?= $per ?>%"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="analysis-box">
                            <p class="fw-700 u-mb-20">📱 모바일 브라우저</p>
                            <?php
                            $mo_total = array_sum($stats['Mobile']);
                            foreach ($stats['Mobile'] as $name => $val):
                                $per = ($mo_total > 0) ? round(($val / $mo_total) * 100) : 0; ?>
                                <div class="u-mb-12">
                                    <div class="d-flex justify-content-between c-fs-12 u-mb-4"><span><?= $name ?></span><span><?= $val ?>건</span></div>
                                    <div class="bar-bg" style="height:4px;">
                                        <div class="bar-fill" style="width:<?= $per ?>%; background:#ff9800;"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

            </section>

            <?php if ($ga_id): ?>
                <section class="card_custom u-mt-40">
                    <h3 class="t-fs-24 fw-800 u-mb-24">📈 Google Analytics 대시보드</h3>

                    <div class="g-cols-fit-10 u-gap-20 u-mb-24">
                        <a href="https://analytics.google.com"
                            target="_blank" class="u-btn u-btn-main rounded-8 u-gap-8">
                            <span class="material-symbols-outlined">bar_chart</span>
                            GA4 대시보드 열기
                        </a>
                        <a href="https://tagmanager.google.com"
                            target="_blank" class="u-btn u-btn-info rounded-8 u-gap-8">
                            <span class="material-symbols-outlined">sell</span>
                            태그 관리자
                        </a>
                        <a href="https://search.google.com/search-console"
                            target="_blank" class="u-btn u-btn-outline rounded-8 u-gap-8">
                            <span class="material-symbols-outlined">search</span>
                            Search Console
                        </a>
                    </div>

                    <div class="u-bg-white u-p-24 rounded-12">
                        <p class="u-txt-dark c-fs-13 u-mb-12">
                            <span class="material-symbols-black v-middle" style="font-size: 18px;">info</span>
                            현재 설치된 GA 측정 ID: <strong class="u-txt-main"><?= $ga_id ?></strong>
                        </p>
                        <p class="u-txt-dark c-fs-13 m-0">
                            <span class="material-symbols-outlined v-middle" style="font-size: 18px;">lightbulb</span>
                            실시간 데이터를 보려면 위 버튼을 클릭해 Google Analytics로 이동하세요.
                        </p>
                    </div>

                    <!-- Looker Studio 리포트 임베드 (옵션) -->
                    <!-- 
                <div class="u-mt-24">
                    <iframe width="100%" height="600" 
                        src="YOUR_LOOKER_STUDIO_EMBED_URL" 
                        frameborder="0" 
                        style="border-radius: 12px; border: 1px solid #e0e0e0;"
                        allowfullscreen>
                    </iframe>
                </div>
                -->
                </section>
            <?php endif; ?>

            <section class="card_custom u-mt-40">
                <h3 class="t-fs-24 fw-800 u-mb-24">📊 네이버 애널리틱스</h3>

                <div class="g-cols-fit-10 u-gap-20 u-mb-24">
                    <a href="https://analytics.naver.com"
                        target="_blank" class="u-btn rounded-8 u-gap-8"
                        style="background: #03C75A; color: white;">
                        <span class="material-symbols-outlined">analytics</span>
                        네이버 애널리틱스 열기
                    </a>
                    <a href="https://searchadvisor.naver.com"
                        target="_blank" class="u-btn u-btn-info rounded-8 u-gap-8">
                        <span class="material-symbols-outlined">search</span>
                        서치어드바이저
                    </a>
                    <a href="https://webmastertool.naver.com"
                        target="_blank" class="u-btn u-btn-outline rounded-8 u-gap-8">
                        <span class="material-symbols-outlined">settings</span>
                        웹마스터도구
                    </a>
                </div>

                <div class="u-bg-white u-p-24 rounded-12">
                    <p class="u-txt-dark c-fs-13 u-mb-12">
                        <span class="material-symbols-black v-middle" style="font-size: 18px;">info</span>
                        네이버 애널리틱스로 실시간 방문자, 유입 경로, 페이지뷰 등을 확인하세요.
                    </p>
                    <p class="u-txt-dark c-fs-13 m-0">
                        <span class="material-symbols-outlined v-middle" style="font-size: 18px;">lightbulb</span>
                        서치어드바이저에서 네이버 검색 노출 키워드를 분석할 수 있습니다.
                    </p>
                </div>
            </section>


            <section class="card_custom u-mt-40 g-cols-fit-10">
                <h3 class="t-fs-24 fw-800 g-v-center">📊 최근 활동</h3>
                <div class="u-txt-dark">
                    <p class="u-mb-8">• 최근 로그인: <?= date('Y-m-d H:i:s') ?></p>
                    <p class="u-mb-8">• 관리자 레벨: Level <?= $admin['mb_level'] ?></p>
                    <p class="u-mb-8">• 시스템 상태: <span class="u-txt-main fw-700">정상 운영중</span></p>
                </div>
            </section>
        </main>
    </div>

    <style>
        .stat-card {
            background: #fff;
            padding: 24px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            gap: 20px;
            transition: all 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.1) !important;
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .stat-icon .material-symbols-outlined {
            font-size: 32px;
        }

        .quick-link {
            background: var(--bg-soft);
            padding: 20px;
            border-radius: 12px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            color: var(--t-color);
            transition: all 0.3s;
        }

        .quick-link:hover {
            background: var(--main-color);
            color: #fff;
            transform: translateY(-2px);
        }

        .quick-link .material-symbols-outlined {
            font-size: 36px;
        }

        .quick-link span:last-child {
            font-weight: 600;
            font-size: 14px;
        }

        .analysis-box {
            background: #fff;
            padding: 24px;
            border-radius: 20px;
            border: 1px solid #eee;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
        }

        .bar-bg {
            background: #f0f0f0;
            height: 6px;
            border-radius: 10px;
            overflow: hidden;
        }

        .bar-fill {
            height: 100%;
            transition: width 0.8s ease-in-out;
        }

        .u-txt-red {
            color: #ff4d4f !important;
        }

        .v-middle {
            vertical-align: middle;
            margin-right: 4px;
        }
    </style>

</body>

</html>