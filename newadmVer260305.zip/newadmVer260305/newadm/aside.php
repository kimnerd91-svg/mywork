<?php 
include_once(G5_PATH . '/head_sub.php');

$admin_root = '/newadm';
$current_full_path = $_SERVER['SCRIPT_NAME'];

// ✨ 배너 및 팝업 만료 체크
function check_expiring_content() {
    $now = time();
    $alerts = [];
    
    // 1. 팝업 만료 체크
    $popup_query = "
        SELECT nw_id, nw_subject, nw_end_time, nw_status
        FROM dm_popup 
        WHERE nw_status = 1 
        AND nw_end_time != '0000-00-00 00:00:00'
        AND nw_end_time > NOW()
        ORDER BY nw_end_time ASC
    ";
    
    $popup_result = @sql_query($popup_query);
    if ($popup_result) {
        while ($popup = sql_fetch_array($popup_result)) {
            $end_time = strtotime($popup['nw_end_time']);
            $time_left = $end_time - $now;
            $days_left = floor($time_left / 86400);
            $hours_left = floor($time_left / 3600);
            
            if ($time_left > 0 && $time_left <= 259200) { // 3일(259200초) 이하
                $alerts[] = [
                    'type' => 'popup',
                    'id' => $popup['nw_id'],
                    'title' => $popup['nw_subject'],
                    'end_time' => $popup['nw_end_time'],
                    'time_left' => $time_left,
                    'days_left' => $days_left,
                    'hours_left' => $hours_left,
                    'urgency' => $hours_left <= 24 ? 'critical' : 'warning'
                ];
            }
        }
    }
    
    // 2. 배너 만료 체크
    $banner_query = "SELECT id, name, images FROM mainbanner";
    $banner_result = @sql_query($banner_query);
    
    if ($banner_result) {
        while ($banner = sql_fetch_array($banner_result)) {
            if (!$banner['images']) continue;
            
            $images = json_decode($banner['images'], true);
            if (!is_array($images)) continue;
            
            foreach ($images as $idx => $img) {
                if (!isset($img['visible']) || !$img['visible']) continue;
                if (!isset($img['end_date']) || !$img['end_date']) continue;
                
                $end_time = strtotime($img['end_date'] . ' 23:59:59');
                $time_left = $end_time - $now;
                $days_left = floor($time_left / 86400);
                $hours_left = floor($time_left / 3600);
                
                if ($time_left > 0 && $time_left <= 259200) { // 3일 이하
                    $alerts[] = [
                        'type' => 'banner',
                        'id' => $banner['id'],
                        'title' => $banner['name'] . ' (이미지 ' . ($idx + 1) . ')',
                        'end_time' => $img['end_date'],
                        'time_left' => $time_left,
                        'days_left' => $days_left,
                        'hours_left' => $hours_left,
                        'urgency' => $hours_left <= 24 ? 'critical' : 'warning'
                    ];
                }
            }
        }
    }
    
    return $alerts;
}

// 알림 체크 및 쿠키 관리
$expiring_alerts = check_expiring_content();
$should_show_alert = false;
$filtered_alerts = [];

foreach ($expiring_alerts as $alert) {
    $cookie_name = 'alert_' . $alert['type'] . '_' . $alert['id'] . '_dismiss';
    $last_shown = isset($_COOKIE[$cookie_name]) ? (int)$_COOKIE[$cookie_name] : 0;
    $now = time();
    
    // 24시간 이하: 4시간마다 (14400초)
    // 24시간 이상: 24시간마다 (86400초)
    $interval = $alert['hours_left'] <= 24 ? 14400 : 86400;
    
    if ($now - $last_shown >= $interval) {
        $should_show_alert = true;
        $filtered_alerts[] = $alert;
    }
}
?>

<aside id="adm_aside">
    <div class="brand_area d-flex u-gap-8">
        <span class="brand_logo">
            <?php if (isset($dm_conf['cf_logo']) && $dm_conf['cf_logo']) { ?>
                <img src="<?= G5_DATA_URL ?>/common/<?= $dm_conf['cf_logo'] ?>" alt="<?= $dm_conf['cf_site_name'] ?>" style="max-height:30px;">
            <?php } else { ?>
                <?= $dm_conf['cf_logo'] ?: 'LOGO' ?>
            <?php } ?>
        </span>
        <button type="button" class="toggle_btn" onclick="toggleSidebar()" title="사이드바 접기/펼치기">
            <span class="material-symbols-outlined" id="toggle_icon">menu_open</span>
        </button>
    </div>
    
    <!-- ✨ 알림 배지 -->
    <?php if (count($expiring_alerts) > 0) { ?>
    <div class="alert-badge-container" onclick="showExpiringAlerts()" style="cursor: pointer;">
        <div class="alert-badge">
            <span class="material-symbols-outlined">notifications_active</span>
            <span class="badge-text">만료 임박 알림</span>
            <span class="badge-count"><?= count($expiring_alerts) ?></span>
        </div>
    </div>
    <?php } ?>
    
    <nav class="nav_list">
        <?php
        // 메뉴 구성
        $menus = [
            ['/index.php', 'dashboard', '대시보드', [$admin_root.'/index.php']],
            
            ['/config/site_config.php', 'settings', '사이트 설정', [$admin_root.'/config/site_config.php', $admin_root.'/config/site_config_update.php']],
            
            // 콘텐츠 관리
            ['#', 'folder', '콘텐츠 관리', [], [
                ['/content/doctor_manager.php', 'medical_services', '의료진 관리', [$admin_root.'/content/doctor_manager.php']],
                ['/content/banner_manager.php', 'panorama', '배너 관리', [$admin_root.'/content/banner_manager.php', $admin_root.'/content/create_banner_table.php']],
                ['/content/popup_manager.php', 'aspect_ratio', '팝업 관리', [$admin_root.'/content/popup_manager.php', $admin_root.'/content/popup_form.php', $admin_root.'/content/popup_update.php']],
                ['/content/before_after_manager.php', 'compare_arrows', 'B/A 관리', [$admin_root.'/content/before_after_manager.php']],
                // ['/content/parallax_manager.php', 'video_template', '패럴렉스 관리', [$admin_root.'/content/parallax_manager.php']],
                 ['/content/device_manager.php', 'devices', '장비 관리', [$admin_root.'/content/device_manager.php']],
            ]],
            
            // 게시판 관리
            ['#', 'article', '게시판 관리', [], [
                ['/board/board_manager.php', 'view_list', '게시판 설정', [$admin_root.'/board/board_manager.php', $admin_root.'/board/board_create_update.php', $admin_root.'/board/board_post_list.php', $admin_root.'/board/post_manager.php', $admin_root.'/board/write_direct.php']],
                ['/board/review_manager.php', 'reviews', '리뷰 관리', [$admin_root.'/board/review_manager.php']],
                ['/board/qa_manager.php', 'help', '질문 관리', [$admin_root.'/board/qa_manager.php']],
                ['/board/faq_manager.php', 'live_help', 'FAQ 관리', [$admin_root.'/board/faq_manager.php']],
            ]],
            
            ['/member/member_manager.php', 'group', '회원 관리', [$admin_root.'/member/member_manager.php']],
            
            ['/price/non_covered_manager.php', 'payments', '비급여 관리', [$admin_root.'/price/non_covered_manager.php']],
            
            ['/backup/db_backup_manager.php', 'backup', 'DB백업 관리', [$admin_root.'/backup/db_backup_manager.php']],
        ];
        
        foreach($menus as $menu) {
            $has_submenu = isset($menu[4]) && !empty($menu[4]);
            $link_url = $menu[0] === '#' ? '#' : $admin_root . $menu[0];
            
            $active = '';
            if ($has_submenu) {
                foreach($menu[4] as $submenu) {
                    if (in_array($current_full_path, $submenu[3])) {
                        $active = 'active';
                        break;
                    }
                }
            } else {
                $active = in_array($current_full_path, $menu[3]) ? 'active' : '';
            }
            
            if ($has_submenu) {
                echo "<div class='nav-group {$active}'>
                        <a href='javascript:void(0)' class='nav-link parent' onclick='toggleSubmenu(this)' title='{$menu[2]}'>
                            <span class='material-symbols-outlined'>{$menu[1]}</span>
                            <b>{$menu[2]}</b>
                            <span class='material-symbols-outlined submenu-arrow'>expand_more</span>
                        </a>
                        <div class='submenu'>";
                
                foreach($menu[4] as $submenu) {
                    $sub_active = in_array($current_full_path, $submenu[3]) ? 'active' : '';
                    $sub_link = $admin_root . $submenu[0];
                    echo "<a href='{$sub_link}' class='nav-link sub {$sub_active}' title='{$submenu[2]}'>
                            <span class='material-symbols-outlined'>{$submenu[1]}</span>
                            <b>{$submenu[2]}</b>
                          </a>";
                }
                
                echo "</div></div>";
            } else {
                echo "<a href='{$link_url}' class='nav-link {$active}' title='{$menu[2]}'>
                        <span class='material-symbols-outlined'>{$menu[1]}</span>
                        <b>{$menu[2]}</b>
                      </a>";
            }
        }
        
        $logout_path = $admin_root . '/auth/logout.php';
        ?>
        
        <div style="margin-top: auto; padding-top: 20px; border-top: 1px solid #333;">
            <a href='<?= $logout_path ?>' class='nav-link' title='로그아웃' style='color: rgba(255,255,255,0.5) !important;'>
                <span class='material-symbols-outlined'>logout</span>
                <b>로그아웃</b>
            </a>
        </div>
    </nav>
</aside>

<!-- ✨ 만료 알림 모달 -->
<div id="expiringModal" class="expiring-modal">
    <div class="expiring-modal-content">
        <div class="expiring-modal-header">
            <h3>⏰ 만료 임박 알림</h3>
            <button class="close-btn" onclick="closeExpiringModal()">×</button>
        </div>
        <div class="expiring-modal-body">
            <p class="modal-intro">다음 콘텐츠의 노출 기한이 임박했습니다:</p>
            <div id="alertList"></div>
        </div>
        <div class="expiring-modal-footer">
            <button class="btn-dismiss" onclick="dismissAllAlerts()">모두 확인</button>
        </div>
    </div>
</div>

<style>
/* 알림 배지 */
.alert-badge-container {
    padding: 12px 20px;
    margin: 10px 15px;
    background: linear-gradient(135deg, #ff6b6b 0%, #ff5252 100%);
    border-radius: 12px;
    animation: pulse 2s infinite;
}

.alert-badge {
    display: flex;
    align-items: center;
    gap: 10px;
    color: white;
}

.alert-badge .material-symbols-outlined {
    font-size: 20px;
}

.badge-text {
    flex: 1;
    font-size: 13px;
    font-weight: 700;
}

.badge-count {
    background: rgba(255,255,255,0.3);
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 800;
}

@keyframes pulse {
    0%, 100% { box-shadow: 0 0 0 0 rgba(255, 82, 82, 0.7); }
    50% { box-shadow: 0 0 0 8px rgba(255, 82, 82, 0); }
}

/* 사이드바 접힌 상태에서 배지 숨기기 */
#adm_aside.collapsed .alert-badge-container {
    display: none;
}

/* 모달 스타일 */
.expiring-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.7);
    z-index: 10000;
    align-items: center;
    justify-content: center;
}

.expiring-modal.active {
    display: flex;
}

.expiring-modal-content {
    background: white;
    border-radius: 16px;
    width: 90%;
    max-width: 600px;
    max-height: 80vh;
    overflow: hidden;
    animation: modalSlideIn 0.3s ease-out;
}

@keyframes modalSlideIn {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.expiring-modal-header {
    padding: 24px;
    border-bottom: 2px solid #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.expiring-modal-header h3 {
    margin: 0;
    font-size: 20px;
    font-weight: 800;
}

.close-btn {
    background: none;
    border: none;
    font-size: 32px;
    cursor: pointer;
    color: #999;
    line-height: 1;
    padding: 0;
    width: 32px;
    height: 32px;
}

.close-btn:hover {
    color: #333;
}

.expiring-modal-body {
    padding: 24px;
    max-height: 60vh;
    overflow-y: auto;
}

.modal-intro {
    font-size: 14px;
    color: #666;
    margin-bottom: 16px;
}

.alert-item {
    padding: 16px;
    margin-bottom: 12px;
    border-radius: 8px;
    border: 2px solid #e0e0e0;
    transition: all 0.2s;
}

.alert-item:hover {
    border-color: #2196f3;
    box-shadow: 0 2px 8px rgba(33, 150, 243, 0.1);
}

.alert-item.critical {
    border-color: #f44336;
    background: #ffebee;
}

.alert-item.warning {
    border-color: #ff9800;
    background: #fff3e0;
}

.alert-item-header {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
}

.alert-type-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 800;
    text-transform: uppercase;
}

.alert-type-badge.popup {
    background: #2196f3;
    color: white;
}

.alert-type-badge.banner {
    background: #9c27b0;
    color: white;
}

.alert-item-title {
    flex: 1;
    font-weight: 700;
    font-size: 15px;
}

.alert-item-time {
    font-size: 13px;
    color: #666;
    margin-bottom: 8px;
}

.alert-item-urgency {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 800;
}

.alert-item-urgency.critical {
    background: #f44336;
    color: white;
}

.alert-item-urgency.warning {
    background: #ff9800;
    color: white;
}

.expiring-modal-footer {
    padding: 16px 24px;
    border-top: 2px solid #f5f5f5;
    text-align: center;
}

.btn-dismiss {
    padding: 12px 32px;
    background: #2196f3;
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
}

.btn-dismiss:hover {
    background: #1976d2;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(33, 150, 243, 0.3);
}

.nav-group {
    position: relative;
}

.nav-link.parent {
    position: relative;
}

.submenu-arrow {
    position: absolute;
    right: 15px;
    transition: transform 0.3s ease;
    font-size: 20px !important;
}

.submenu {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
    background: rgba(0,0,0,0.2);
}

.nav-link.sub {
    padding-left: 60px !important;
    font-size: 14px;
}

.nav-link.sub .material-symbols-outlined {
    font-size: 18px;
}

#adm_aside.collapsed .submenu-arrow {
    display: none;
}

#adm_aside.collapsed .submenu {
    display: none;
}
</style>

<script>
// PHP에서 알림 데이터 전달
const expiringAlerts = <?= json_encode($filtered_alerts) ?>;
const allAlerts = <?= json_encode($expiring_alerts) ?>;

function toggleSubmenu(element) {
    const parent = element.closest('.nav-group');
    const submenu = parent.querySelector('.submenu');
    const arrow = element.querySelector('.submenu-arrow');
    
    parent.classList.toggle('open');
    
    if (parent.classList.contains('open')) {
        submenu.style.maxHeight = submenu.scrollHeight + 'px';
        arrow.style.transform = 'rotate(180deg)';
    } else {
        submenu.style.maxHeight = '0';
        arrow.style.transform = 'rotate(0deg)';
    }
}

function toggleSidebar() {
    const aside = document.getElementById('adm_aside');
    const icon = document.getElementById('toggle_icon');
    
    aside.classList.toggle('collapsed');
    
    const isCollapsed = aside.classList.contains('collapsed');
    icon.innerText = isCollapsed ? 'menu' : 'menu_open';
    localStorage.setItem('sidebar_collapsed', isCollapsed ? 'true' : 'false');
}

function showExpiringAlerts() {
    const modal = document.getElementById('expiringModal');
    const alertList = document.getElementById('alertList');
    
    alertList.innerHTML = '';
    
    allAlerts.forEach(alert => {
        const timeText = alert.hours_left <= 24 
            ? `${alert.hours_left}시간 ${Math.floor((alert.time_left % 3600) / 60)}분 남음`
            : `${alert.days_left}일 ${Math.floor((alert.time_left % 86400) / 3600)}시간 남음`;
        
        const urgencyText = alert.urgency === 'critical' ? '긴급' : '주의';
        
        alertList.innerHTML += `
            <div class="alert-item ${alert.urgency}">
                <div class="alert-item-header">
                    <span class="alert-type-badge ${alert.type}">${alert.type === 'popup' ? '팝업' : '배너'}</span>
                    <span class="alert-item-title">${alert.title}</span>
                </div>
                <div class="alert-item-time">종료: ${alert.end_time}</div>
                <span class="alert-item-urgency ${alert.urgency}">${urgencyText} - ${timeText}</span>
            </div>
        `;
    });
    
    modal.classList.add('active');
}

function closeExpiringModal() {
    const modal = document.getElementById('expiringModal');
    modal.classList.remove('active');
}

function dismissAllAlerts() {
    // 모든 알림에 대해 쿠키 설정
    allAlerts.forEach(alert => {
        const cookieName = 'alert_' + alert.type + '_' + alert.id + '_dismiss';
        const expires = new Date();
        expires.setTime(expires.getTime() + (alert.hours_left <= 24 ? 14400000 : 86400000)); // 4시간 또는 24시간
        document.cookie = cookieName + '=' + Date.now() + ';expires=' + expires.toUTCString() + ';path=/';
    });
    
    closeExpiringModal();
    
    // 배지 숨기기
    const badgeContainer = document.querySelector('.alert-badge-container');
    if (badgeContainer) {
        badgeContainer.style.display = 'none';
    }
}

// 페이지 로드 시 active 메뉴의 부모 자동 열기 및 알림 자동 표시
(function() {
    const aside = document.getElementById('adm_aside');
    const icon = document.getElementById('toggle_icon');
    
    if (localStorage.getItem('sidebar_collapsed') === 'true') {
        aside.classList.add('collapsed');
        icon.innerText = 'menu';
    }
    
    const activeGroups = document.querySelectorAll('.nav-group.active');
    activeGroups.forEach(group => {
        group.classList.add('open');
        const submenu = group.querySelector('.submenu');
        const arrow = group.querySelector('.submenu-arrow');
        if (submenu) {
            submenu.style.maxHeight = submenu.scrollHeight + 'px';
            arrow.style.transform = 'rotate(180deg)';
        }
    });
    
    // ✨ 알림이 있고 표시해야 할 알림이 있으면 자동으로 모달 표시
    if (expiringAlerts.length > 0) {
        setTimeout(() => {
            showExpiringAlerts();
        }, 500);
    }
})();

// 모달 외부 클릭 시 닫기
document.getElementById('expiringModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeExpiringModal();
    }
});
</script>