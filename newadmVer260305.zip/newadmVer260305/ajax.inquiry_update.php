<?php
include_once('./_common.php');
header('Content-Type: application/json');

$name    = isset($_POST['wr_name']) ? clean_xss_tags(trim($_POST['wr_name'])) : '';
$tel     = isset($_POST['wr_1']) ? clean_xss_tags(trim($_POST['wr_1'])) : '';
$type    = isset($_POST['inquiry_type']) ? clean_xss_tags($_POST['inquiry_type']) : '';
$content = isset($_POST['wr_content']) ? clean_xss_tags($_POST['wr_content']) : '';

// 수신 동의 정보 처리
$agree_sms = isset($_POST['agree_sms']) ? 'Y' : 'N';
$agree_kakao = isset($_POST['agree_kakao']) ? 'Y' : 'N';
$agree_status = "SMS:{$agree_sms} / KAKAO:{$agree_kakao}";

$cate_map = ['A'=>'교정', 'B'=>'임플란트', 'C'=>'일반', 'D'=>'비용', 'E'=>'기타'];
$ca_name = isset($cate_map[$type]) ? $cate_map[$type] : '일반문의';

if (!$name || !$tel) {
    echo json_encode(['res' => 'fail', 'msg' => '필수 항목을 입력해주세요.']);
    exit;
}

$bo_table = "qa";
$write_table = $g5['write_prefix'] . $bo_table;

// 데이터 삽입 (wr_2 필드에 수신동의 저장)
$sql = " INSERT INTO {$write_table}
            SET ca_name = '$ca_name',
                wr_name = '$name',
                wr_1 = '$tel',
                wr_2 = '$agree_status', 
                wr_content = '$content',
                wr_datetime = '".G5_TIME_YMDHIS."',
                wr_ip = '{$_SERVER['REMOTE_ADDR']}' ";

if(sql_query($sql)) {
    echo json_encode(['res' => 'success']);
} else {
    echo json_encode(['res' => 'fail', 'msg' => 'DB 저장 중 오류가 발생했습니다.']);
}