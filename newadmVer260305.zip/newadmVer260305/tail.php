<?php
if (!defined('_GNUBOARD_')) exit;

// 데이터 로드
$conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
$non_covered_file = G5_DATA_PATH . '/content/non_covered.json';
$non_covered = [];

if (file_exists($non_covered_file)) {
    $decoded_data = json_decode(file_get_contents($non_covered_file), true);
    if (is_array($decoded_data)) {
        $non_covered = $decoded_data;
    }
}
?>

<!-- 푸터 -->
<footer
    class="footer u-bg-light u-pretendard u-px-0-sm u-pt-80 u-pb-60 "
    id="footer02">
    <div class="u-fluid u-fluid-xl-sm">
        <div class="g-cols-fill-3 g-cols-fill-1-sm u-mb-64 u-gap-40-sm g-cols-fit-8-sm">
            <!-- 진료시간 -->
            <div class="col-12">
                <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-dark">
                    진료시간
                </h5>
                <ul class="footer-list u-mb-20">
                    <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                        <div class="col-3" style="letter-spacing: -2px">
                            월 / 수 / 금
                        </div>
                        <p class="c-fs-20 u-lh-175 u-txt-dark u-mb-0">
                            <span class="u-txt-sub">AM</span> 09:30 ~
                            <span class="u-txt-sub">PM</span> 06:30
                        </p>
                    </li>
                    <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                        <div class="col-3">화 / 목</div>
                        <div class="d-flex u-gap-8">
                            <p class="c-fs-20 u-lh-175 u-txt-dark u-mb-0 flex-wrap">
                                <span class="u-txt-sub">AM</span> 09:30 ~
                                <span class="u-txt-sub">PM</span> 08:30
                            </p>
                            <span
                                class="badge u-bg-sub d-flex justify-content-center align-items-center rounded-full t-fs-18 u-txt-WHITE u-py-4 u-px-10">야간진료</span>
                        </div>
                    </li>
                    <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                        <div class="col-3">토요일</div>
                        <p class="c-fs-20 u-lh-175 u-txt-dark u-mb-0">
                            <span class="u-txt-sub">AM</span> 09:00 ~
                            <span class="u-txt-sub">PM</span> 02:00
                        </p>
                    </li>
                    <li class="d-flex u-gap-36 c-fs-20 u-lh-175 u-txt-dark">
                        <div class="col-3">점심시간</div>
                        <p class="c-fs-20 u-lh-175 u-txt-dark u-mb-0">
                            <span class="u-txt-sub">PM</span> 01:00 ~
                            <span class="u-txt-sub">PM</span> 02:00
                        </p>
                    </li>
                </ul>
                <p class="u-txt-gray-500 c-fs-18 fw-400">
                    ※ 일요일, 공휴일은 휴진입니다.
                </p>
                <p class="u-txt-gray-500 c-fs-18 fw-400">
                    ※ 토요일은 점심시간 없이 진료합니다.
                </p> 
            </div>
            <em
                class="d-block d-md-none u-bg-gray-600 u-my-20-sm u-op-5"
                style="height: 1px"></em>
            <!-- SNS & 연락처 -->
            <div
                class="col-12 u-bd-1 u-bc-gray-700 u-solid u-px-40 u-px-0-sm u-bd-n-sm"
                style="border-top: none !important; border-bottom: none !important">
                <h5 class="footer-title u-mb-30 fw-bold t-fs-36 u-txt-dark">
                    상담문의
                </h5>

                <a
                    href="tel:<?= preg_replace('/[^0-9]/', '', $conf['cf_tel']) ?>"
                    class="footer-phone d-block t-fs-40 fw-700 text-decoration-none u-txt-dark">
                    <img src="/images/call.svg" alt="" />
                    <?= htmlspecialchars($conf['cf_tel']) ?>
                </a>
                <div class="u-mt-20">
                    <div
                        id="daumRoughmapContainer1770873470613"
                        class="root_daum_roughmap root_daum_roughmap_landing"></div>
                </div>
            </div>
            <em
                class="d-block d-md-none u-bg-gray-600 u-my-20-sm u-op-5"
                style="height: 1px"></em>
            <!-- 오시는길 -->
            <div class="col-12 d-flex flex-column u-pl-40 u-pl-0-sm">
                <h5 class="footer-title fw-bold t-fs-36 u-txt-dark">
                    오시는길 <img src="/images/goldright.svg" alt="" />
                </h5>
                <p
                    class="u-txt-dark fw-400 t-fs-20 u-lh-175 u-mb-30"
                    style="letter-spacing: -1px">
                    <?= htmlspecialchars($conf['cf_address']) ?>
                </p>
                <div
                    class="footer-metro d-flex u-gap-10 align-items-start flex-wrap u-mb-10">
                    <div>
                        <div
                            class="bus_label u-bg-point d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                            <p class="fw-500 c-fs-18 u-txt-white u-mb-0">인천 2호선</p>
                        </div>
                    </div>
                    <div>
                        <div class="d-flex align-items-center u-gap-4 u-mb-6">
                            <img src="/images/buslabel.svg" alt="" />
                            <h6 class="c-fs-18 u-mb-0 u-txt-point">
                                가정중앙시장역 2번 출구 도보 6분
                            </h6>
                        </div>
                    </div>
                    <div class="col-12">
                        <p class="c-fs-14 fw-500 u-txt-gray-500">
                            *오시는 방향 : 2번 출구 → 오른쪽 방향 → 직진 후 KT 매장 →
                            오른쪽 방향
                        </p>
                    </div>
                </div>
                <div
                    class="footer-bus d-flex u-gap-10 align-items-start flex-wrap u-mb-10">
                    <div>
                        <div
                            class="bus_label d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                            <p class="fw-500 c-fs-18 u-txt-white u-mb-0">버스 이용 시</p>
                        </div>
                    </div>
                    <div>
                        <div class="d-flex align-items-center u-gap-4 u-mb-6">
                            <img src="/images/buslabel.svg" alt="" />
                            <h6 class="c-fs-18 u-mb-0">신현쇼핑 앞 하차</h6>
                        </div>
                    </div>
                    <div class="col-12">
                        <p class="c-fs-16 fw-500 u-txt-gray-500">
                            검암동 방향 77, 7, 28, 103-1, 12, 903
                        </p>
                    </div>
                </div>
                <div class="footer-car d-flex u-gap-10 align-items-start flex-wrap">
                    <div>
                        <div
                            class="car_label d-flex u-gap-4 u-px-10 u-py-4 rounded-full">
                            <p class="fw-500 c-fs-18 u-txt-white u-mb-0">
                                자가용 이용 시
                            </p>
                        </div>
                    </div>
                    <div>
                        <div class="d-flex align-items-center u-gap-4 u-mb-6">
                            <h6 class="c-fs-18 u-mb-0 u-txt-gray-900">
                                금강아미움 주차장 2시간 지원
                            </h6>
                        </div>
                    </div>
                    <div class="col-12">
                        <p class="c-fs-16 fw-500 u-txt-gray-500">
                            *주차 시 데스크에서 주차 등록 해주셔야 합니다.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright -->
    <div
        class="u-fluid u-fluid-xl-sm u-bg-main rounded-full u-px-48 u-py-28 rounded-20-sm ">
        <div class="w-100-sm">
            <div
                class="d-flex justify-content-between align-items-start align-items-md-center flex-column flex-md-row flex-wrap">
                <div
                    class="d-flex u-gap-80 align-items-start align-items-md-center flex-column flex-md-row u-gap-30-sm u-mb-30-sm">
                    <a href="/">
                        <img class="w-100 w-50-sm" src="/images/footlogo.svg" alt="" />
                    </a>
                    <div>
                        <p class="u-txt-gray-500 c-fs-16 fw-400 u-mb-0 c-fs-14-sm">
                            상호명 : <?= htmlspecialchars($conf['cf_company_name']) ?> |
                            <br class="d-block d-md-none" />
                            대표·원장 : <?= htmlspecialchars($conf['cf_ceo_name']) ?> |
                            <br class="d-block d-md-none" />
                            사업자등록번호 : <?=
                                        htmlspecialchars($conf['cf_business_number']) ?>
                        </p>
                        <p class="u-txt-gray-500 c-fs-16 fw-400 c-fs-10-sm">
                            Copyright 2025. MAEUM DAMEUN DENTAL CLINIC All rights
                            reserved.
                        </p>
                        <div
                            class="d-flex justify-content-start align-items-center u-txt-gray-500 c-fs-16 u-gap-4">
                            <a
                                href="#"
                                class="u-txt-gray-500 fw-400 c-fs-16"
                                data-bs-toggle="modal"
                                data-bs-target="#modalPrivacy">개인정보처리방침</a>
                            |
                            <a
                                href="#"
                                class="u-txt-gray-500 fw-400 c-fs-16"
                                data-bs-toggle="modal"
                                data-bs-target="#modalProvision">이용약관</a>
                        </div>
                    </div>
                </div>
                <div class="u-mb-30-sm">
                    <div class="d-flex u-gap-18 w-max">
                        <a href="#" class="sns-icon"><img src="/images/blog.svg" alt="" /></a>
                        <a href="#" class="sns-icon"><img src="/images/naver.svg" alt="" /></a>
                        <a href="#" class="sns-icon"><img src="/images/talk.svg" alt="" /></a>
                        <a href="#" class="sns-icon"><img src="/images/kakao.svg" alt="" /></a>
                    </div>
                </div>
                <div class="flex-1-sm">
                    <button
                        class="u-btn u-btn-accent rounded-full u-txt-white u-bg-sub fw-bold t-fs-20 d-flex align-items-center u-py-14 u-px-28 u-px-14-sm w-max-sm u-py-4-sm t-fs-14-sm"
                        data-bs-toggle="modal"
                        data-bs-target="#modalNonCovered">
                        비급여고지표
                    </button>
                </div>
            </div>
        </div>
    </div>
</footer>



<!-- 이용약관 모달 -->
<div class="modal fade" id="modalProvision" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <h5 class="modal-title fw-700 t-fs-20">이용약관</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php
                echo isset($conf['cf_terms']) && $conf['cf_terms']
                    ? nl2br($conf['cf_terms'])
                    : "등록된 이용약관이 없습니다.";
                ?>
            </div>
        </div>
    </div>
</div>


<!-- 개인정보처리방침 모달 -->
<div class="modal fade" id="modalPrivacy" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-24 border-0">
            <div class="modal-header u-p-24 u-bd-b-1">
                <h5 class="modal-title fw-700 t-fs-20 u-txt-main">개인정보처리방침</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body u-p-32 c-fs-15 u-lh-160 u-txt-body" style="max-height: 60vh; overflow-y: auto;">
                <?php
                echo isset($conf['cf_privacy_policy']) && $conf['cf_privacy_policy']
                    ? nl2br($conf['cf_privacy_policy'])
                    : "등록된 개인정보처리방침이 없습니다.";
                ?>
            </div>
        </div>
    </div>
</div>


<!-- 비급여 수가표 모달 -->
<div class="modal fade" id="modalNonCovered" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-16 u-bd-n shadow-soft">
            <div class="modal-header u-bg-soft">
                <h5 class="modal-title fw-700">비급여 수가표</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body u-p-0">
                <table class="u-table" style="width: 100%;">
                    <thead class="u-bg-gray-100 u-txt-title">
                        <tr>
                            <th class="u-p-16">항목명</th>
                            <th class="u-p-16">가격</th>
                            <th class="u-p-16">비고</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($non_covered)) { ?>
                            <tr>
                                <td colspan="3" class="u-p-40 u-txt-center u-txt-muted">
                                    등록된 항목이 없습니다.
                                </td>
                            </tr>
                        <?php } else { ?>
                            <?php foreach ($non_covered as $row) { ?>
                                <tr class="u-bd-b-1 u-bc-gray-100">
                                    <td class="u-p-16 fw-600 u-txt-center">
                                        <?= htmlspecialchars($row['name']) ?>
                                    </td>
                                    <td class="u-p-16 u-txt-main u-txt-center">
                                        <?= htmlspecialchars($row['price']) ?>원
                                    </td>
                                    <td class="u-p-16 u-txt-gray-500 u-txt-center">
                                        <?= htmlspecialchars($row['note']) ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div id="quick_menu_pill" class="u-pretendard">
    <div class="quick_menu_pill-container">
        <div class="quick_menu_pill-items">
            <ul class="u-gap-8 d-flex flex-column">
                <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q01.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">네이버 예약</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q02.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">카톡 상담</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q03.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">블로그</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q04.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">인스타그램</p>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q05.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">유튜브</p>
                        </div>
                    </a>
                </li>
                <li class="d-block d-md-none">
                    <a href="/" target="_blank" class="qm-bar-fixed-item">
                        <img src="/images/q06.svg" alt="" />
                        <div class="qm-bar-fixed-item-text">
                            <p class="fw-500 c-fs-16 u-lh-14 u-ls-10">전화상담</p>
                        </div>
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <button
        type="button"
        id="qm_pill_toggle"
        class="qm-pill-toggle u-bg-sub u-mt-16-sm">
        <img src="/images/quickLogo.svg" alt="" />
    </button>

    <button
        type="button"
        class="u-bg-white aspect-1-1 rounded-full u-bd-n shadow-sm u-mt-8 u-mt-16-sm shadow-soft"
        id="SD">
        <img src="/images/quickSD.svg" alt="" />
    </button>

    <div
        id="SD-popup"
        class="u-bg-light shadow-soft u-round-20 u-p-40 u-pretendard">
        <div class="u-mb-24">
            <h5
                class="fw-bold u-lh-14 u-ls-10 t-fs-28 u-txt-dark u-mb-20 t-fs-32-sm">
                빠른 상담 문의
            </h5>
            <p class="u-txt-gray-600 c-fs-16 fw-400 u-lh-15 u-ls-10 c-fs-16-sm">
                신청을 남겨주시면 최대한 빠른 시간 내에<br />전화드리겠습니다.
            </p>
        </div>

        <form id="inquiryFormPopup" onsubmit="return submitInquiry(this);">
            <input
                type="text"
                name="wr_name"
                class="w-100 u-mb-10 u-bg-white u-bd-n u-txt-dark u-py-10 u-px-16 u-round-4 c-fs-14 fw-400 u-lh-16 u-ls-10 c-fs-16-sm"
                placeholder="성함을 입력해주세요"
                required />
            <input
                type="tel"
                name="wr_1"
                class="w-100 u-mb-10 u-bg-white u-bd-n u-txt-dark u-py-10 u-px-16 u-round-4 c-fs-14 fw-400 u-lh-16 u-ls-10 c-fs-16-sm"
                placeholder="연락처를 입력해주세요 (010-0000-0000)"
                style="outline: none"
                required />

            <div class="u-mb-24">
                <div class="d-flex u-gap-16 u-mb-10">
                    <label
                        class="d-flex align-items-center u-gap-6 c-fs-14 u-px-16 u-py-8 u-gap-10 u-round-full u-bg-white c-fs-14-sm"
                        style="cursor: pointer">
                        <input
                            type="checkbox"
                            class="u-check"
                            name="agree_sms"
                            value="Y"
                            checked />
                        SMS 수신동의
                    </label>
                    <label
                        class="d-flex align-items-center u-gap-6 c-fs-14 u-px-16 u-py-8 u-gap-10 u-round-full u-bg-white c-fs-14-sm"
                        style="cursor: pointer">
                        <input
                            type="checkbox"
                            class="u-check"
                            name="agree_kakao"
                            value="Y"
                            checked />
                        카카오톡 수신 동의
                    </label>
                </div>
                <p class="c-fs-10 u-mt-8 c-fs-14-sm">
                    * 상담 안내를 위한 정보 수신에 동의합니다.
                </p>
            </div>

            <!-- 숨겨진 실제 input (form 데이터 전송용) -->
            <input
                type="hidden"
                name="inquiry_type"
                id="inquiry_type_value"
                value="" />

            <!-- 커스텀 드롭다운 -->
            <div class="custom-select-wrap position-relative w-100 u-mb-12">
                <div
                    class="custom-select-trigger u-round-4 u-bg-white c-fs-14 u-px-16 u-py-10 u-txt-dark d-flex justify-content-between align-items-center c-fs-16-sm"
                    style="cursor: pointer; border: 1px solid #e0e0e0">
                    <span class="custom-select-label u-txt-gray-500">문의하실 분야를 선택하세요</span>
                    <i
                        class="bi bi-chevron-down custom-select-arrow"
                        style="transition: transform 0.2s"></i>
                </div>
                <ul
                    class="custom-select-options u-bg-white u-round-4 position-absolute w-100 u-mb-0 u-p-0"
                    style="
                display: none;
                top: calc(100% + 4px);
                left: 0;
                z-index: 100;
                border: 1px solid #e0e0e0;
                list-style: none;
                overflow: hidden;
              ">
                    <li
                        class="custom-option u-px-16 u-py-10 c-fs-14 u-txt-dark c-fs-16-sm"
                        style="cursor: pointer"
                        data-value="A">
                        임플란트 클리닉
                    </li>
                    <li
                        class="custom-option u-px-16 u-py-10 c-fs-14 u-txt-dark c-fs-16-sm"
                        style="cursor: pointer"
                        data-value="B">
                        교정심미치료 클리닉
                    </li>
                    <li
                        class="custom-option u-px-16 u-py-10 c-fs-14 u-txt-dark c-fs-16-sm"
                        style="cursor: pointer"
                        data-value="C">
                        자연치아 살리기 클리닉
                    </li>
                    <li
                        class="custom-option u-px-16 u-py-10 c-fs-14 u-txt-dark c-fs-16-sm"
                        style="cursor: pointer"
                        data-value="D">
                        일반진료 클리닉
                    </li>
                </ul>
            </div>

            <textarea
                name="wr_content"
                class="w-100 u-mb-40 u-round-4 u-bd-n u-bg-white c-fs-14 u-px-16 u-py-10 u-txt-dark c-fs-16-sm"
                placeholder="궁금하신 내용을 입력해주세요"
                rows="4"
                style="outline: none; resize: vertical"></textarea>

            <div class="d-flex u-gap-10 justify-content-end">
                <button
                    type="button"
                    id="SD-cancel"
                    class="w-max u-bd-n u-py-10 c-fs-14 u-lh-16 u-ls-10 u-px-20 u-py-14 u-round-8 fw-500 c-fs-16-sm"
                    style="background: #f0f0f0; cursor: pointer">
                    취소
                </button>
                <button
                    type="submit"
                    class="w-max u-bd-n u-py-10 u-px-20 u-round-8 fw-600 c-fs-14 u-lh-16 u-ls-10 fw-500 u-txt-white u-bg-main c-fs-16-sm">
                    문의하기
                </button>
            </div>
        </form>
    </div>
</div>


<!-- ========================================== -->
<!-- Bootstrap 5 JS (모달 작동을 위해 필수!) -->
<!-- ========================================== -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


<!-- 다음 지도 스크립트 -->
<script charset="UTF-8" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>

<script>
    // ==========================================
    // 토스트 메시지 표시 함수
    // ==========================================
    function showToast(message, type = 'default') {
        // 기존 토스트 제거
        const existingToast = document.querySelector('.toast-message');
        if (existingToast) {
            existingToast.remove();
        }

        // 새 토스트 생성
        const toast = document.createElement('div');
        toast.className = 'toast-message';
        if (type === 'success') toast.classList.add('success');
        if (type === 'error') toast.classList.add('error');
        if (type === 'warning') toast.classList.add('warning');
        toast.textContent = message;

        document.body.appendChild(toast);

        // 애니메이션 효과
        setTimeout(() => toast.classList.add('show'), 10);

        // 2.5초 후 사라짐
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    }
</script>

<script>
    let scrollTracked = {
        '25': false,
        '50': false,
        '75': false,
        '100': false
    };

    window.addEventListener('scroll', function() {
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const scrolled = (window.scrollY / scrollHeight) * 100;

        if (scrolled >= 25 && !scrollTracked['25']) {
            gtag('event', 'scroll_depth', {
                'depth': '25%',
                'page_location': window.location.href
            });
            scrollTracked['25'] = true;
        }

        if (scrolled >= 50 && !scrollTracked['50']) {
            gtag('event', 'scroll_depth', {
                'depth': '50%',
                'page_location': window.location.href
            });
            scrollTracked['50'] = true;
        }

        if (scrolled >= 75 && !scrollTracked['75']) {
            gtag('event', 'scroll_depth', {
                'depth': '75%',
                'page_location': window.location.href
            });
            scrollTracked['75'] = true;
        }

        if (scrolled >= 99 && !scrollTracked['100']) {
            gtag('event', 'scroll_depth', {
                'depth': '100%',
                'page_location': window.location.href
            });
            scrollTracked['100'] = true;
        }
    });
</script>
<script>
    // ==========================================
    // 1. AOS + 메인 Swiper 초기화
    // ==========================================
    AOS.init();
    const swiperMain = new Swiper("#swiper-main", {
        slidesPerView: 1,
        spaceBetween: 0,
        effect: '<?= htmlspecialchars($banner_settings['effect']) ?>',
        loop: <?= $banner_settings['loop'] ? 'true' : 'false' ?>,
        speed: <?= (int)$banner_settings['speed'] ?>,
        autoplay: {
            delay: <?= (int)$banner_settings['autoplay_delay'] ?>,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        on: {
            slideChange: function() {
                AOS.refresh();
            },
        },
    });
</script>

<script>
    // ==========================================
    // 2. 케이스 탭 전환 (tab-btn)
    // ==========================================
    document.addEventListener("DOMContentLoaded", function() {
        const tabButtons = document.querySelectorAll(".tab-btn");
        const tabContents = document.querySelectorAll(".tab-contents");

        tabButtons.forEach((button) => {
            button.addEventListener("click", function() {
                tabButtons.forEach((btn) => btn.classList.remove("active"));
                this.classList.add("active");

                tabContents.forEach((content) => {
                    content.classList.remove("active");
                    content.style.display = "none";
                });

                const tabId = this.getAttribute("data-tab");
                const targetTab = document.getElementById(tabId);
                if (targetTab) {
                    targetTab.classList.add("active");
                    targetTab.style.display = "grid";
                }
            });
        });

        // 초기 상태: 첫 번째 탭만 표시
        tabContents.forEach((content, index) => {
            content.style.display = index === 0 ? "grid" : "none";
        });
    });
</script>

<script>
    // ==========================================
    // 3. 진료 항목 탭 전환 (doc-btn)
    // ==========================================
    document.addEventListener("DOMContentLoaded", function() {
        const tabButtons = document.querySelectorAll(".doc-btn");

        tabButtons.forEach((button) => {
            button.addEventListener("click", function() {
                const targetTab = this.getAttribute("data-tab");

                document.querySelectorAll(".tab-content").forEach((content) => {
                    content.classList.remove("active");
                });
                document.querySelectorAll(".doc-btn").forEach((btn) => {
                    btn.classList.remove("active");
                });

                document.getElementById(targetTab).classList.add("active");
                document.querySelectorAll(`[data-tab="${targetTab}"]`).forEach((btn) => {
                    btn.classList.add("active");
                });
            });
        });
    });
</script>

<script>
    // ==========================================
    // 4. sect06 — 데스크톱 GSAP 스크롤 + 모바일 Swiper
    // ==========================================
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

    if (window.innerWidth >= 769) {
        ScrollTrigger.create({
            trigger: "#sect06 .slide-wrap",
            start: "0% 0%",
            end: "100% 0%",
            scrub: true,
            onUpdate: ({
                progress
            }) => {
                let idx = Math.min(Math.floor(progress * 3), 2);

                document.querySelectorAll("#sect06 .service-list li").forEach((item, i) => {
                    item.classList.toggle("active", i === idx);
                });
                document.querySelectorAll("#sect06 .img-box .img").forEach((item, i) => {
                    item.classList.toggle("show", i === idx);
                });

                const numberEl = document.querySelector("#sect06 .left-text .number");
                if (numberEl) numberEl.textContent = "0" + (idx + 1);

                // 오른쪽 텍스트 데이터 (3개)
                const rightTextData = [{
                        subTitle: "대학병원급 분과별 ",
                        title: "4인 전문의 협진",
                        desc: "대학병원에 가지 않아도 집 근처에서 일반진료 부터<br>고난이도 진료까지 포괄적인 진료가 가능",
                    },
                    {
                        subTitle: "누적 식립 1만 건 이상 ",
                        title: "숫자가 증명하는 차별화된 전문성",
                        desc: "26년 3월 기준 <br>임플란트 누적 식립 개수 1만건",
                    },
                    {
                        subTitle: "가정동 150평 대형치과,",
                        title: "독립된 집중치료실 구축",
                        desc: "환자 한 분 한 분에게 온전히 집중하고, 편안한 <br>상태에서 최선의 치료 결과를 제공하기 위함",
                    },
                ];

                // 오른쪽 텍스트 업데이트
                const iconEl = document.querySelector("#sect06 .right-text .icon");
                const subTitleEl = document.querySelector(
                    "#sect06 .right-text .sub-title",
                );
                const titleEl = document.querySelector(
                    "#sect06 .right-text .main-title",
                );
                const descEl = document.querySelector(
                    "#sect06 .right-text .description",
                );

                if (titleEl && subTitleEl && descEl && rightTextData[idx]) {
                    titleEl.innerHTML = rightTextData[idx].title;
                    subTitleEl.innerHTML = rightTextData[idx].subTitle;
                    descEl.innerHTML = rightTextData[idx].desc;
                }
            },
        });
    }

    if (window.innerWidth < 769) {
        new Swiper("#sect06 .swiper-service", {
            slidesPerView: 1,
            spaceBetween: 0,
            centeredSlides: true,
            loop: true,
            autoplay: {
                delay: 8000,
                disableOnInteraction: false,
            },
            on: {
                slideChange: function() {
                    updateMobileActiveClass(this.realIndex);
                },
            },
        });
    }
</script>

<script>
    // ==========================================
    // sect03 — 데스크톱 GSAP 스크롤 + 모바일 Swiper
    // ==========================================
    gsap.registerPlugin(ScrollTrigger, ScrollToPlugin);

    const rightTextData = [{
            subTitle: "",
            title: "&lt;Top 100 Implant Doctors in Korea&gt;",
            desc: "Recognized as one of the Top 100 Doctors<br> for clinical excellence and implant expertise.",
        },
        {
            subTitle: "",
            title: "&lt;Thesis&gt;",
            desc: "Experiment of vasopressin receptor <br> agonist to substitute epinephrine <br> Autophagy: a multifaceted intracellular system <br>for bulk and selective recycling",
        },
        {
            subTitle: "",
            title: "&lt;Specialist Certification&gt;",
            desc: "Certified by the Ministry of Health and Welfare,<br> providing comprehensive <br>and systematic treatment planning.",
        },
        {
            subTitle: "",
            title: "&lt;Adjunct Professor&gt;",
            desc: "Actively engaged in clinical education <br>and academic research<br> alongside ongoing patient care.",
        },
    ];

    if (window.innerWidth >= 0) {
        const slideWrap = document.querySelector("main.doctors #sect03 .slide-wrap.d-md-block");
        const listItems = document.querySelectorAll("main.doctors #sect03 .service-list li");
        const imgs = document.querySelectorAll("main.doctors #sect03 .img-box .img");
        const bullets = document.querySelectorAll("main.doctors #sect03 .pc-bullet");
        const subTitleEl = document.querySelector("main.doctors #sect03 .right-text .sub-title");
        const titleEl = document.querySelector("main.doctors #sect03 .right-text .main-title");
        const descEl = document.querySelector("main.doctors #sect03 .right-text .description");

        function updateSlide(idx) {
            idx = Math.max(0, Math.min(idx, 3));
            listItems.forEach((el, i) => el.classList.toggle("active", i === idx));
            imgs.forEach((el, i) => el.classList.toggle("show", i === idx));
            bullets.forEach((el, i) => el.classList.toggle("active", i === idx));
            if (subTitleEl) subTitleEl.innerHTML = rightTextData[idx].subTitle;
            if (titleEl) titleEl.innerHTML = rightTextData[idx].title;
            if (descEl) descEl.innerHTML = rightTextData[idx].desc;
        }

        updateSlide(0);

        ScrollTrigger.create({
            trigger: "main.doctors #sect03 .slide-wrap .sticky",
            start: "top top",
            end: "+=300%",
            pin: true,
            scrub: 1,
            onUpdate: ({
                progress
            }) => {
                const idx = Math.min(Math.floor(progress * 4), 3);
                updateSlide(idx);
            },
        });
    }

    // if (window.innerWidth < 769) {
    //     const swiperEl = document.querySelector("main.doctors #sect03 .swiper-service2");
    //     const paginationEl = document.querySelector("main.doctors #sect03 .swiper-service2 .swiper-pagination");

    //     new Swiper(swiperEl, {
    //         slidesPerView: 1,
    //         spaceBetween: 0,
    //         centeredSlides: true,
    //         loop: true,
    //         pagination: {
    //             el: paginationEl,
    //             clickable: true,
    //         },
    //         autoplay: {
    //             delay: 8000,
    //             disableOnInteraction: false,
    //         },
    //     });
    // }
</script>



<script>
    // ==========================================
    // 5. sect09 탭 + Swiper 초기화
    // ==========================================
    const swipers = {};

    function initSwiper(tabId) {
        if (swipers[tabId]) return;
        swipers[tabId] = new Swiper(`.swiper-${tabId}`, {
            slidesPerView: 1,
            spaceBetween: 0,
            pagination: {
                el: `.swiper-${tabId} .swiper-pagination`,
                clickable: true,
            },
            navigation: {
                prevEl: `.swiper-${tabId} .swiper-button-prev`,
                nextEl: `.swiper-${tabId} .swiper-button-next`,
            },
        });
    }

    initSwiper("tab1");

    document.querySelectorAll(".sect09-tab-btn").forEach((btn) => {
        btn.addEventListener("click", function() {
            const target = this.getAttribute("data-tab");

            document.querySelectorAll(".sect09-tab-btn").forEach((b) => b.classList.remove("active"));
            this.classList.add("active");

            document.querySelectorAll(".sect09-tab-content").forEach((c) => c.classList.remove("active"));
            document.getElementById(target).classList.add("active");

            initSwiper(target);
        });
    });
</script>

<script>
    // ==========================================
    // 6. 카카오맵 (다음 지도) 렌더링
    // ==========================================
</script>
<?php if (empty($no_tail_map)): ?>
    <script charset="UTF-8" class="daum_roughmap_loader_script" src="https://ssl.daumcdn.net/dmaps/map_js_init/roughmapLoader.js"></script>
    <script charset="UTF-8">
        new daum.roughmap.Lander({
            timestamp: "1770873470613",
            key: "h9622g47xio",
            mapWidth: "376",
            mapHeight: "173",
        }).render();
    </script>
<?php endif; ?>

<script>
    // ==========================================
    // 7. 퀵메뉴 (필형 토글 + 외부 클릭 닫기)
    // ==========================================
    (function() {
        "use strict";

        var pillItems = document.querySelector(".quick_menu_pill-items");
        var pillToggle = document.getElementById("qm_pill_toggle");
        var pillTop = document.getElementById("qm_pill_top");

        if (pillToggle) {
            pillToggle.onclick = function() {
                pillItems.classList.toggle("active");
                pillToggle.classList.toggle("active");
                if (typeof gtag !== "undefined") {
                    gtag("event", "click_quick_menu", {
                        event_category: "engagement",
                        event_label: "pill_toggle"
                    });
                }
            };
        }

        if (pillTop) {
            pillTop.onclick = function() {
                window.scrollTo({
                    top: 0,
                    behavior: "smooth"
                });
                if (typeof gtag !== "undefined") {
                    gtag("event", "click_quick_menu", {
                        event_category: "engagement",
                        event_label: "pill_top"
                    });
                }
            };
        }

        // 링크 미설정 시 알림
        var allLinks = document.querySelectorAll(".qm-circle-item, .qm-bar-item, .qm-bar-fixed-item");
        for (var i = 0; i < allLinks.length; i++) {
            allLinks[i].onclick = function(e) {
                var has = this.getAttribute("data-has");
                if (has === "0" && this.href && this.href.indexOf("#") !== -1) {
                    e.preventDefault();
                    alert("링크가 설정되지 않았습니다.");
                    return false;
                }
            };
        }

        // 외부 클릭 시 메뉴 닫기
        document.addEventListener("click", function(e) {
            var circleMenu = document.getElementById("quick_menu_circle");
            var barMenu = document.getElementById("quick_menu_bar");
            var pillMenu = document.getElementById("quick_menu_pill");

            if (circleMenu && !circleMenu.contains(e.target) && circleItems && circleItems.classList.contains("active")) {
                circleItems.classList.remove("active");
                circleToggle.classList.remove("active");
            }
            if (barMenu && !barMenu.contains(e.target) && barWrapper && barWrapper.classList.contains("active")) {
                barWrapper.classList.remove("active");
            }
            if (pillMenu && !pillMenu.contains(e.target) && pillItems && pillItems.classList.contains("active")) {
                pillItems.classList.remove("active");
                pillToggle.classList.remove("active");
            }
        });
    })();
</script>

<script>
    // ==========================================
    // 8. SD 팝업 + 백드랍 (640px 이하 활성화)
    // ==========================================
    const sdBtn = document.getElementById("SD");
    const sdPopup = document.getElementById("SD-popup");
    const sdCancel = document.getElementById("SD-cancel");

    const sdBackdrop = document.createElement("div");
    sdBackdrop.id = "sd-backdrop";
    Object.assign(sdBackdrop.style, {
        display: "none",
        position: "fixed",
        inset: "0",
        backgroundColor: "rgba(0,0,0,0.5)",
        zIndex: "998",
    });
    document.body.appendChild(sdBackdrop);

    function openSdPopup() {
        sdPopup.style.display = "block";
        if (window.innerWidth <= 640) sdBackdrop.style.display = "block";
    }

    function closeSdPopup() {
        sdPopup.style.display = "none";
        sdBackdrop.style.display = "none";
    }

    sdBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        sdPopup.style.display === "block" ? closeSdPopup() : openSdPopup();
    });
    sdCancel.addEventListener("click", () => closeSdPopup());
    sdBackdrop.addEventListener("click", () => closeSdPopup());
    document.addEventListener("click", (e) => {
        if (!sdPopup.contains(e.target) && !sdBtn.contains(e.target)) closeSdPopup();
    });
</script>

<script>
    // ==========================================
    // 9. 문의 드롭다운 + AJAX 폼 제출
    // ==========================================
    document.querySelectorAll(".custom-select-wrap").forEach((wrap) => {
        const trigger = wrap.querySelector(".custom-select-trigger");
        const options = wrap.querySelector(".custom-select-options");
        const label = wrap.querySelector(".custom-select-label");
        const arrow = wrap.querySelector(".custom-select-arrow");
        const hidden = document.getElementById("inquiry_type_value");

        trigger.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = options.style.display === "block";
            options.style.display = isOpen ? "none" : "block";
            arrow.style.transform = isOpen ? "rotate(0deg)" : "rotate(180deg)";
        });

        options.querySelectorAll(".custom-option").forEach((option) => {
            option.addEventListener("click", (e) => {
                e.stopPropagation();
                hidden.value = option.dataset.value;
                label.textContent = option.textContent.trim();
                label.classList.remove("u-txt-gray-500");
                options.querySelectorAll(".custom-option").forEach((o) => o.classList.remove("selected"));
                option.classList.add("selected");
                options.style.display = "none";
                arrow.style.transform = "rotate(0deg)";
            });
        });
    });

    document.addEventListener("click", () => {
        document.querySelectorAll(".custom-select-options").forEach((opt) => (opt.style.display = "none"));
        document.querySelectorAll(".custom-select-arrow").forEach((arrow) => (arrow.style.transform = "rotate(0deg)"));
    });

    function submitInquiry(f) {
        if (!f.inquiry_type.value) {
            showToast("문의 분야를 선택해주세요.", "warning");
            return false;
        }
        if (!f.wr_name.value.trim()) {
            showToast("성함을 입력해주세요.", "warning");
            return false;
        }
        if (!f.wr_1.value.trim()) {
            showToast("연락처를 입력해주세요.", "warning");
            return false;
        }

        const submitBtn = f.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.innerText = "전송 중...";

        fetch("/ajax.inquiry_update.php", {
                method: "POST",
                body: new FormData(f)
            })
            .then(async (res) => {
                const text = await res.text();
                try {
                    return JSON.parse(text);
                } catch (e) {
                    throw new Error("서버 내부 오류가 발생했습니다.");
                }
            })
            .then((data) => {
                if (data.res === "success") {
                    gtag("event", "generate_lead", {
                        event_category: "conversion",
                        event_label: "inquiry_submit",
                        inquiry_type: f.inquiry_type.value,
                        value: 1
                    });
                    bootstrap.Modal.getInstance(document.getElementById("inquiryModal"))?.hide();
                    showToast("문의가 정상적으로 접수되었습니다. 🎉", "success");
                    setTimeout(() => {
                        f.reset();
                        submitBtn.disabled = false;
                        submitBtn.innerText = "문의하기";
                    }, 1000);
                } else {
                    gtag("event", "form_error", {
                        event_category: "error",
                        event_label: "inquiry_submit_fail"
                    });
                    showToast(data.msg || "문의 접수에 실패했습니다.", "error");
                    submitBtn.disabled = false;
                    submitBtn.innerText = "문의하기";
                }
            })
            .catch((error) => {
                gtag("event", "form_error", {
                    event_category: "error",
                    event_label: "inquiry_submit_error"
                });
                showToast(error.message || "오류가 발생했습니다.", "error");
                submitBtn.disabled = false;
                submitBtn.innerText = "문의하기";
            });

        return false;
    }
</script>

<script>
    // ==========================================
    // 10. swiper-service2 (모바일 카드 슬라이더)
    // ==========================================
    new Swiper(".swiper-service2", {
        loop: true,
        speed: 500,
        autoplay: {
            delay: 5000
        },
        slidesPerView: 1,
        spaceBetween: 16,
        centeredSlides: false,
        pagination: {
            el: ".swiper-service2 .swiper-pagination",
            clickable: true,
        },
    });
</script>


<?php
// tail.sub.php는 로드하지 않음 (BS5 중복 방지)
include_once(G5_PATH . '/tail_sub.php');
?>
</body>

</html>