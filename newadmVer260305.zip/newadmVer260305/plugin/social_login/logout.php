<?php
include_once($_SERVER['DOCUMENT_ROOT'] . '/common.php');
include_once($_SERVER['DOCUMENT_ROOT'] . '/_common.php');

// 카카오 로그인 사용자 체크
$is_kakao = false;
if (isset($_SESSION['ss_mb_id']) && strpos($_SESSION['ss_mb_id'], 'kakao_') === 0) {
    $is_kakao = true;
}

// 그누보드 로그아웃 처리
set_session('ss_mb_id', '');
set_cookie('ck_mb_id', '', 0);
set_cookie('ck_auto', '', 0);

// 카카오 사용자면 카카오도 로그아웃
if ($is_kakao) {
    $dm_conf = sql_fetch("SELECT * FROM dm_config WHERE cf_id = 1");
    if ($dm_conf['cf_kakao_rest_key']) {
        $logout_redirect = G5_URL;
        $kakao_logout_url = "https://kauth.kakao.com/oauth/logout?client_id=" . 
                           $dm_conf['cf_kakao_rest_key'] . 
                           "&logout_redirect_uri=" . urlencode($logout_redirect);
        goto_url($kakao_logout_url);
    }
}

goto_url(G5_URL);
?>