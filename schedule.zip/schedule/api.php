<?php
// ============================================================
// api.php — 진료일정 데이터 API
// ============================================================
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

define('DATA_FILE', __DIR__ . '/schedule_data.json');

function read_data() {
    if (!file_exists(DATA_FILE)) return [];
    $data = json_decode(file_get_contents(DATA_FILE), true);
    return is_array($data) ? $data : [];
}
function write_data($data) {
    file_put_contents(DATA_FILE, json_encode(array_values($data), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

$method = $_SERVER['REQUEST_METHOD'];

// ── GET
if ($method === 'GET') {
    $data  = read_data();
    $year  = isset($_GET['year'])  ? (int)$_GET['year']  : null;
    $month = isset($_GET['month']) ? (int)$_GET['month'] : null;
    if ($year && $month) {
        $data = array_values(array_filter($data, fn($s) => $s['year'] === $year && $s['month'] === $month));
    }
    echo json_encode(['ok' => true, 'data' => $data]);
    exit;
}

// ── POST (저장 / 수정 — 같은 이름이면 덮어쓰기)
if ($method === 'POST') {
    $body  = json_decode(file_get_contents('php://input'), true);
    if (!$body) { http_response_code(400); echo json_encode(['ok'=>false,'msg'=>'Invalid JSON']); exit; }

    $name  = trim($body['name']  ?? '');
    $year  = (int)($body['year']  ?? 0);
    $month = (int)($body['month'] ?? 0);
    $marks = $body['marks'] ?? [];

    if (!$name || !$year || !$month) {
        http_response_code(400);
        echo json_encode(['ok'=>false,'msg'=>'name, year, month 필수']);
        exit;
    }

    $data = read_data();

    // 제출 일시 (한국 시간)
    $now_ts  = time() + (9 * 3600); // UTC+9
    $now_str = gmdate('Y-m-d H:i:s', $now_ts); // "2026-03-19 14:32:00"

    // 수정 모드 (id 명시)
    if (!empty($body['id'])) {
        $found = false;
        foreach ($data as &$s) {
            if ($s['id'] === $body['id']) {
                $s['name']       = $name;
                $s['year']       = $year;
                $s['month']      = $month;
                $s['marks']      = $marks;
                $s['updatedAt']  = $now_str;
                $found = true;
                break;
            }
        }
        unset($s);
        if (!$found) { http_response_code(404); echo json_encode(['ok'=>false,'msg'=>'Not found']); exit; }
        write_data($data);
        echo json_encode(['ok'=>true,'msg'=>'수정 완료']);
        exit;
    }

    // 같은 이름 + 같은 연월이면 덮어쓰기
    $overwritten = false;
    foreach ($data as &$s) {
        if ($s['name'] === $name && $s['year'] === $year && $s['month'] === $month) {
            $s['marks']      = $marks;
            $s['updatedAt']  = $now_str;
            $overwritten = true;
            break;
        }
    }
    unset($s);

    if (!$overwritten) {
        array_unshift($data, [
            'id'        => uniqid('sc_', true),
            'name'      => $name,
            'year'      => $year,
            'month'     => $month,
            'marks'     => $marks,
            'createdAt' => $now_str,
        ]);
    }

    write_data($data);
    echo json_encode(['ok'=>true,'msg'=>$overwritten?'일정이 업데이트되었습니다.':'저장 완료']);
    exit;
}

// ── DELETE
if ($method === 'DELETE') {
    $id   = $_GET['id'] ?? '';
    if (!$id) { http_response_code(400); echo json_encode(['ok'=>false,'msg'=>'id 필수']); exit; }
    $data   = read_data();
    $before = count($data);
    $data   = array_values(array_filter($data, fn($s) => $s['id'] !== $id));
    if (count($data) === $before) { http_response_code(404); echo json_encode(['ok'=>false,'msg'=>'Not found']); exit; }
    write_data($data);
    echo json_encode(['ok'=>true,'msg'=>'삭제 완료']);
    exit;
}

http_response_code(405);
echo json_encode(['ok'=>false,'msg'=>'Method not allowed']);
